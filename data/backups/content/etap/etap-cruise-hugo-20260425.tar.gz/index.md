---
title: "Best Shore Excursions in Reykjavik: Cruise Port Activities and Day Tours"
date: 2026-04-25T12:10:59+09:00
description: "Best shore excursions in Reykjavik for cruise passengers: port tours with real prices, timing tips, and honest comparisons."
tags:
  - "Reykjavik"
  - "Iceland"
  - "Shore Excursions"
  - "Travel"
categories:
  - "Shore Excursions"
showTableOfContents: true
---

## A 20-minute taxi ride from the Reykjavik port transports you to the stunning landscapes and unique attractions that define Iceland's capital and its surroundings.


![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/reykjavik_shore-excursions/body_1.jpg)
*Photo by [Andrea De Santis](https://www.pexels.com/@santesson89) on [Pexels](https://www.pexels.com)*


<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8772455780561463"
     crossorigin="anonymous"></script>
<!-- ETAP -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8772455780561463"
     data-ad-slot="4276065235"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

## Top Shore Excursions in Reykjavik

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8772455780561463"
     crossorigin="anonymous"></script>
<!-- ETAP -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8772455780561463"
     data-ad-slot="4276065235"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/reykjavik_shore-excursions/body_2.jpg)
*Photo by [David Hitchcock](https://www.pexels.com/@david-hitchcock-2160795853) on [Pexels](https://www.pexels.com)*



| Tour | Price | Discount | Book |
|------|-------|----------|------|
| [Small-Group South Coast & Glacier Hike Tour from Reykjavik](https://www.viator.com/tours/Reykjavik/Small-Group-South-Coast-and-Glacier-Hike-Tour-from-Reykjavik/d905-5590AAGVW) | $189.92 | -1% | [Book](https://www.viator.com/tours/Reykjavik/Small-Group-South-Coast-and-Glacier-Hike-Tour-from-Reykjavik/d905-5590AAGVW) |
| [Landmannalaugar Highlands 4x4 Minibus Tour with Hot Spring Bath](https://www.viator.com/tours/Reykjavik/Landmannalaugar-Highlands-4x4-Minibus-Tour-with-Hot-Spring-Bath/d905-423175P29) | $207 | -10% | [Book](https://www.viator.com/tours/Reykjavik/Landmannalaugar-Highlands-4x4-Minibus-Tour-with-Hot-Spring-Bath/d905-423175P29) |
| [Golden Circle, Farm & Sky Lagoon Admission Small Group Tour](https://www.viator.com/tours/Reykjavik/Golden-Circle-Farm-and-Sky-Lagoon-Admission-Small-Group-Tour/d905-16698P39) | $216.90 | -10% | [Book](https://www.viator.com/tours/Reykjavik/Golden-Circle-Farm-and-Sky-Lagoon-Admission-Small-Group-Tour/d905-16698P39) |
| [Reykjanes peninsula](https://www.viator.com/tours/Reykjavik/Reykjanes-peninsula/d905-219782P4) | $937.64 | -10% | [Book](https://www.viator.com/tours/Reykjavik/Reykjanes-peninsula/d905-219782P4) |
| [The Golden Circle](https://www.viator.com/tours/Reykjavik/The-Golden-Circle/d905-219782P3) | $1229.42 | -10% | [Book](https://www.viator.com/tours/Reykjavik/The-Golden-Circle/d905-219782P3) |



When you're in [Reykjavik](https://flights.techpawz.com/posts/cheapest-flights-chicago-to-reykjavik/), a small group tour can often provide a more intimate and personalized experience. One standout option is the **Golden Circle, Fridheimar Farm & Horses Small Group Tour from Reykjavik** priced at $117 ISK. This tour not only takes you through [Iceland](https://visafree.techpawz.com/posts/iceland-visa-free/)’s famous Golden Circle but also allows for more flexibility and interaction with the landscape and your fellow travelers. It’s perfect for those who prefer a more relaxed pace and want to connect with the local culture. A practical tip is to wear comfortable shoes, as you'll likely be walking on uneven terrain while exploring the stunning natural features.

Another excellent choice is the **South Iceland, Glacier and Black Sand Beach Small Group Tour** at $123 ISK. This tour is ideal for nature lovers, offering an awe-inspiring journey to the southernmost tip of Iceland, where you’ll encounter both glaciers and striking black sand beaches. The small group setting enhances your experience, allowing for more questions and personal engagement with your guide. Be sure to bring your camera; the landscapes you'll encounter are truly photogenic. Also, check the weather forecast before you leave; it can change rapidly, so layers are your best bet.

For a slightly different perspective on the Golden Circle, consider the **Golden Circle Day Tour with Local Surprise - Small Group Minibus** for $126 ISK. This tour offers a more personal and relaxed experience in a small-group minibus, making it easier to bond with your fellow travelers. You’ll visit iconic sites like Þingvellir, Geysir, and Gullfoss, but the added "local surprise" keeps the itinerary exciting. A great tip is to bring a water bottle; staying hydrated is essential, especially if you’re doing a lot of walking.

## Best Half-Day Port Tours

If you're looking for a shorter excursion, half-day tours can still deliver a taste of Iceland's beauty. Unfortunately, there are no specific half-day tours listed in your data. However, considering the shorter duration of these options, they usually focus on a single highlight or attraction, making them a great choice if you want to maximize your time in the city. 

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/reykjavik_shore-excursions/body_3.jpg)
*Photo by [Andreas Ebner](https://www.pexels.com/@andreas-ebner-246992646) on [Pexels](https://www.pexels.com)*


## Full-Day Excursions Worth the Splurge

For those willing to spend a bit more for A Practical experience, full-day excursions can be incredibly rewarding. The **South Coast** tour priced at $1670 ISK is a prime example of a trip that covers a lot of ground. This tour includes visits to Seljalandsfoss and Eyjafjallajökull, among other breathtaking sites. It’s ideal if you're eager to see the varied landscapes of Iceland in a single day. Make sure to pack a hearty lunch or snacks, as you’ll be out exploring for a while, and sometimes food options can be limited.

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/reykjavik_shore-excursions/body_4.jpg)
*Photo by [Artūras Kokorevas](https://www.pexels.com/@kokorevas) on [Pexels](https://www.pexels.com)*


Another premium option is the **Borgarfjörður** tour for $1241 ISK, which takes you to stunning waterfalls like Hraunfossar and Barnafoss. This trip is great for those interested in the unique geological features of Iceland and the local lore surrounding them. The tour often includes a knowledgeable guide who can share fascinating stories, enhancing your experience. It’s advisable to bring a light jacket, as it can get breezy near the waterfalls.

Lastly, the **Golden Circle** tour at $1229 ISK is also worth considering if you want to experience the iconic sites in a more extensive format. This tour covers Þingvellir National Park, Geysir, and Gullfoss, making it A Practical introduction to Iceland's natural wonders. Always check the tour's itinerary for any extras or surprises, and don’t hesitate to ask the guide for tips on what to see after the tour ends.

## Tips for Cruise Passengers in Reykjavik

Navigating Reykjavik as a cruise passenger can be straightforward if you prepare a bit. The local currency is ISK, and while many places accept cards, having some cash for smaller vendors or tips can be useful.

The best days to explore are typically during weekdays when the crowds are lighter, but weekends can offer unique local events. Dress in layers to cope with the unpredictable weather; a waterproof jacket and sturdy shoes will serve you well, especially if you're heading to the beaches or waterfalls. Bring along a refillable water bottle, as tap water is pure and safe. Most importantly, don’t forget to pack snacks. While some tours include meals, having something on hand is a good idea, especially for longer excursions.

If you only have one day in Reykjavik, I recommend the **Golden Circle, Fridheimar Farm & Horses Small Group Tour from Reykjavik** for $117 ISK. It perfectly balances key attractions with a personal touch, giving you a memorable experience of Iceland's natural beauty.
<div class="etap-disclaimer-card">

> **📌 Disclaimer**
>
> Prices, schedules, tour details, flight routes, visa requirements, and all other information on this page are based on data **at the time of writing**. Fares, availability, and policies may change. Please verify current details on the official website before booking.

</div>


<div class="etap-product-cards">
<h2 class="etap-card-title">Top Tours &amp; Activities</h2>

[![Golden Circle, Fridheimar Farm & Horses Small Group Tour from Reykjavik](https://media-cdn.tripadvisor.com/media/attractions-splice-spp-360x240/06/f1/36/26.jpg)](https://www.viator.com/tours/Reykjavik/Golden-Circle-Fridheimar-Farm-and-Horses-Small-Group-Tour-from-Reykjavik/d905-16698P13)

**[Golden Circle, Fridheimar Farm & Horses Small Group Tour from Reykjavik](https://www.viator.com/tours/Reykjavik/Golden-Circle-Fridheimar-Farm-and-Horses-Small-Group-Tour-from-Reykjavik/d905-16698P13)** <span class="badge">-10%</span>

_Shore Excursions_

From **$117**

[Book Now](https://www.viator.com/tours/Reykjavik/Golden-Circle-Fridheimar-Farm-and-Horses-Small-Group-Tour-from-Reykjavik/d905-16698P13)

---

[![South Iceland, Glacier and Black Sand Beach Small Group Tour](https://media-cdn.tripadvisor.com/media/attractions-splice-spp-360x240/15/68/5c/74.jpg)](https://www.viator.com/tours/Reykjavik/South-Iceland-Glacier-and-Black-Sand-Beach-Small-Group-Tour/d905-16698P16)

**[South Iceland, Glacier and Black Sand Beach Small Group Tour](https://www.viator.com/tours/Reykjavik/South-Iceland-Glacier-and-Black-Sand-Beach-Small-Group-Tour/d905-16698P16)** <span class="badge">-10%</span>

_Shore Excursions_

From **$123**

[Book Now](https://www.viator.com/tours/Reykjavik/South-Iceland-Glacier-and-Black-Sand-Beach-Small-Group-Tour/d905-16698P16)

---

[![Golden Circle Day Tour with Local Surprise - Small Group Minibus](https://media-cdn.tripadvisor.com/media/attractions-splice-spp-360x240/r/32/d7/22/9b/caption.jpg)](https://www.viator.com/tours/Reykjavik/Golden-Circle-Day-Tour-with-Local-Surprise-Small-Group-Minibus/d905-423175P26)

**[Golden Circle Day Tour with Local Surprise - Small Group Minibus](https://www.viator.com/tours/Reykjavik/Golden-Circle-Day-Tour-with-Local-Surprise-Small-Group-Minibus/d905-423175P26)** <span class="badge">-10%</span>

_Day Trips_

From **$126**

[Book Now](https://www.viator.com/tours/Reykjavik/Golden-Circle-Day-Tour-with-Local-Surprise-Small-Group-Minibus/d905-423175P26)

---

[![Private One-Way Transfer: Reykjavík ↔ Blue Lagoon](https://media-cdn.tripadvisor.com/media/attractions-splice-spp-360x240/15/9d/99/0e.jpg)](https://www.viator.com/tours/Reykjavik/Private-One-Way-Transfer-Reykjavk-Blue-Lagoon/d905-459458P2)

**[Private One-Way Transfer: Reykjavík ↔ Blue Lagoon](https://www.viator.com/tours/Reykjavik/Private-One-Way-Transfer-Reykjavk-Blue-Lagoon/d905-459458P2)** <span class="badge">-20%</span>

_Shore Excursions_

From **$130**

[Book Now](https://www.viator.com/tours/Reykjavik/Private-One-Way-Transfer-Reykjavk-Blue-Lagoon/d905-459458P2)

---

[![Reykjavik Northern Lights Tour with Pro Aurora Photos Small Group](https://media-cdn.tripadvisor.com/media/attractions-splice-spp-360x240/10/04/00/6d.jpg)](https://www.viator.com/tours/Reykjavik/Reykjavik-Northern-Lights-Tour-with-Pro-Aurora-Photos-Small-Group/d905-380422P1)

**[Reykjavik Northern Lights Tour with Pro Aurora Photos Small Group](https://www.viator.com/tours/Reykjavik/Reykjavik-Northern-Lights-Tour-with-Pro-Aurora-Photos-Small-Group/d905-380422P1)** <span class="badge">-15%</span>

_Half-day Tours_

From **$135**

[Book Now](https://www.viator.com/tours/Reykjavik/Reykjavik-Northern-Lights-Tour-with-Pro-Aurora-Photos-Small-Group/d905-380422P1)

---

</div>



<div style="margin:20px 0;padding:16px;background:#fafbfc;border-radius:12px;border:1px solid #e8ecf0">
<p style="margin:0 0 10px;font-weight:600;font-size:15px;color:#374151">📌 More about Reykjavik</p>
<div style="display:flex;flex-wrap:wrap;gap:4px">
<a href="https://visafree.techpawz.com/posts/iceland-visa-free/" style="display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:#f0f7ff;border:1px solid #d0e3ff;border-radius:8px;text-decoration:none;color:#1a56db;font-size:14px;margin:4px">🛂 Iceland visa requirements</a>
<a href="https://visa.techpawz.com/posts/visa-policy-iceland/" style="display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:#f0f7ff;border:1px solid #d0e3ff;border-radius:8px;text-decoration:none;color:#1a56db;font-size:14px;margin:4px">📋 Iceland visa policy</a>
<a href="https://esim.techpawz.com/posts/esim-iceland/" style="display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:#f0f7ff;border:1px solid #d0e3ff;border-radius:8px;text-decoration:none;color:#1a56db;font-size:14px;margin:4px">📱 Iceland eSIM plans</a>
</div>
</div>


