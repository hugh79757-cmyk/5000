---
title: "New Zealand Passport: Travel Freedom and Visa Requirements"
slug: 'new-zealand-visa-free'
date: '2026-04-12T17:20:58+09:00'
draft: false
featureimage: "https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/new-zealand-visa-free/cover.jpg"
---

## New Zealand Passport: Travel Freedom Overview

New Zealand passport holders enjoy a significant degree of travel freedom, with access to a total of 198 destinations worldwide. This includes 116 countries that offer visa-free access, allowing New Zealanders to travel without the need for a visa for various durations. Additionally, there are 39 countries where a visa can be obtained upon arrival, and 20 countries that provide an e-Visa option. This comprehensive guide will explore the various travel options available to New Zealand passport holders, detailing visa-free destinations, countries offering visas on arrival, e-Visa and ETA destinations, as well as those requiring a traditional visa.

## Visa-Free Destinations

![new-zealand-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/new-zealand-visa-free/body_2.jpg)


New Zealand passport holders can travel to a wide range of countries without the need for a visa. These destinations can be categorized based on the duration of stay permitted without a visa.

### Visa-Free for 360 Days

- Georgia

### Visa-Free for 180 Days

- [Antigua and Barbuda](https://visa.techpawz.com/posts/visa-policy-antigua-and-barbuda/)
- Armenia
- Barbados
- Costa Rica
- [Dominica](https://visa.techpawz.com/posts/visa-dominica-passport/)
- El Salvador
- Mexico
- Peru

### Visa-Free for 90 Days

- Albania
- Andorra
- Argentina
- Austria
- Bahamas
- Belgium
- Bolivia
- [Bosnia and Herzegovina](https://visa.techpawz.com/posts/visa-policy-bosnia-and-herzegovina/)
- Botswana
- Brazil
- Bulgaria
- Chile
- Colombia
- Croatia
- Cyprus
- Czech Republic
- Denmark
- Ecuador
- Estonia
- Finland
- France
- Gambia
- Germany
- Greece
- Grenada
- Guatemala
- Guyana
- Haiti
- Honduras
- Hong Kong
- Hungary
- Iceland
- Ireland
- Israel
- Italy
- Japan
- Kiribati
- Kosovo
- Latvia
- Liechtenstein
- Lithuania
- Luxembourg
- Macao
- Malaysia
- Malta
- Mauritius
- Moldova
- Monaco
- Montenegro
- Morocco
- Namibia
- Netherlands
- Nicaragua
- North Macedonia
- Norway
- Oman
- Panama
- Paraguay
- Poland
- Portugal
- Romania
- Saint Kitts and Nevis
- Saint Vincent and the Grenadines
- San Marino
- Serbia
- Seychelles
- Singapore
- Slovakia
- Slovenia
- South Africa
- South Korea
- Spain
- Sweden
- Switzerland
- Taiwan
- Tunisia
- Turkey
- Ukraine
- Uruguay
- Vatican
- Venezuela
- Zambia

### Visa-Free for 60 Days

- Kyrgyzstan
- Thailand

### Visa-Free for 42 Days

- Saint Lucia

### Visa-Free for 30 Days

- Angola
- Belarus
- Brunei
- China
- Kazakhstan
- Malawi
- Micronesia
- Mongolia
- Philippines
- Rwanda
- Swaziland
- Tajikistan
- United Arab Emirates
- Uzbekistan

### Visa-Free for 14 Days

- Lesotho

### Visa-Free for 120 Days

- Fiji
- Vanuatu

### Visa-Free Countries

- Australia
- Belize
- Dominican Republic
- Jamaica
- Palestine

## Visa on Arrival Countries

![new-zealand-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/new-zealand-visa-free/body_3.jpg)


In addition to visa-free travel, New Zealand passport holders can obtain a visa upon arrival in 39 countries. This option provides flexibility for travelers who may not have secured a visa prior to their journey. The countries where a visa can be obtained upon arrival include:

- Bahrain
- Bangladesh
- Burkina Faso
- Burundi
- Cambodia
- Cape Verde
- Comoros
- Djibouti
- Egypt
- Ethiopia
- Ghana
- Guinea-Bissau
- Indonesia
- Iran
- Iraq
- Jordan
- Kuwait
- Laos
- Lebanon
- Madagascar
- Maldives
- Marshall Islands
- Mauritania
- Mozambique
- Nepal
- Palau
- Qatar
- Samoa
- Saudi Arabia
- Senegal
- Sierra Leone
- Solomon Islands
- Sri Lanka
- Tanzania
- Timor-Leste
- Tonga
- Trinidad and Tobago
- Tuvalu
- Zimbabwe

## e-Visa and ETA Destinations

![new-zealand-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/new-zealand-visa-free/body_4.jpg)


New Zealand passport holders can also take advantage of e-Visa options and Electronic Travel Authorizations (ETA) for certain countries. This process typically involves applying online before travel, making it a convenient option for many travelers. The countries offering e-Visa options include:

- Azerbaijan
- Benin
- Bhutan
- Cameroon
- Cuba
- DR Congo
- Equatorial Guinea
- Gabon
- Guinea
- India
- Libya
- Myanmar
- Nigeria
- Sao Tome and Principe
- Somalia
- South Sudan
- Syria
- Togo
- Uganda
- Vietnam

Additionally, there are seven countries that require an ETA for entry:

- Canada
- Ivory Coast
- Kenya
- Pakistan
- Papua New Guinea
- United Kingdom
- United States

## Countries Requiring a Traditional Visa

![new-zealand-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/new-zealand-visa-free/body_5.jpg)


While New Zealand passport holders enjoy extensive travel freedom, there are still some countries that require a traditional visa for entry. The following 16 countries necessitate obtaining a visa prior to travel:

- [Afghanistan](https://visa.techpawz.com/posts/visa-policy-afghanistan/)
- Algeria
- Central African Republic
- Chad
- Congo
- Eritrea
- Liberia
- Mali
- Nauru
- Niger
- North Korea
- Russia
- Sudan
- Suriname
- Turkmenistan
- Yemen

## Tips for New Zealand Passport Holders

![new-zealand-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/new-zealand-visa-free/body_6.jpg)


When planning international travel, New Zealand passport holders should keep several tips in mind to ensure a smooth journey. First, it is essential to check the specific entry requirements for each destination, as regulations can change frequently. This includes verifying the duration of stay allowed without a visa, as well as any additional documentation that may be required upon arrival.

Travelers should also consider obtaining travel insurance to cover unexpected events, such as medical emergencies or trip cancellations. Additionally, it is advisable to keep a copy of important documents, including the passport and any visas or travel authorizations, in a secure location separate from the originals.

Finally, staying informed about the local customs and regulations of the destination country can enhance the travel experience and help avoid any misunderstandings or issues during the trip. By following these guidelines, New Zealand passport holders can make the most of their travel opportunities around the world.
