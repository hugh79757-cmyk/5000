---
title: "Bosnia and Herzegovina Passport: Travel Freedom Guide"
date: 2026-04-24T16:49:47+09:00
description: "Complete visa requirements guide for Bosnia and Herzegovina: visa-free countries, visa on arrival, e-visa, and more."
featureimage: "https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/bosnia-and-herzegovina-visa-free/cover.jpg"
featureimagecredit: "Photo by [Alan Wang](https://www.pexels.com/@alankrantas) on [Pexels](https://www.pexels.com)"
tags:
  - "Bosnia and Herzegovina"
  - "Visa Requirements"
  - "Passport"
  - "Travel Documents"
  - "Visa Free"
categories:
  - "Visa-Free Travel"
showTableOfContents: true
---

Photo by [Alan Wang](https://www.pexels.com/@alankrantas) on [Pexels](https://www.pexels.com)

Traveling with a [Bosnia and Herzegovina](https://visa.techpawz.com/posts/visa-policy-bosnia-and-herzegovina/) passport offers a range of possibilities for exploring various countries around the world. With a total of 198 destinations available, passport holders can enjoy varying degrees of access, including visa-free entry, visa on arrival, and e-visa options. This guide aims to provide A Practical overview of where Bosnia and Herzegovina passport holders can travel, detailing the requirements and opportunities available.


<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8772455780561463"
     crossorigin="anonymous"></script>
<!-- ETAP -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8772455780561463"
     data-ad-slot="4276065235"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

## Bosnia and Herzegovina Passport: Travel Freedom Overview

Bosnia and Herzegovina passport holders enjoy significant travel freedom, with access to 74 countries without the need for a visa. Additionally, there are 34 countries where travelers can obtain a visa upon arrival, and 37 countries that offer e-visa options. This variety allows for flexibility and convenience when planning international trips. However, there are also 50 countries that require a traditional visa prior to travel, which necessitates careful planning and preparation.

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/bosnia-and-herzegovina-visa-free/body_1.jpg)
*Photo by [Antonio  Tose](https://www.pexels.com/@antonio-tose-298756153) on [Pexels](https://www.pexels.com)*


## Visa-Free Destinations

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8772455780561463"
     crossorigin="anonymous"></script>
<!-- ETAP -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8772455780561463"
     data-ad-slot="4276065235"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/bosnia-and-herzegovina-visa-free/body_2.jpg)
*Photo by [Antonio  Tose](https://www.pexels.com/@antonio-tose-298756153) on [Pexels](https://www.pexels.com)*



Visa-free travel is one of the most appealing aspects of holding a Bosnia and Herzegovina passport. The following sections categorize the visa-free destinations based on the duration of stay allowed.

### Visa-Free for 90 Days

Bosnia and Herzegovina passport holders can travel visa-free for up to 90 days in the following countries:

Albania, Andorra, Argentina, Austria, Azerbaijan, Belgium, Brazil, Bulgaria, Chile, China, Colombia, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Estonia, Finland, France, Gambia, Germany, Greece, Haiti, Hungary, Iceland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg, Macao, Malaysia, Malta, Moldova, Monaco, Montenegro, Netherlands, North Macedonia, Norway, Panama, Poland, Portugal, Romania, Saint Vincent and the Grenadines, San Marino, Serbia, Seychelles, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tunisia, Turkey, Vatican.

### Visa-Free for 60 Days

Kyrgyzstan allows Bosnia and Herzegovina passport holders to stay for up to 60 days without a visa.

### Visa-Free for 42 Days

Saint Lucia offers a visa-free stay for 42 days.

### Visa-Free for 30 Days

The following countries permit a 30-day visa-free stay:

Belarus, Micronesia, Russia, Singapore, Swaziland, Tajikistan, Trinidad and Tobago, Ukraine, Uzbekistan.

### Visa-Free for 21 Days

[Dominica](https://visa.techpawz.com/posts/visa-dominica-passport/) allows a 21-day visa-free entry.

### Visa-Free for 15 Days

Iran permits a 15-day visa-free stay.

### Visa-Free for 14 Days

Hong Kong grants a 14-day visa-free access.

### Visa-Free for 360 Days

Georgia offers an extended visa-free stay of 360 days.

### Visa-Free Countries with Special Status

Additionally, the [Dominican Republic](https://visa.techpawz.com/posts/visa-policy-dominican-republic/), Grenada, and Palestine are also accessible without a visa for Bosnia and Herzegovina passport holders.

## Visa on Arrival Countries

For those who prefer the convenience of obtaining a visa upon arrival, there are 34 countries available to Bosnia and Herzegovina passport holders. The following countries allow entry with a visa on arrival:

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/bosnia-and-herzegovina-visa-free/body_3.jpg)
*Photo by [Antonio  Tose](https://www.pexels.com/@antonio-tose-298756153) on [Pexels](https://www.pexels.com)*


Armenia, Bangladesh, Bolivia, Burundi, Cambodia, Cape Verde, Comoros, Djibouti, Ethiopia, Ghana, Guinea-Bissau, Indonesia, Jamaica, Jordan, Laos, Madagascar, Malawi, Maldives, Marshall Islands, Mauritania, Mauritius, Mozambique, Nepal, Palau, Qatar, Rwanda, Samoa, Sri Lanka, Tanzania, Timor-Leste, Tuvalu, United Arab Emirates, Zambia, Zimbabwe.

## e-Visa and ETA Destinations

E-visas and Electronic Travel Authorizations (ETAs) provide another convenient option for Bosnia and Herzegovina passport holders. The following countries offer e-visa or ETA options:

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/bosnia-and-herzegovina-visa-free/body_4.jpg)
*Photo by [Muhammed Fatih Beki](https://www.pexels.com/@mfbeki) on [Pexels](https://www.pexels.com)*


### e-Visa Countries

Bosnia and Herzegovina passport holders can apply for an e-visa to the following 37 countries:

[Antigua and Barbuda](https://visa.techpawz.com/posts/visa-policy-antigua-and-barbuda/), Australia, Bahamas, Bahrain, Benin, Bhutan, Botswana, Burkina Faso, Cameroon, DR Congo, Egypt, El Salvador, Equatorial Guinea, Gabon, Guinea, India, Iraq, Kazakhstan, Lesotho, Libya, Mongolia, Myanmar, Nigeria, Oman, Pakistan, Papua New Guinea, Saint Kitts and Nevis, Sao Tome and Principe, Sierra Leone, Somalia, South Sudan, Syria, Taiwan, Thailand, Togo, Uganda, Vietnam.

### ETA Countries

Bosnia and Herzegovina passport holders can also obtain an ETA for travel to:

Ivory Coast, Kenya, South Korea.

## Countries Requiring a Traditional Visa

While there are many opportunities for visa-free travel, Bosnia and Herzegovina passport holders should be aware that there are 50 countries that require a traditional visa before entering. These countries include:

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/bosnia-and-herzegovina-visa-free/body_5.jpg)
*Photo by [Drago Rapovac](https://www.pexels.com/@drago-rapovac-167144988) on [Pexels](https://www.pexels.com)*


Afghanistan, Algeria, Angola, Barbados, Belize, Brunei, Canada, [Central African Republic](https://visa.techpawz.com/posts/visa-policy-central-african-republic/), Chad, Congo, Costa Rica, Eritrea, Fiji, Guatemala, Guyana, Honduras, Ireland, Israel, Japan, Kiribati, Kosovo, Kuwait, Lebanon, Liberia, Mali, Mexico, Morocco, Namibia, Nauru, New Zealand, Nicaragua, Niger, North Korea, Paraguay, Peru, Philippines, Saudi Arabia, Senegal, Solomon Islands, South Africa, Sudan, Suriname, Tonga, Turkmenistan, United Kingdom, United States, Uruguay, Vanuatu, Venezuela, Yemen.

## Tips for Bosnia and Herzegovina Passport Holders

When planning international travel, Bosnia and Herzegovina passport holders should consider a few essential tips to ensure a smooth journey. First, always check the specific entry requirements for each destination, as they can vary significantly. This includes understanding the duration of stay allowed, any necessary documentation, and potential fees associated with visas or entry permits.

![Photo](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/bosnia-and-herzegovina-visa-free/body_6.jpg)
*Photo by [Antonio  Tose](https://www.pexels.com/@antonio-tose-298756153) on [Pexels](https://www.pexels.com)*


It is also advisable to keep abreast of any travel advisories or updates related to the countries you plan to visit. This information can be crucial for ensuring safety and compliance with local regulations. Additionally, having a valid passport with sufficient validity beyond your intended stay is essential, as many countries require a passport to be valid for at least six months from the date of entry.

Lastly, consider travel insurance to cover any unforeseen circumstances during your trip. This can provide peace of mind and financial protection in case of emergencies.

 the Bosnia and Herzegovina passport opens up a wide range of travel opportunities, from visa-free destinations to those offering visas on arrival and e-visa options. By understanding the requirements and planning accordingly, passport holders can enjoy their travels with greater ease and confidence.
<div class="etap-disclaimer-card">

> **📌 Disclaimer**
>
> Prices, schedules, tour details, flight routes, visa requirements, and all other information on this page are based on data **at the time of writing**. Fares, availability, and policies may change. Please verify current details on the official website before booking.

</div>


<div class="etap-product-cards">
<h2 class="etap-card-title">Top Tours &amp; Activities</h2>

[![Bosnia and Herzegovina eSIM - 1 GB Bosnia and Herzegovina travel eSIM valid for 7 days](https://cdn.airalo.com/images/9fd07480-33ff-4fc1-95fd-c98d4f4bdbc9.jpg)](https://airalo.pxf.io/c/1209822/1923897/15608?prodsku=7576&u=https%3A%2F%2Fwww.airalo.com%2Fbosnia-and-herzegovina-esim%2Fbosher-7days-1gb&intsrc=CATF_15506)

**[Bosnia and Herzegovina eSIM - 1 GB Bosnia and Herzegovina travel eSIM valid for 7 days](https://airalo.pxf.io/c/1209822/1923897/15608?prodsku=7576&u=https%3A%2F%2Fwww.airalo.com%2Fbosnia-and-herzegovina-esim%2Fbosher-7days-1gb&intsrc=CATF_15506)**

_eSIM_

From **$4**

[Book Now](https://airalo.pxf.io/c/1209822/1923897/15608?prodsku=7576&u=https%3A%2F%2Fwww.airalo.com%2Fbosnia-and-herzegovina-esim%2Fbosher-7days-1gb&intsrc=CATF_15506)

---

[![Sarajevo Walking Tour](https://media-cdn.tripadvisor.com/media/attractions-splice-spp-360x240/r/32/b7/9e/f6/caption.jpg)](https://www.viator.com/tours/Sarajevo/Sarajevo-Walking-Tour/d22427-5645326P3)

**[Sarajevo Walking Tour](https://www.viator.com/tours/Sarajevo/Sarajevo-Walking-Tour/d22427-5645326P3)**

_Archaeology Tours_

From **$16**

[Book Now](https://www.viator.com/tours/Sarajevo/Sarajevo-Walking-Tour/d22427-5645326P3)

---

</div>



<div style="margin:20px 0;padding:16px;background:#fafbfc;border-radius:12px;border:1px solid #e8ecf0">
<p style="margin:0 0 10px;font-weight:600;font-size:15px;color:#374151">📌 More about Bosnia and Herzegovina</p>
<div style="display:flex;flex-wrap:wrap;gap:4px">
<a href="https://visa.techpawz.com/posts/visa-policy-bosnia-and-herzegovina/" style="display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:#f0f7ff;border:1px solid #d0e3ff;border-radius:8px;text-decoration:none;color:#1a56db;font-size:14px;margin:4px">📋 Bosnia and Herzegovina visa policy</a>
</div>
</div>


