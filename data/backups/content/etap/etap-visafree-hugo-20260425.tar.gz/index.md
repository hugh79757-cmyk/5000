---
title: "Mexico Passport: Travel Freedom Guide"
slug: 'mexico-visa-free'
date: '2026-04-17T09:41:41+09:00'
draft: false
featureimage: "https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/mexico-visa-free/cover.jpg"
---

## Mexico Passport: Travel Freedom Overview

Holders of a Mexico passport enjoy a significant degree of travel freedom, with access to a total of 198 destinations worldwide. This includes 98 countries that allow visa-free entry, 33 countries that offer a visa on arrival, and 31 countries that provide an e-Visa option. This extensive range of travel possibilities makes the Mexico passport a valuable asset for international travel.

## Visa-Free Destinations

![mexico-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/mexico-visa-free/body_2.jpg)


Mexico passport holders can travel to a variety of countries without the need for a visa. These destinations are categorized based on the duration of stay allowed without a visa.

### Visa-Free for 90 Days

The following countries permit stays of up to 90 days without a visa:

- Albania
- Andorra
- Argentina
- Austria
- Bahamas
- Belgium
- Bolivia
- [Bosnia and Herzegovina](https://visa.techpawz.com/posts/visa-policy-bosnia-and-herzegovina/)
- Botswana
- Brazil
- Bulgaria
- Chile
- Colombia
- Croatia
- Cyprus
- [Czech Republic](https://visa.techpawz.com/posts/visa-policy-czech-republic/)
- Denmark
- Ecuador
- Estonia
- Finland
- France
- Germany
- Greece
- Grenada
- Guatemala
- Haiti
- Honduras
- Hong Kong
- Hungary
- Iceland
- Ireland
- Israel
- Italy
- Jamaica
- Japan
- Kiribati
- Kosovo
- Latvia
- Liechtenstein
- Lithuania
- Luxembourg
- Macao
- Malta
- Mauritius
- Moldova
- Monaco
- Montenegro
- Morocco
- Netherlands
- Nicaragua
- North Macedonia
- Norway
- Panama
- Paraguay
- Poland
- Portugal
- Romania
- Saint Kitts and Nevis
- Saint Vincent and the Grenadines
- San Marino
- Serbia
- Seychelles
- Slovakia
- Slovenia
- Spain
- Sweden
- Switzerland
- Trinidad and Tobago
- Tunisia
- Uruguay
- Vatican
- Venezuela

### Visa-Free for 60 Days

Mexico passport holders can stay for up to 60 days in:

- Kyrgyzstan
- Thailand

### Visa-Free for 42 Days

Saint Lucia allows a visa-free stay for 42 days.

### Visa-Free for 30 Days

The following countries permit stays of up to 30 days without a visa:

- Angola
- Belarus
- Belize
- Kazakhstan
- Malaysia
- Micronesia
- Philippines
- Singapore
- Tajikistan
- Uzbekistan

### Visa-Free for 28 Days

Barbados allows a stay of 28 days without a visa.

### Visa-Free for 180 Days

The following countries permit stays of up to 180 days:

- [Antigua and Barbuda](https://visa.techpawz.com/posts/visa-policy-antigua-and-barbuda/)
- Costa Rica
- [Dominica](https://visa.techpawz.com/posts/visa-dominica-passport/)
- El Salvador
- Peru
- United Arab Emirates

### Visa-Free for 120 Days

Fiji and Vanuatu allow stays of up to 120 days without a visa.

### Visa-Free for 15 Days

Iran permits a visa-free stay for 15 days.

### Visa-Free for 360 Days

Georgia allows a visa-free stay for up to 360 days.

### Visa-Free Countries

Additionally, Mexico passport holders can visit the Dominican Republic and Palestine without a visa.

## Visa on Arrival Countries

![mexico-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/mexico-visa-free/body_3.jpg)


There are 33 countries where Mexico passport holders can obtain a visa upon arrival. This option provides flexibility for travelers who may not have secured a visa in advance. The countries offering this convenience include:

- Armenia
- Bahrain
- Burundi
- Cambodia
- Cape Verde
- Comoros
- Djibouti
- Egypt
- Ethiopia
- Ghana
- Guinea-Bissau
- Indonesia
- Jordan
- Laos
- Lebanon
- Madagascar
- Malawi
- Maldives
- Marshall Islands
- Mauritania
- Mozambique
- Namibia
- Nepal
- Palau
- Qatar
- Rwanda
- Samoa
- Sri Lanka
- Tanzania
- Timor-Leste
- Tuvalu
- Zambia
- Zimbabwe

## e-Visa and ETA Destinations

![mexico-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/mexico-visa-free/body_4.jpg)


Mexico passport holders can also take advantage of e-Visas and Electronic Travel Authorizations (ETAs) for easier entry into certain countries. The following countries offer e-Visas:

- Australia
- Azerbaijan
- Benin
- Bhutan
- Burkina Faso
- Cameroon
- Cuba
- DR Congo
- Equatorial Guinea
- Gabon
- Guinea
- India
- Iraq
- Lesotho
- Libya
- Mongolia
- Myanmar
- Nigeria
- Oman
- Pakistan
- Russia
- Sao Tome and Principe
- Sierra Leone
- Somalia
- South Africa
- South Sudan
- Syria
- Togo
- Turkey
- Uganda
- Vietnam

In addition, there are six countries that require an ETA for entry:

- Ivory Coast
- Kenya
- New Zealand
- Papua New Guinea
- South Korea
- United Kingdom

## Countries Requiring a Traditional Visa

![mexico-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/mexico-visa-free/body_5.jpg)


Despite the extensive travel options available, there are still 30 countries that require a traditional visa for entry. Mexico passport holders must secure a visa before traveling to these destinations. The countries that require a visa include:

- Afghanistan
- Algeria
- Bangladesh
- Brunei
- Canada
- [Central African Republic](https://visa.techpawz.com/posts/visa-policy-central-african-republic/)
- Chad
- China
- Congo
- Eritrea
- Gambia
- Guyana
- Kuwait
- Liberia
- Mali
- Nauru
- Niger
- North Korea
- Saudi Arabia
- Senegal
- Solomon Islands
- Sudan
- Suriname
- Swaziland
- Taiwan
- Tonga
- Turkmenistan
- Ukraine
- United States
- Yemen

## Tips for Mexico Passport Holders

![mexico-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/mexico-visa-free/body_6.jpg)


When traveling internationally, Mexico passport holders should keep several tips in mind to ensure a smooth journey. First, it is essential to check the specific entry requirements for each destination, as these can vary widely. While many countries offer visa-free access, others may have additional stipulations, such as proof of onward travel or sufficient funds for the duration of the stay.

It is also advisable to keep copies of important documents, such as the passport and any visas, in case of loss or theft. Familiarizing oneself with local customs and regulations can enhance the travel experience and help avoid misunderstandings.

Lastly, consider registering with the local Mexican embassy or consulate upon arrival in a foreign country. This can provide an additional layer of security and assistance in case of emergencies.

the Mexico passport offers a diverse range of travel opportunities across the globe. With careful planning and awareness of visa requirements, travelers can make the most of their international journeys.
