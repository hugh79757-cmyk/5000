---
title: "United States Passport: Visa Requirements Guide"
slug: 'united-states-visa-free'
date: '2026-04-12T17:31:16+09:00'
draft: false
featureimage: "https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/united-states-visa-free/cover.jpg"
---

## United States Passport: Travel Freedom Overview

United States passport holders enjoy a significant level of travel freedom, with access to a total of 198 destinations worldwide. This includes 116 countries that offer visa-free access, 36 countries where a visa can be obtained upon arrival, and 20 countries that provide an e-Visa option. This guide will detail the various visa requirements and travel options available for U.S. citizens, ensuring a smooth travel experience.

## Visa-Free Destinations

![united-states-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/united-states-visa-free/body_2.jpg)


Visa-free travel allows U.S. passport holders to enter a country without the need for a visa, simplifying the travel process. The countries are categorized based on the duration of stay permitted without a visa.

### Visa-Free for 90 Days (72 countries)

U.S. citizens can travel visa-free for up to 90 days in the following countries:

Andorra, Argentina, Austria, Belgium, [Bosnia and Herzegovina](https://visa.techpawz.com/posts/visa-policy-bosnia-and-herzegovina/) , Botswana, Brazil, Brunei, Bulgaria, Chile, Croatia, Cyprus, Czech Republic, Denmark, Ecuador, Estonia, Finland, France, Germany, Greece, Grenada, Guatemala, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, Ireland, Israel, Italy, Japan, Kiribati, Kosovo, Latvia, Liechtenstein, Lithuania, Luxembourg, Malta, Mauritius, Moldova, Monaco, Mongolia, Montenegro, Morocco, Namibia, Netherlands, Nicaragua, North Macedonia, Norway, Paraguay, Poland, Portugal, Qatar, Romania, San Marino, Senegal, Serbia, Seychelles, Slovakia, Slovenia, South Africa, South Korea, Spain, Sweden, Switzerland, Taiwan, Trinidad and Tobago, Ukraine, Uruguay, Vatican, Zambia.

### Visa-Free for 60 Days (2 countries)

U.S. passport holders can stay for up to 60 days in:

Kyrgyzstan, Thailand.

### Visa-Free for 42 Days (1 country)

Saint Lucia allows a visa-free stay for 42 days.

### Visa-Free for 30 Days (11 countries)

The following countries permit a 30-day visa-free stay:

Angola, Cape Verde, Kazakhstan, Macao, Malawi, Micronesia, Mozambique, Philippines, Swaziland, Tajikistan, United Arab Emirates.

### Visa-Free for 180 Days (14 countries)

U.S. citizens can enjoy a 180-day visa-free stay in:

[Antigua and Barbuda](https://visa.techpawz.com/posts/visa-policy-antigua-and-barbuda/) , Armenia, Barbados, Belize, Canada, Costa Rica, [Dominica](https://visa.techpawz.com/posts/visa-dominica-passport/) , El Salvador, Jamaica, Mexico, Panama, Peru, Saint Kitts and Nevis, Saint Vincent and the Grenadines.

### Visa-Free for 240 Days (1 country)

The Bahamas offers a 240-day visa-free stay for U.S. passport holders.

### Visa-Free for 120 Days (3 countries)

Fiji, Tunisia, and Vanuatu allow for a 120-day visa-free stay.

### Visa-Free for 15 Days (1 country)

Sao Tome and Principe permits a 15-day visa-free stay.

## Visa on Arrival Countries

![united-states-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/united-states-visa-free/body_3.jpg)


For 36 countries, U.S. passport holders can obtain a visa upon arrival. This option provides flexibility for travelers who may not have secured a visa in advance. The countries where a visa on arrival is available include:

Bahrain, Bangladesh, Bolivia, Burkina Faso, Burundi, Cambodia, Comoros, Djibouti, Egypt, Ethiopia, Gambia, Ghana, Guinea-Bissau, Indonesia, Iraq, Jordan, Kuwait, Laos, Lebanon, Madagascar, Maldives, Mauritania, Nepal, Oman, Rwanda, Samoa, Saudi Arabia, Sierra Leone, Solomon Islands, Somalia, Sri Lanka, Tanzania, Timor-Leste, Tonga, Tuvalu, Zimbabwe.

## e-Visa and ETA Destinations

![united-states-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/united-states-visa-free/body_4.jpg)


The e-Visa system allows U.S. passport holders to apply for a visa online before traveling. This option is available for 20 countries, making it convenient for travelers. The countries offering e-Visas include:

[Azerbaijan](https://visa.techpawz.com/posts/visa-policy-azerbaijan/) , Benin, Bhutan, Cameroon, China, Cuba, DR Congo, Equatorial Guinea, Gabon, Guinea, India, Libya, Myanmar, Nigeria, South Sudan, Syria, Togo, Uganda, Uzbekistan, Vietnam.

Additionally, there are 7 countries that require an Electronic Travel Authorization (ETA) for entry:

Australia, Ivory Coast, Kenya, New Zealand, Pakistan, Papua New Guinea, United Kingdom.

## Countries Requiring a Traditional Visa

![united-states-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/united-states-visa-free/body_5.jpg)


While the United States passport offers extensive travel options, there are still 19 countries that require a traditional visa prior to arrival. U.S. citizens must ensure they obtain the necessary visas for travel to these countries:

[Afghanistan](https://visa.techpawz.com/posts/visa-policy-afghanistan/) , Algeria, Belarus, Central African Republic, Chad, Congo, Eritrea, Iran, Liberia, Mali, Nauru, Niger, North Korea, Russia, Sudan, Suriname, Turkmenistan, Venezuela, Yemen.

## Tips for United States Passport Holders

![united-states-visa-free](https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/etap/united-states-visa-free/body_6.jpg)


When planning international travel, U.S. passport holders should keep several tips in mind to ensure a smooth journey. First, always check the specific entry requirements for your destination well in advance of your trip. This includes understanding whether a visa is needed and the duration of stay permitted.

It’s also advisable to keep a copy of your passport and any required visas in a safe place, separate from the originals. This can be helpful in case of loss or theft. Additionally, consider registering with the Smart Traveler Enrollment Program (STEP) to receive important updates and assistance from the U.S. embassy or consulate while abroad.

Travel insurance is another important consideration. It can provide coverage for unexpected events such as medical emergencies, trip cancellations, or lost belongings. Lastly, familiarize yourself with local customs and laws in your destination country to ensure a respectful and enjoyable experience.

U.S. passport holders have access to a wide range of travel options, with many countries offering visa-free entry or simplified visa processes. By understanding the requirements and preparing accordingly, travelers can make the most of their international journeys.
