---
title: "글 목록"
description: "KBO 선수별 타율 ERA 성적 순위와 시즌 기록 추적"
---
