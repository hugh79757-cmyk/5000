---
title: "전남 강진 무위사 선각대사탑의 역사와 건축적 가치 해설"
slug: '전남-강진-무위사-선각대사탑의-역사와-건축적-가치-해설'
date: '2026-04-20T07:12:02+09:00'
draft: false
description: "전남 보물 서각류 — 강진 무위사 선각대사탑비. 1곳 정보와 방문 팁 정리."
tags: ['전남', '보물 서각류']
categories: ['보물 서각류']
featureimage: "https://www.khs.go.kr/unisearch/images/treasure/1619240.jpg"
---

## 강진 무위사 선각대사탑비의 역사와 배경

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B0%95%EC%A7%84%20%EB%AC%B4%EC%9C%84%EC%82%AC%20%EC%84%A0%EA%B0%81%EB%8C%80%EC%82%AC%ED%83%91%EB%B9%84" target="_blank" rel="nofollow">강진 무위사 선각대사탑비 네이버 지도에서 보기</a>


![강진 무위사 선각대사탑비](https://www.khs.go.kr/unisearch/images/treasure/1619240.jpg)


전남 강진군 성전면에 위치한 강진 무위사 선각대사탑비는 고려시대에 세워진 중요한 문화유산으로, 1969년 6월 16일 보물 제507호로 지정되었습니다. 이 탑비는 신라 말의 명승인 선각대사 형미(逈微)를 기리기 위해 건립된 것으로, 고려 정종 원년인 946년에 세워졌습니다. 무위사는 원래 신라의 명승 원효에 의해 창건되었으며, 후에 태감에 의해 무위사라는 이름으로 다시 세워졌습니다. 이 시기는 고려 태조 왕건이 통일신라를 계승하고, 새로운 정치 및 문화적 기반을 다지던 시기로, 불교가 국가의 중요한 이념으로 자리 잡고 있던 때입니다. 선각대사는 당나라에 14년간 유학한 후 귀국하여 무위사에서 8년간 머물며 불교의 진리를 전파한 인물로, 그의 죽음 이후 28년 만에 이 비가 세워졌습니다. 이 탑비는 선각대사의 업적을 기리며, 고려시대 불교 문화의 발달을 보여주는 중요한 증거로 평가받고 있습니다.

## 강진 무위사 선각대사탑비의 건축적·예술적 특징

강진 무위사 선각대사탑비는 비받침, 비몸돌, 머릿돌로 구성된 완전한 형태를 갖추고 있습니다. 비받침은 거북의 몸체와 여의주를 물고 있는 용의 머리를 형상화하여, 사실성이 뚜렷하게 드러납니다. 비몸에는 선각대사에 관한 기록이 새겨져 있으며, 최언위가 비문을 짓고 유훈율이 해서로 쓴 기록이 남아 있습니다. 비좌(碑座)에는 구름무늬와 둥근 형태의 조각이 새겨져 있어, 당시의 조각 기법을 잘 보여줍니다. 비의 전체적인 크기는 약 2.5m로, 고려시대의 다른 탑비들과 비교했을 때, 조각의 세밀함과 사실성이 특히 두드러집니다. 머릿돌은 3단의 받침 위에 연꽃무늬가 새겨져 있으며, 중앙에 비의 이름이 새겨진 공간이 있지만 마멸되어 글씨는 알아볼 수 없습니다. 이러한 요소들은 고려시대 불교 조각의 양식과 기법을 잘 보여주며, 같은 시대의 다른 서각류 유산들과 비교할 때, 예술적 가치가 높습니다.

## 방문 안내

강진 무위사 선각대사탑비는 전라남도 강진군 성전면 무위사로 308에 위치해 있습니다. 무위사는 월출산 동남쪽에 자리하고 있어, 자연 경관이 아름다운 지역입니다. 방문하기 위해서는 대중교통을 이용할 경우, 강진 시내에서 버스를 타고 무위사 방향으로 이동할 수 있습니다. 사찰 내부에 위치하고 있으며, 주변에는 다양한 불교 유적들이 있어 함께 관람할 수 있는 기회가 많습니다. 관람 시 유의사항으로는 비석에 직접 손을 대지 않는 것이며, 조용한 관람을 부탁드립니다. 또한, 사찰 내부에서의 사진 촬영은 제한될 수 있으니 사전에 확인하시기 바랍니다.

## 강진 무위사 선각대사탑비의 가치와 의미

강진 무위사 선각대사탑비는 역사적, 문화적, 학술적 가치가 매우 높은 유산입니다. 보물 제507호로 지정된 이 탑비는 고려시대 불교문화의 중요한 증거로, 선각대사의 업적을 기리는 기념비로서 그 의미가 깊습니다. 비문에 새겨진 내용은 고려시대의 불교적 사상과 사회적 맥락을 이해하는 데 중요한 자료가 됩니다. 이 유산은 기록유산으로 분류되며, 서각류의 대표적인 예로서, 한국 문화유산 전체에서 중요한 위치를 차지하고 있습니다. 강진 무위사 선각대사탑비는 고려시대의 불교적 전통과 예술적 성취를 보여주는 중요한 유산으로, 후세에 전해지는 귀중한 문화유산입니다.

---

## 여행 준비에 도움되는 추천 용품

- [보바 그립 22.5W 고속충전 보조배터리 20000mAh](https://link.coupang.com/a/essKgO) — 40,900원
- [본트래커 초경량 접이식 듀랄루민7075 등산스틱 2개](https://link.coupang.com/a/essKkc) — 35,900원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>




<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>


<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/77/3537777_image2_1.jpg" alt="강진 백운동별서정원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">강진 백운동별서정원</strong><span class="nearby-card-addr">전라남도 강진군 성전면 월하안운길 100-63</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B0%95%EC%A7%84%20%EB%B0%B1%EC%9A%B4%EB%8F%99%EB%B3%84%EC%84%9C%EC%A0%95%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/07/3558407_image2_1.jpg" alt="강진다원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">강진다원</strong><span class="nearby-card-addr">전라남도 강진군 성전면 백운로 93-25</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B0%95%EC%A7%84%EB%8B%A4%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/72/2629772_image2_1.bmp" alt="녹향월촌마을" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">녹향월촌마을</strong><span class="nearby-card-addr">전라남도 강진군 성전면 달마지길 6</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%85%B9%ED%96%A5%EC%9B%94%EC%B4%8C%EB%A7%88%EC%9D%84" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/07/2823307_image2_1.jpg" alt="백운차실" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">백운차실</strong><span class="nearby-card-addr">전라남도 강진군 성전면 백운로 107</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%B0%B1%EC%9A%B4%EC%B0%A8%EC%8B%A4" target="_blank" rel="nofollow">지도에서 보기</a></div></div>