---
title: "광주 국보 탐방, 성거사지와 대곡리 청동기 유적 추천"
slug: '광주-국보-탐방-성거사지와-대곡리-청동기-유적-추천'
date: '2026-03-24T07:05:08+09:00'
draft: false
description: "광주 국보 탐방 — (전)광주 성거사지 오층석탑, 화순 대곡리 청동기 일괄, 노인 금계일기. 5곳 정보와 방문 팁 정리."
tags: ['광주', '국보 탐방', '국내여행']
categories: ['국내여행']
---

## 1.  국보 탐방 개요  

![(전)광주 성거사지 오층석탑](https://www.khs.go.kr/unisearch/images/treasure/1615465.jpg)

'광주광역시는 한국의 역사와 문화를 품고 있는 중요한 지역입니다.' 이곳에는 고려시대부터 조선시대까지 다양한 시대의 문화유산이 존재하며, 이들은 우리의 역사적 배경을 이해하는 데 큰 도움이 됩니다. 그중에서도 보물과 국보로 지정된 유산들은 특히 그 가치를 높이 평가받고 있습니다. 이번 탐방에서는 광주 지역의 국보 및 보물 중에서 세 가지 주요 문화유산을 살펴보겠습니다. 각각의 유산은 그 시대의 건축 양식과 역사적 의미를 담고 있으며, 방문객들에게 깊은 감동을 선사합니다. 또한 이들 문화유산은 지역 주민들에게 자부심을 주고, 관광객들에게는 한국의 전통 문화를 체험할 수 있는 기회를 제공합니다.

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>

## 2. 주요 문화유산 소개  

![화순 대곡리 청동기 일괄](https://www.khs.go.kr/unisearch/images/national_treasure/1612004.jpg)


### (전)광주 성거사지 오층석탑  

> [(전)광주 성거사지 오층석탑 네이버 지도에서 보기](https://map.naver.com/v5/search/%28%EC%A0%84%29%EA%B4%91%EC%A3%BC%20%EC%84%B1%EA%B1%B0%EC%82%AC%EC%A7%80%20%EC%98%A4%EC%B8%B5%EC%84%9D%ED%83%91)
(전)광주 성거사지 오층석탑은 고려전기(918-1392) 시대의 유산으로, 광주광역시 남구에 위치해 있습니다. 이 석탑은 보물 제109호로 지정되어 있으며, 높이는 약 7m에 달합니다. 전체적으로 양호한 상태를 유지하고 있으며, 석탑의 형태는 오층으로 되어 있어 그 시기의 건축 기술을 잘 보여줍니다. 이 탑은 불교의 신앙을 위한 장소로 사용되었으며, 고려시대의 종교적 신념을 반영하고 있습니다. 방문 주소는 광주광역시 남구 서오층석탑2길 17입니다.광주%20성거사지%20오층석탑)

### 화순 대곡리 청동기 일괄  

> [화순 대곡리 청동기 일괄 네이버 지도에서 보기](https://map.naver.com/v5/search/%ED%99%94%EC%88%9C%20%EB%8C%80%EA%B3%A1%EB%A6%AC%20%EC%B2%AD%EB%8F%99%EA%B8%B0%20%EC%9D%BC%EA%B4%84)
화순 대곡리 청동기 일괄은 국보 제143호로, 현재 국립광주박물관에 소장되어 있습니다. 이 유물은 청동기 시대의 주요 유물로, 총 11점으로 구성되어 있습니다. 이들 유물은 청동기 시대의 생활상을 보여주는 중요한 증거로 평가받고 있으며, 그 제작기술과 예술성에서도 높은 가치를 지닙니다. 이 유물들은 청동기 시대의 문화와 기술적 발전을 이해하는 데 중요한 역할을 하며, 그 역사적 의의는 매우 깊습니다. 방문 주소는 광주 북구 하서로 110에 위치한 국립광주박물관입니다.

### 노인 금계일기  

> [노인 금계일기 네이버 지도에서 보기](https://map.naver.com/v5/search/%EB%85%B8%EC%9D%B8%20%EA%B8%88%EA%B3%84%EC%9D%BC%EA%B8%B0)
노인 금계일기는 조선 선조 32년(1599)에 작성된 역사적 기록입니다. 이 전적류는 보물 제311호로 지정되어 있으며, 한 인물이 남긴 일기로서, 포로 생활의 어려움과 저항의 이야기를 담고 있습니다. 금계는 그 시기 일본으로 갈 수밖에 없었던 역사적 상황을 배경으로 하고 있으며, 이 문서는 한국 역사에서 중요한 사건을 증언하는 소중한 자료입니다. 노인 금계일기는 당시의 역사적 맥락을 이해하는 데 중요한 자료로 기능하며, 한국 문헌사에서도 중요한 위치를 차지하고 있습니다. 이 또한 국립광주박물관에 소장되어 있으며, 주소는 광주광역시 북구 하서로 110입니다.

## 3. 방문 안내와 관람 팁  

![노인 금계일기](https://www.khs.go.kr/unisearch/images/treasure/1615476.jpg)

광주 지역의 문화유산을 탐방하기 위해서는 먼저 대중교통을 이용하는 것이 편리합니다. (전)광주 성거사지 오층석탑은 광주광역시 남구에 위치하고 있으며, 대중교통으로 접근하기 용이합니다. 이후 화순 대곡리 청동기 일괄과 노인 금계일기는 국립광주박물관 내에 위치하므로, 성거사지 오층석탑에서 국립광주박물관까지 이동하는 경로를 택하면 좋습니다. 두 장소 간의 거리는 비교적 가까워, 도보로 이동할 수 있습니다. 관람 시 각 유산에 대한 설명을 면밀히 읽고, 관련된 역사적 배경을 미리 공부해 두면 더욱 의미 있는 시간을 보낼 수 있습니다. 또한, 특정 전시나 특별한 프로그램이 있을 경우, 사전에 확인하여 계획을 세우는 것이 좋습니다.

## 4. 문화유산의 가치와 의미  

![정지장군 갑옷](https://www.khs.go.kr/unisearch/images/treasure/1615477.jpg)

광주광역시의 문화유산은 단순한 유물이 아닌, 한국의 역사와 문화를 이해하는 중요한 매개체입니다. (전)광주 성거사지 오층석탑은 고려시대의 불교 신앙을 나타내는 중요한 유산이며, 화순 대곡리 청동기 일괄은 청동기 시대의 생활과 문화를 보여주는 필수적인 자료입니다. 노인 금계일기는 조선시대의 사회적 상황을 반영하며, 포로의 삶과 저항에 대한 기록으로 역사적 가치를 지닙니다. 이처럼, 각각의 문화유산은 그 시대의 사회적, 문화적 맥락을 밝혀주는 귀중한 자료로, 우리의 역사적 정체성을 강화하는 데 기여합니다. 지정일과 소유 정보는 이들 유산의 공식적 가치를 부각시키며, 많은 이들의 관심과 보호를 필요로 합니다.

---

## 여행 준비에 도움되는 추천 용품

![광주 증심사 철조비로자나불좌상](https://www.khs.go.kr/unisearch/images/treasure/1615474.jpg)


- [버티탭 캠핑랜턴 10000mAh LED작업등 충전식조명 텐트조명 캠핑전등 감성랜턴 렌턴충전식 렌턴 감성램프, 그레이, 1개](https://link.coupang.com/a/eae1fA) — 31,800원
- [원스위크라이프 캠핑 IGT 접이식 테이블, 카키](https://link.coupang.com/a/eae1g2) — 182,990원

## 함께 읽어보기

{{< article link="/posts/경남-국보-탐방-탐방-후-들르기-좋은-카페와-맛집/" >}}

{{< article link="/posts/제주에서-국보-탐방-돈내코-원앙폭포와-4곳-한눈에-보기/" >}}

{{< article link="/posts/제주-김정희-종가-유물과-관덕정-탐방-코스-추천/" >}}

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://www.trip.com/?Allianceid=3993748&SID=travel_blog" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 반경 10km 내 가볼만한 곳

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B8%88%EB%82%A8%EB%A1%9C" target="_blank">금남로 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%9B%90%EA%B0%81%EC%82%AC%28%EA%B4%91%EC%A3%BC%29" target="_blank">원각사(광주) 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B8%88%EB%82%A8%EB%A1%9C%EA%B3%B5%EC%9B%90%20%EA%B8%88%EB%82%A8%EB%82%98%EB%B9%84%EC%A0%95%EC%9B%90" target="_blank">금남로공원 금남나비정원 지도에서 보기</a>



## 반경 10km 내 맛집

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B3%84%EB%A6%BC%EB%8F%99%EC%9E%94%EC%B9%98%EC%A7%91" target="_blank">계림동잔치집 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EB%B0%95%EC%88%9C%EC%9E%90%20%EB%85%B9%EB%91%90%EC%A7%91" target="_blank">박순자 녹두집 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%A0%9C%EC%9D%BC%EB%B0%98%EC%A0%90" target="_blank">제일반점 지도에서 보기</a>

전화: 062-224-6670