---
title: "광주 동구 축제 광주국가유산야행, 시대별 변화와 건축 양식"
slug: '광주-동구-축제-광주국가유산야행-시대별-변화와-건축-양식'
date: '2026-04-05T13:05:07+09:00'
draft: false
description: "광주 동구 축제 — 광주국가유산야행. 1곳 정보와 방문 팁 정리."
tags: ['festival', '축제', '광주 동구']
categories: ['festival']
---

## 광주 동구 축제 개요

![광주국가유산야행](https://tong.visitkorea.or.kr/cms/resource/70/4053670_image2_1.jpg)


광주 동구는 역사와 문화가 어우러진 지역으로, 다양한 축제가 열리는 곳입니다. 그 중에서도 '광주국가유산야행'은 지역의 역사적 유산을 조명하고, 시민과 관광객이 함께 참여할 수 있는 특별한 행사입니다. 이 축제는 2026년 4월 24일부터 25일까지 진행되며, 야경과 다양한 프로그램을 통해 광주의 역사와 문화를 경험할 수 있는 기회를 제공합니다. 특히, 5·18민주광장과 같은 역사적 장소에서 열리는 만큼, 지역 주민과 방문객 모두에게 깊은 감동을 선사할 것입니다. 이러한 축제는 단순한 관람을 넘어, 지역의 정체성을 느끼고, 역사적 사건을 되새길 수 있는 중요한 기회를 제공합니다.

## 광주국가유산야행

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EA%B5%AD%EA%B0%80%EC%9C%A0%EC%82%B0%EC%95%BC%ED%96%89" target="_blank" rel="nofollow">광주국가유산야행 네이버 지도에서 보기</a>


광주국가유산야행은 광주광역시 동구가 주최하는 축제로, 5·18민주광장에서 열립니다. 이 축제는 다양한 프로그램을 통해 광주의 역사와 문화를 체험할 수 있는 기회를 제공합니다. 행사 기간 동안 야경을 감상할 수 있는 빛터널과 미디어 아트 전시가 진행되며, 시간의 등 만들기와 같은 체험 프로그램도 마련되어 있습니다. 또한, 광주목사 행차 재현과 어린이 해설사 투어 등 가족 단위 관람객을 위한 프로그램도 다양하게 준비되어 있습니다.

이 축제는 단순한 문화 행사에 그치지 않고, 광주의 역사적 배경을 되새기고, 지역 주민과의 소통을 강화하는 데 큰 의의를 지닙니다. 특히, '건축가의 고민'과 같은 렉처콘서트는 지역 건축의 역사와 현대적 의미를 되짚어 볼 수 있는 기회를 제공합니다. 이러한 프로그램은 광주가 가진 독특한 건축적 특성과 역사적 사건들을 깊이 있게 탐구할 수 있는 장을 마련합니다. 

광주국가유산야행은 지역의 문화유산을 통해 광주를 재조명하고, 방문객들에게 역사적 가치와 감동을 전달하는 중요한 역할을 하고 있습니다. 이처럼 다양한 프로그램과 함께하는 축제는 가족 단위 방문객들에게도 큰 찾는 손님이 많습니다.

## 방문 안내

광주국가유산야행은 광주광역시 동구 문화전당로 38에 위치한 5·18민주광장에서 개최됩니다. 행사 기간 동안 18:00부터 22:00까지 운영되며, 다양한 프로그램이 진행됩니다. 행사장에 도착하기 위해서는 대중교통을 이용하는 것이 편리합니다. 광주 지하철 1호선을 이용해 '문화전당역'에서 하차한 후, 도보로 약 10분 거리에 위치해 있습니다. 또한, 행사장 주변에는 다양한 편의시설이 마련되어 있어 관람 후 편리하게 이용할 수 있습니다.

## 문화유산의 가치

광주국가유산야행은 단순한 축제를 넘어, 지역의 역사적 가치와 문화를 재조명하는 중요한 의미를 지닙니다. 이 축제를 통해 광주가 가진 독특한 역사와 문화유산을 경험할 수 있으며, 지역 주민과의 소통을 통해 공동체 의식을 느낄 수 있는 기회를 제공합니다. 또한, 다양한 프로그램은 가족 단위 관람객들에게도 흥미롭고 교육적인 경험을 제공하여, 다음 세대에 지역 역사와 문화를 전파하는 데 기여하고 있습니다. 이러한 축제는 지역 사회의 정체성을 강화하고, 광주를 방문하는 사람들에게 깊은 인상을 남기는 중요한 문화 행사로 자리 잡고 있습니다.

---

## 여행 준비에 도움되는 추천 용품

- [울란지 Protective Serie 카메라 백팩 BP09](https://link.coupang.com/a/eirodk) — 131,350원
- [타이탄트랙 등산스틱 접이식 초경량 등산용 스틱 두랄루민](https://link.coupang.com/a/eirogF) — 47,300원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 근처 가볼 만한 곳

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/99/3351399_image2_1.jpg" alt="충장로" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">충장로</strong><span class="nearby-card-addr">광주광역시 동구 서석로 37 (충장로1가)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B6%A9%EC%9E%A5%EB%A1%9C" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/58/3453358_image2_1.jpg" alt="광주 충장로 케이팝 스타의 거리" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">광주 충장로 케이팝 스타의 거리</strong><span class="nearby-card-addr">광주광역시 동구 충장로 94 (충장로2가)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EC%B6%A9%EC%9E%A5%EB%A1%9C%20%EC%BC%80%EC%9D%B4%ED%8C%9D%20%EC%8A%A4%ED%83%80%EC%9D%98%20%EA%B1%B0%EB%A6%AC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/71/3556671_image2_1.jpeg" alt="충장로 홍콩골목" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">충장로 홍콩골목</strong><span class="nearby-card-addr">광주광역시 동구 충장로안길 5-2 (충장로3가)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B6%A9%EC%9E%A5%EB%A1%9C%20%ED%99%8D%EC%BD%A9%EA%B3%A8%EB%AA%A9" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



## 근처 맛집

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/41/3454441_image2_1.jpg" alt="카페진정성" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">카페진정성</strong><span class="nearby-card-addr">광주광역시 동구 문화전당로 38 (광산동)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B9%B4%ED%8E%98%EC%A7%84%EC%A0%95%EC%84%B1" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/94/2665094_image2_1.jpg" alt="장독대" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">장독대</strong><span class="nearby-card-addr">광주광역시 동구 문화전당로 43 3층</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9E%A5%EB%8F%85%EB%8C%80" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/53/2668053_image2_1.jpg" alt="퍼스트네팔" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">퍼스트네팔</strong><span class="nearby-card-addr">광주광역시 동구 서석로7번길 6-44</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%8D%BC%EC%8A%A4%ED%8A%B8%EB%84%A4%ED%8C%94" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

- [경기 맑은숲캠프와 반딧불캠핑장 비밀스러운 매력 탐구](/posts/경기-맑은숲캠프와-반딧불캠핑장-비밀스러운-매력-탐구/)
- [전북 덕동자동차야영장 방문 가이드, 역사부터 동선까지](/posts/전북-덕동자동차야영장-방문-가이드-역사부터-동선까지/)
- [충청북도 어게인캠핑B의 매력과 숨겨진 비밀](/posts/충청북도-어게인캠핑b의-매력과-숨겨진-비밀/)