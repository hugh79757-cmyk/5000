---
title: "전남 강진 월남사지 진각국사의 역사적 가치와 건축 양식 해설"
slug: '전남-강진-월남사지-진각국사의-역사적-가치와-건축-양식-해설'
date: '2026-04-21T07:11:39+09:00'
draft: false
description: "전남 보물 — 강진 월남사지 진각국사비, 구례 연곡사 동 승탑비, 담양 남산리 오층석탑. 3곳 정보와 방문 팁 정리."
tags: ['보물', '전남']
categories: ['보물']
featureimage: "https://www.khs.go.kr/unisearch/images/treasure/1619063.jpg"
---

## 전남 보물 개요

![강진 월남사지 진각국사비](https://www.khs.go.kr/unisearch/images/treasure/1619063.jpg)

전남 지역은 고려시대의 역사와 문화가 잘 보존된 곳으로, 이곳에서 발견된 여러 보물들은 당시의 종교적 신앙과 예술적 표현을 보여줍니다. 강진 월남사지 진각국사비, 구례 연곡사 동 승탑비, 담양 남산리 오층석탑은 모두 고려시대에 제작된 석조문화재로, 각 유산은 그 자체로 독특한 역사적 배경과 예술적 가치를 지니고 있습니다. 이들 유산은 고려시대의 불교 문화와 그에 따른 예술적 양식을 반영하고 있으며, 지역적으로도 서로 연결된 의미를 가지고 있습니다. 특히, 각 유산이 사찰과 관련되어 있다는 점은 이들 유산이 단순한 구조물이 아닌, 당시 사람들의 신앙과 삶의 일면을 보여주는 중요한 기록임을 시사합니다. 이러한 맥락에서 이들 유산을 함께 살펴보는 것은 고려시대의 종교적 신념과 예술적 경향을 이해하는 데 큰 도움이 됩니다.

## 강진 월남사지 진각국사비

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B0%95%EC%A7%84%20%EC%9B%94%EB%82%A8%EC%82%AC%EC%A7%80%20%EC%A7%84%EA%B0%81%EA%B5%AD%EC%82%AC%EB%B9%84" target="_blank" rel="nofollow">강진 월남사지 진각국사비 네이버 지도에서 보기</a>


![담양 남산리 오층석탑](https://www.khs.go.kr/unisearch/images/treasure/1619227.jpg)

강진 월남사지 진각국사비는 고려 중기에 창건된 월남사의 터에 세워진 비석입니다. 이 비는 진각국사 혜심을 추모하기 위해 세운 것으로, 비의 형태는 거북받침돌 위에 비몸을 올린 독특한 구조를 가지고 있습니다. 비의 받침돌은 사실적으로 조각된 거북의 모습이 인상적이며, 비문은 당시의 문장가 이규보가 지은 것으로 전해집니다. 현재 비문은 심하게 마모되어 가독성이 떨어지지만, 그 역사적 의미는 여전히 중요합니다. 월남사지 진각국사비는 고려시대 불교의 중요한 인물과 그 사찰의 역사를 연결해주며, 다른 두 유산과 함께 고려시대의 불교 문화의 흐름을 이해하는 데 기여합니다.

## 구례 연곡사 동 승탑비

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B5%AC%EB%A1%80%20%EC%97%B0%EA%B3%A1%EC%82%AC%20%EB%8F%99%20%EC%8A%B9%ED%83%91%EB%B9%84" target="_blank" rel="nofollow">구례 연곡사 동 승탑비 네이버 지도에서 보기</a>

구례 연곡사 동 승탑비는 고려시대에 제작된 승탑비로, 동 승탑 앞에 세워져 있습니다. 이 비는 몸돌이 사라진 상태지만, 받침돌과 머릿돌이 남아 있어 독특한 형태를 보여줍니다. 받침돌은 용의 모습을 형상화하고 있으며, 머릿돌에는 구름무늬와 보주 장식이 새겨져 있습니다. 이 비는 통일신라시대와는 다른 고려시대의 새로운 양식을 보여주는 중요한 사례로 평가받고 있습니다. 연곡사 자체가 통일신라시대에 창건된 사찰로, 이 비는 그 역사적 연속성을 강조해줍니다. 강진의 진각국사비와 마찬가지로, 구례 연곡사 동 승탑비도 고려시대 불교 문화의 중요한 유산으로, 지역적 특성과 함께 고려시대의 예술적 표현을 담고 있습니다.

## 담양 남산리 오층석탑

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EB%8B%B4%EC%96%91%20%EB%82%A8%EC%82%B0%EB%A6%AC%20%EC%98%A4%EC%B8%B5%EC%84%9D%ED%83%91" target="_blank" rel="nofollow">담양 남산리 오층석탑 네이버 지도에서 보기</a>

담양 남산리 오층석탑은 고려시대에 세워진 석탑으로, 백제의 정림사지 오층석탑을 모방하여 제작된 것으로 알려져 있습니다. 이 탑은 1층의 기단 위에 5층의 탑신을 올린 형태로, 기단이 낮고 독특한 양식을 지니고 있습니다. 탑신은 안정된 느낌을 주며, 네 귀퉁이에 장식적 구멍이 있어 초기의 화려함을 짐작하게 합니다. 현재 남산리 오층석탑은 주변에 절터의 흔적이 남아있지 않지만, 그 자체로 고려시대의 종교적 신념과 건축 양식을 보여주는 중요한 유산입니다. 강진 월남사지의 진각국사비와 구례 연곡사 동 승탑비와 함께, 담양 남산리 오층석탑은 고려시대 불교 문화의 다양한 양상을 보여주며, 이들 유산 간의 역사적 연관성을 강조합니다.

## 방문 안내
강진 월남사지 진각국사비는 전남 강진군 성전면 월남리 813-1에 위치하고 있으며, 구례 연곡사 동 승탑비는 전남 구례군 토지면 내동리 산54-1에 있습니다. 담양 남산리 오층석탑은 전남 담양군 담양읍 남산리 342번지에 자리하고 있습니다. 이 세 곳은 전남 지역 내에서 비교적 가까운 거리에 위치하고 있어, 방문 시 함께 관람하기 용이합니다. 각 유산은 사찰과 관련된 역사적 배경이 있으며, 방문자는 각 유산의 역사와 의미를 깊이 있게 이해할 수 있는 기회를 가질 수 있습니다.

---

## 여행 준비에 도움되는 추천 용품

- [보바 그립 22.5W 고속충전 보조배터리 20000mAh](https://link.coupang.com/a/etaDyl) — 40,900원
- [위드제이앤엠 짐벌 블루투스 휴대폰 셀카봉 삼각대 거치대 360도 회전 얼굴인식 트래킹 짐벌 셀카봉 모션아이, 블랙 1개](https://link.coupang.com/a/etaDCY) — 47,800원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>




<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>


<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/53/3347153_image2_1.JPG" alt="화순 야사리 은행나무" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">화순 야사리 은행나무</strong><span class="nearby-card-addr">전라남도 화순군 이서면 야사은행나무길 7</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%99%94%EC%88%9C%20%EC%95%BC%EC%82%AC%EB%A6%AC%20%EC%9D%80%ED%96%89%EB%82%98%EB%AC%B4" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/55/3348155_image2_1.JPG" alt="물염적벽" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">물염적벽</strong><span class="nearby-card-addr">전라남도 화순군 이서면 물염로</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%AC%BC%EC%97%BC%EC%A0%81%EB%B2%BD" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/32/3533532_image2_1.jpg" alt="화순적벽" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">화순적벽</strong><span class="nearby-card-addr">전라남도 화순군 이서면 적벽로 630-1</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%99%94%EC%88%9C%EC%A0%81%EB%B2%BD" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기