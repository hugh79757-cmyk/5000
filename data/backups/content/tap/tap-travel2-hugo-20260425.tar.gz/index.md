---
title: "광주 광주여성영화제, 건축 양식으로 읽는 조선의 기술"
slug: '광주-광주여성영화제-건축-양식으로-읽는-조선의-기술'
date: '2026-04-06T13:05:11+09:00'
draft: false
description: "광주 봄 축제 — 광주여성영화제, 광주국제미술전람회 〈아트광주, 렛츠플로피(Let's FLO. 3곳 정보와 방문 팁 정리."
tags: ['봄 축제', '광주', '축제']
categories: ['축제']
---

## 광주 봄 축제 개요

![광주여성영화제](https://tong.visitkorea.or.kr/cms/resource/26/3460726_image2_1.jpg)


광주에서 열리는 봄 축제는 지역의 문화적 정체성을 드러내는 중요한 행사입니다. 특히, 광주여성영화제, 광주국제미술전람회 〈아트광주24〉, 렛츠플로피(Let's FLOPPY 3.0)와 같은 다양한 문화유산들이 함께 어우러져 지역 주민과 방문객들에게 풍성한 문화 체험을 제공합니다. 이들 유산은 각기 다른 예술 장르를 대표하며, 모두 무료로 관람할 수 있어 많은 이들에게 접근성이 높습니다. 또한, 이들 행사들은 현대 예술과 여성의 권리, 그리고 지역 사회의 발전을 주제로 하여, 광주가 지닌 사회적, 역사적 맥락을 더욱 깊이 있게 탐구할 수 있는 기회를 제공합니다. 따라서 이들 유산은 단순한 관람을 넘어, 광주 지역의 문화적 흐름을 이해하는 데 중요한 연결 고리 역할을 합니다.

## 광주여성영화제

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EC%97%AC%EC%84%B1%EC%98%81%ED%99%94%EC%A0%9C" target="_blank" rel="nofollow">광주여성영화제 네이버 지도에서 보기</a>


![광주국제미술전람회 〈아트광주24〉](https://tong.visitkorea.or.kr/cms/resource/30/3382730_image2_1.jpg)


광주여성영화제는 2005년에 시작되어 매년 개최되는 행사로, 여성 감독의 작품을 중심으로 한 영화 상영을 통해 여성의 시각과 경험을 조명합니다. 이 축제는 한국 사회에서 여성의 목소리를 강화하고, 성 평등을 촉진하는 중요한 플랫폼으로 자리 잡았습니다. 영화제는 다양한 작품을 통해 관객에게 깊은 감동을 주며, 관람객들은 가족과 친구와 함께 영화를 감상하며 의미 있는 시간을 보낼 수 있습니다. 현재 광주여성영화제는 국내외에서 주목받는 행사로 성장하였으며, 매년 많은 관객이 참여하여 여성의 이야기를 나누는 장이 되고 있습니다. 광주여성영화제는 다른 문화유산들과 마찬가지로 지역 사회의 문화적 정체성을 확립하는 데 기여하고 있습니다.

## 광주국제미술전람회 〈아트광주24〉

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EA%B5%AD%EC%A0%9C%EB%AF%B8%EC%88%A0%EC%A0%84%EB%9E%8C%ED%9A%8C%20%E3%80%88%EC%95%84%ED%8A%B8%EA%B4%91%EC%A3%BC24%E3%80%89" target="_blank" rel="nofollow">광주국제미술전람회 〈아트광주24〉 네이버 지도에서 보기</a>


![렛츠플로피(Let's FLOPPY 3.0)](https://tong.visitkorea.or.kr/cms/resource/62/3492562_image2_1.jpg)


광주국제미술전람회 〈아트광주24〉는 현대 미술의 다양성을 보여주는 행사로, 국내외 아티스트들이 참여하여 최신 작품을 선보입니다. 이 전람회는 광주가 미술의 중심지로 자리매김하는 데 중요한 역할을 하고 있으며, 지역 예술가들에게도 큰 기회를 제공합니다. 〈아트광주24〉는 다양한 장르와 매체의 예술 작품을 통해 관람객들에게 시각적 즐거움을 선사하고, 현대 미술의 흐름을 이해할 수 있는 장을 마련합니다. 이 행사 또한 무료로 관람할 수 있어, 다양한 계층의 사람들이 미술을 접할 수 있는 기회를 제공합니다. 광주여성영화제와 마찬가지로 〈아트광주24〉도 지역 사회의 문화적 발전에 기여하고 있습니다.

## 렛츠플로피(Let's FLOPPY 3.0)

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EB%A0%9B%EC%B8%A0%ED%94%8C%EB%A1%9C%ED%94%BC%28Let%27s%20FLOPPY%203.0%29" target="_blank" rel="nofollow">렛츠플로피(Let's FLOPPY 3.0) 네이버 지도에서 보기</a>


렛츠플로피(Let's FLOPPY 3.0)는 디지털 아트와 대중문화가 만나는 지점을 탐구하는 행사로, 현대 사회의 다양한 이슈를 반영한 예술 작품을 선보입니다. 이 행사는 특히 젊은 세대에게 큰 호응을 얻고 있으며, 디지털 매체를 활용한 창작물들이 주를 이루고 있습니다. 렛츠플로피는 현대 기술과 예술의 융합을 통해 새로운 형태의 예술 경험을 제공하고, 관람객들은 이를 통해 현대 사회의 변화를 체감할 수 있습니다. 이 행사 또한 무료로 개방되어 있어, 누구나 쉽게 참여할 수 있는 점이 특징입니다. 광주국제미술전람회와 연계되어, 현대 미술의 다양한 양상을 한 자리에서 경험할 수 있는 기회를 제공합니다.

## 방문 안내

광주여성영화제는 광주광역시 동구 중앙로160번길 16-7에 위치해 있으며, 대중교통을 이용할 경우 지하철이나 버스를 통해 쉽게 접근할 수 있습니다. 광주국제미술전람회 〈아트광주24〉와 렛츠플로피는 모두 광주광역시 서구 상무누리로 30에 자리 잡고 있습니다. 이곳은 지하철과 버스 노선이 잘 연결되어 있어, 방문객들이 편리하게 이동할 수 있습니다. 각 행사장은 가까운 거리에 위치해 있어, 관람 동선을 효율적으로 계획할 수 있습니다.

---

## 여행 준비에 도움되는 추천 용품

- [울란지 Protective Serie 카메라 백팩 BP09](https://link.coupang.com/a/ei6Wot) — 131,350원
- [유스몰 옥스포드 남성 메신저백 크로스백](https://link.coupang.com/a/ei6WqF) — 17,100원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 근처 가볼 만한 곳

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/13/3367313_image2_1.jpg" alt="운천저수지" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">운천저수지</strong><span class="nearby-card-addr">광주광역시 서구 운천로 165</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9A%B4%EC%B2%9C%EC%A0%80%EC%88%98%EC%A7%80" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/28/3367228_image2_1.jpg" alt="운천사마애여래좌상" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">운천사마애여래좌상</strong><span class="nearby-card-addr">광주광역시 서구 금호운천길 85-15</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9A%B4%EC%B2%9C%EC%82%AC%EB%A7%88%EC%95%A0%EC%97%AC%EB%9E%98%EC%A2%8C%EC%83%81" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/27/3350527_image2_1.jpg" alt="5·18 기념공원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">5·18 기념공원</strong><span class="nearby-card-addr">광주광역시 서구 상무민주로 61 (쌍촌동)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/5%C2%B718%20%EA%B8%B0%EB%85%90%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



## 근처 맛집

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/18/2606418_image2_1.jpg" alt="[백년가게]민들레" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">[백년가게]민들레</strong><span class="nearby-card-addr">광주광역시 서구 상무평화로 137</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%5B%EB%B0%B1%EB%85%84%EA%B0%80%EA%B2%8C%5D%EB%AF%BC%EB%93%A4%EB%A0%88" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/67/2864867_image2_1.jpg" alt="홍아네" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">홍아네</strong><span class="nearby-card-addr">광주광역시 서구 마륵복개로150번길 7</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%99%8D%EC%95%84%EB%84%A4" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/75/2664375_image2_1.jpg" alt="미래연" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">미래연</strong><span class="nearby-card-addr">광주광역시 서구 내방로161번길 4 1층</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%AF%B8%EB%9E%98%EC%97%B0" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

- [경기 더 비치 글램핑의 바다와 캠핑의 비밀](/posts/경기-더-비치-글램핑의-바다와-캠핑의-비밀/)
- [충남 SE클럽(태안둘레길캠핑장&펜의 숨겨진 역사와 건축 비밀](/posts/충남-se클럽태안둘레길캠핑장펜의-숨겨진-역사와-건축-비밀/)
- [경북 불국사한옥팜스테이 탐방 전 꼭 읽어야 할 해설](/posts/경북-불국사한옥팜스테이-탐방-전-꼭-읽어야-할-해설/)