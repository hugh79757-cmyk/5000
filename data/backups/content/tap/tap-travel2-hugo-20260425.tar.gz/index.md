---
title: "광주 정지장군 갑옷의 역사적 가치 해설"
slug: '광주-정지장군-갑옷의-역사적-가치-해설'
date: '2026-04-21T17:38:17+09:00'
draft: false
description: "광주 보물 생활공예 — 정지장군 갑옷. 1곳 정보와 방문 팁 정리."
tags: ['광주', '보물 생활공예']
categories: ['보물 생활공예']
featureimage: "https://pub-2f5c7af1c303419a933069212bc25874.r2.dev/common/default-thumbnail.webp"
---

## 정지장군 갑옷의 역사와 배경

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%A0%95%EC%A7%80%EC%9E%A5%EA%B5%B0%20%EA%B0%91%EC%98%B7" target="_blank" rel="nofollow">정지장군 갑옷 네이버 지도에서 보기</a>


광주 지역의 정지장군 갑옷은 고려시대의 중요한 유물로, 1963년 1월 21일 보물로 지정되었습니다. 이 갑옷은 고려 충목왕 3년인 1347년에 태어난 정지장군이 착용했던 것으로 전해지며, 그의 후손에 의해 현재까지 전해지고 있습니다. 정지장군은 왜구를 물리치는 데 큰 공을 세운 인물로, 공양왕 3년인 1391년에 세상을 떠났습니다. 이 시기는 고려 말기로, 외적의 침입이 빈번했던 시기였으며, 국가의 방어력이 중시되던 시대적 배경을 반영합니다. 고려는 이 시기에 정치적 혼란과 외적의 위협 속에서 군사적 방어를 강화하기 위한 다양한 노력을 기울였습니다. 정지장군의 갑옷은 이러한 군사적 필요에 의해 제작된 것으로, 당시의 전투 방식과 군사 장비의 발전을 보여주는 중요한 증거로 평가됩니다. 이 유물은 현재 광주역사민속박물관에 소장되어 있으며, 하동정씨종친회 소유로 관리되고 있습니다.

## 정지장군 갑옷의 건축적·예술적 특징

정지장군 갑옷은 고려시대의 군사 장비 중 하나로, 경번갑의 형태를 띠고 있습니다. 이 갑옷의 총 길이는 70㎝, 가슴둘레는 79㎝, 소매 길이는 30㎝로, 인체에 맞춰 제작된 형태입니다. 갑옷은 철판과 철제 고리를 엮어 제작되었으며, 세로 7.5∼8㎝, 가로 5∼8.5㎝의 철판에 구멍을 뚫어 고리로 연결하여 만들어졌습니다. 앞면에는 6줄의 철판이 연결되어 있으며, 그 중 두 줄은 여미게 되어 있어 착용자의 움직임을 고려한 디자인이 돋보입니다. 뒷면은 7조각으로 연결되어 5줄로 등 부분을 가릴 수 있도록 제작되었습니다. 어깨와 팔 부분은 철판 없이 고리만을 사용하여 자유로운 움직임을 가능하게 한 점이 특징입니다. 이러한 구조는 당시의 전투에서 기동성을 중시했던 고려의 군사적 요구를 반영하고 있습니다. 정지장군 갑옷은 그 형태와 제작 기법에서 유례를 찾아볼 수 없는 독특한 유물로, 고려시대 군사 공예의 뛰어난 예를 보여줍니다. 다른 시대의 갑옷들과 비교할 때, 정지장군 갑옷은 특히 그 세밀한 제작 기법과 실용성을 강조한 디자인이 눈에 띕니다.

## 방문 안내

정지장군 갑옷은 광주광역시 북구 서하로 48-25에 위치한 광주역사민속박물관에 전시되고 있습니다. 이 박물관은 광주 시내에 위치하여 접근성이 좋습니다. 박물관 내부에 들어가면 정지장군을 모신 사당과 유물관이 있으며, 갑옷을 직접 관람할 수 있는 공간이 마련되어 있습니다. 좌표상으로는 126.888462263732, 35.1842268004769로, 이 지역의 교통 편의성이 높아 다양한 대중교통 수단을 이용하여 방문할 수 있습니다. 관람 시에는 갑옷의 역사적 의미를 충분히 이해할 수 있도록 관련 안내판을 미리 읽어보시는 것이 좋습니다. 또한, 이 유물은 비교적 원형을 잘 간직하고 있으므로, 그 가치를 존중하며 관람하는 것이 중요합니다.

## 정지장군 갑옷의 가치와 의미

정지장군 갑옷은 고려시대의 군사적 방어 장비로서 역사적, 문화적, 학술적 가치가 매우 높습니다. 1963년 1월 21일 보물로 지정된 이 유물은 당시의 군사 기술과 공예 수준을 보여주는 중요한 사례로 평가됩니다. 보물이라는 지정 종목은 이 유물이 한국의 역사와 문화유산에서 차지하는 위상을 나타내며, 정지장군의 전투와 관련된 역사적 사실을 뒷받침합니다. 정지장군 갑옷은 단순한 군사 장비 이상의 의미를 지니며, 고려시대의 외적 방어와 국가의 안전을 위한 노력의 상징으로 자리 잡고 있습니다. 이 유물은 한국 문화유산의 다양성과 깊이를 보여주는 중요한 자산으로, 후대에 전해져야 할 역사적 유산으로서의 가치를 지니고 있습니다. 정지장군 갑옷은 한국의 문화유산 전체에서 중요한 위치를 차지하며, 고려시대 군사 공예의 뛰어난 예로 남아 있습니다.

---

## 여행 준비에 도움되는 추천 용품

- [브랜든 여행용 세이프 플러스 월렛백](https://link.coupang.com/a/ettOfA) — 38,510원
- [바우아토 락모즈 미니 초경량 광각 촬영 모드 원터치 사각 거치 블루투스 셀카봉 삼각대, D-B-0373, 화이트, 1개](https://link.coupang.com/a/ettOjp) — 29,800원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>




<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>


<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/94/3367394_image2_1.jpg" alt="광주폴리" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">광주폴리</strong><span class="nearby-card-addr">광주광역시 북구 비엔날레로 111</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%ED%8F%B4%EB%A6%AC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/53/3353753_image2_1.jpg" alt="뜻모아센터" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">뜻모아센터</strong><span class="nearby-card-addr">광주광역시 북구 서하로245번길 42 (오치동)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%9C%BB%EB%AA%A8%EC%95%84%EC%84%BC%ED%84%B0" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/20/3528420_image2_1.jpg" alt="산동교친수공원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">산동교친수공원</strong><span class="nearby-card-addr">광주광역시 북구 동림동 130-15</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%82%B0%EB%8F%99%EA%B5%90%EC%B9%9C%EC%88%98%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/33/2910633_image2_1.JPG" alt="족발창고" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">족발창고</strong><span class="nearby-card-addr">광주광역시 북구 저불로31번길 4-1</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%A1%B1%EB%B0%9C%EC%B0%BD%EA%B3%A0" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/12/2664712_image2_1.png" alt="서석정" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">서석정</strong><span class="nearby-card-addr">광주광역시 북구 설죽로404번길 12</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%84%9C%EC%84%9D%EC%A0%95" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/27/2874027_image2_1.jpg" alt="갤러리24" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">갤러리24</strong><span class="nearby-card-addr">광주광역시 서구 천변좌로 14</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B0%A4%EB%9F%AC%EB%A6%AC24" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기