---
title: "광주 지산동 오층석탑과 약사암 석조여래좌의 역사와 가치 해설"
slug: '광주-지산동-오층석탑과-약사암-석조여래좌의-역사와-가치-해설'
date: '2026-04-25T11:50:59+09:00'
draft: false
description: "광주 보물 — 광주 지산동 오층석탑, 광주 약사암 석조여래좌상. 2곳 정보와 방문 팁 정리."
tags: ['광주', '보물']
categories: ['보물']
featureimage: "https://www.khs.go.kr/unisearch/images/treasure/1615470.jpg"
---

## 광주 보물 개요

![광주 지산동 오층석탑](https://www.khs.go.kr/unisearch/images/treasure/1615470.jpg)


광주는 통일신라시대의 문화유산이 풍부한 지역으로, 그 중에서도 광주 지산동 오층석탑과 광주 약사암 석조여래좌상은 중요한 보물로 지정되어 있습니다. 두 유산 모두 통일신라시대에 제작된 것으로, 불교 문화와 종교적 신앙을 반영하고 있습니다. 오층석탑은 석탑의 전형적인 양식을 잘 보여주며, 약사암 석조여래좌상은 불교 조각의 아름다움을 잘 나타내고 있습니다. 이 두 유산은 지역 내에서 불교 신앙의 중심 역할을 했던 사찰과 관련이 깊어, 광주 지역의 역사적 맥락을 이해하는 데 중요한 역할을 합니다. 따라서 이 두 보물을 함께 방문하면 통일신라시대의 불교 문화와 예술적 성취를 종합적으로 감상할 수 있습니다.

## 광주 지산동 오층석탑

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EC%A7%80%EC%82%B0%EB%8F%99%20%EC%98%A4%EC%B8%B5%EC%84%9D%ED%83%91" target="_blank" rel="nofollow">광주 지산동 오층석탑 네이버 지도에서 보기</a>


![광주 약사암 석조여래좌상](https://www.khs.go.kr/unisearch/images/treasure/1615504.jpg)


광주 지산동 오층석탑은 통일신라시대 후기의 석탑으로, 1963년 1월 21일 보물로 지정되었습니다. 이 석탑은 백주사 터 근처에 위치하고 있으며, 2단의 기단 위에 5층의 탑신을 세운 형태로, 신라 석탑의 기본형을 잘 유지하고 있습니다. 기단부는 여러 개의 돌을 짜맞추어 구성되어 있으며, 탑신부의 몸돌과 지붕돌은 각각 하나의 돌로 이루어져 있습니다. 특히 지붕돌의 받침 부분에서 1층은 5단, 2층부터는 4단으로 간략화된 점은 이 탑이 통일신라 후기에 제작되었음을 알려줍니다. 1955년의 해체 및 수리 과정에서 사리장치가 발견되는 등 역사적 가치가 높으며, 현재까지도 우수한 상태로 보존되고 있습니다. 약사암 석조여래좌상과 마찬가지로 불교 신앙의 상징으로서 지역 문화유산의 중요한 부분을 차지하고 있습니다.

## 광주 약사암 석조여래좌상

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EC%95%BD%EC%82%AC%EC%95%94%20%EC%84%9D%EC%A1%B0%EC%97%AC%EB%9E%98%EC%A2%8C%EC%83%81" target="_blank" rel="nofollow">광주 약사암 석조여래좌상 네이버 지도에서 보기</a>


광주 약사암 석조여래좌상은 통일신라시대 9세기에 제작된 불상으로, 1975년 8월 4일 보물로 지정되었습니다. 이 불상은 질병에 빠진 중생을 구제하는 약사불을 형상화한 것으로, 거친 화강암 석재를 다듬어 만들어졌습니다. 머리에는 작은 소라 모양의 머리칼을 붙여 놓았으며, 숙이고 있는 얼굴은 위가 넓고 아래가 좁은 형태로 표현되어 있습니다. 상체는 굴곡을 잘 드러내며, 오른손은 무릎 위에 올리고 왼손은 배에 대고 있는 모습이 인상적입니다. 대좌는 전형적인 8각의 연꽃무늬로 구성되어 있으며, 불상의 높이와 대좌의 비율이 1:1인 점에서 석굴암 본존불의 특징을 이어받고 있습니다. 지산동 오층석탑과 함께 통일신라의 불교 미술을 대표하는 작품으로, 두 유산 모두 지역 내 불교 신앙의 중심적 역할을 했음을 보여줍니다.

## 방문 안내

광주 지산동 오층석탑은 광주 동구 지산2동 448-4번지에 위치하고 있으며, 약사암 석조여래좌상은 광주 동구 증심사길 160번길 89에 위치한 약사암 내에 있습니다. 두 유산 모두 광주 시내에서 접근이 용이하며, 대중교통을 이용해 방문할 수 있습니다. 지산동 오층석탑은 백주사 터 근처에 있어 주변 경관과 함께 감상할 수 있으며, 약사암 석조여래좌상은 약사암 대웅전 안에 모셔져 있어 사찰의 고즈넉한 분위기를 느낄 수 있습니다. 두 유산은 각각의 역사적 배경을 가지고 있어, 함께 관람하면 더욱 풍부한 체험을 할 수 있습니다.

## 문화유산의 가치

광주 지산동 오층석탑과 약사암 석조여래좌상은 통일신라시대의 불교 문화와 예술적 성취를 대표하는 유산입니다. 두 유산은 각각의 형태와 양식에서 통일신라의 불교 미술의 발전을 잘 보여주며, 지역 내 불교 신앙의 중심 역할을 해왔습니다. 또한, 이들은 광주 지역의 역사와 문화적 맥락을 이해하는 데 중요한 자료로 작용합니다. 이처럼 두 보물은 단순한 유물이 아니라, 당시 사람들의 신앙과 삶의 방식을 엿볼 수 있는 중요한 문화유산으로서의 가치를 지니고 있습니다.

---

## 여행 준비에 도움되는 추천 용품

- [블랙야크 공용 고어텍스 방수 BOA 다이얼 경량 트레킹화 FATRICK GTX](https://link.coupang.com/a/ev1Goa) — 149,000원
- [매틴 클레버250 카메라백팩, 차콜그레이, 1개](https://link.coupang.com/a/ev1GrK) — 130,900원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>




<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>


<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/81/3366781_image2_1.jpg" alt="운림동 미술관거리" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">운림동 미술관거리</strong><span class="nearby-card-addr">광주광역시 동구 증심사길 9</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9A%B4%EB%A6%BC%EB%8F%99%20%EB%AF%B8%EC%88%A0%EA%B4%80%EA%B1%B0%EB%A6%AC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/59/2614859_image2_1.bmp" alt="증심사 계곡 안산암질용암" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">증심사 계곡 안산암질용암</strong><span class="nearby-card-addr">광주광역시 동구 증심사길 71</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%A6%9D%EC%8B%AC%EC%82%AC%20%EA%B3%84%EA%B3%A1%20%EC%95%88%EC%82%B0%EC%95%94%EC%A7%88%EC%9A%A9%EC%95%94" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/68/3368268_image2_1.jpg" alt="증심사(광주)" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">증심사(광주)</strong><span class="nearby-card-addr">광주광역시 동구 증심사길 177</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%A6%9D%EC%8B%AC%EC%82%AC%28%EA%B4%91%EC%A3%BC%29" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/26/2873726_image2_1.jpg" alt="카페지즈" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">카페지즈</strong><span class="nearby-card-addr">광주광역시 동구 동산길 42</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B9%B4%ED%8E%98%EC%A7%80%EC%A6%88" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/03/2873703_image2_1.jpg" alt="어반레시피" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">어반레시피</strong><span class="nearby-card-addr">광주광역시 동구 의재로136번길 10</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%96%B4%EB%B0%98%EB%A0%88%EC%8B%9C%ED%94%BC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/57/2664957_image2_1.jpeg" alt="화풍" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">화풍</strong><span class="nearby-card-addr">광주광역시 동구 의재로 130</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%99%94%ED%92%8D" target="_blank" rel="nofollow">지도에서 보기</a></div></div>