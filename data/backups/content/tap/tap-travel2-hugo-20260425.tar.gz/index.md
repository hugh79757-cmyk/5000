---
title: "심지백 개국원종공신녹권에서 만나는 부산의 시간 여행"
slug: '심지백-개국원종공신녹권에서-만나는-부산의-시간-여행'
date: '2026-04-15T11:42:40+09:00'
draft: false
description: "부산 국보 문서류 — 심지백 개국원종공신녹권. 1곳 정보와 방문 팁 정리."
tags: ['부산', '국보 문서류']
categories: ['국보 문서류']
---

## 심지백 개국원종공신녹권의 역사와 배경

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%8B%AC%EC%A7%80%EB%B0%B1%20%EA%B0%9C%EA%B5%AD%EC%9B%90%EC%A2%85%EA%B3%B5%EC%8B%A0%EB%85%B9%EA%B6%8C" target="_blank" rel="nofollow">심지백 개국원종공신녹권 네이버 지도에서 보기</a>


![심지백 개국원종공신녹권](https://www.khs.go.kr/unisearch/images/national_treasure/1611957.jpg)


부산에 위치한 심지백 개국원종공신녹권은 조선 태조 6년(1397)에 작성된 중요한 역사적 문서입니다. 이 문서는 당시 공신도감에서 왕의 명령을 받아 심지백에게 내린 것으로, 그의 공신임을 입증하는 내용을 담고 있습니다. 개국원종공신 제도는 조선시대에 개국공신을 늘리려는 의도로 만들어진 포상제도로, 1392년부터 1397년까지 1,400여 명이 봉해졌습니다. 이 제도는 조선 초기 정치의 불안정한 상황 속에서 왕권을 강화하고, 충성된 인물들에게 보상을 제공하여 국가의 기틀을 다지려는 의도가 있었습니다. 심지백이 녹권을 받을 당시 74명이 함께 포상을 받았으며, 이는 그의 위상을 더욱 높여주는 계기가 되었습니다. 이 문서는 1962년 12월 20일 국보로 지정되었으며, 현재 동아대학교 박물관에 소장되어 있습니다. 이처럼 심지백 개국원종공신녹권은 조선 전기의 정치적, 사회적 맥락을 이해하는 데 중요한 자료로 평가받고 있습니다.

## 심지백 개국원종공신녹권의 건축적·예술적 특징

심지백 개국원종공신녹권은 가로 140㎝, 세로 30.5㎝의 크기로, 조선 전기의 문서로서 이두문이 많이 사용되었습니다. 이 문서는 목활자를 이용하여 찍어낸 것으로, 이는 당시 인쇄 기술의 발전을 보여주는 중요한 사례입니다. 이두문은 한자의 음과 뜻을 한국어로 표현한 것으로, 조선 초기의 문서에서 흔히 볼 수 있는 양식입니다. 문서의 형태는 두루마리로 되어 있으며, 이는 조선 전기의 문서 제작 방식의 특징을 잘 보여줍니다. 또한, 이 문서는 상태가 완전하여 남한에 전해지고 있는 조선 전기의 목활자 인쇄물 중에서 가장 귀중한 것으로 평가받고 있습니다. 심지백 개국원종공신녹권과 같은 문서는 조선시대의 정치적 상황과 사회 구조를 이해하는 데 중요한 역할을 하며, 다른 유사한 문서들과 비교할 때 그 예술적 가치와 역사적 중요성에서 독보적인 위치를 차지하고 있습니다. 이는 당시의 정치적, 사회적 맥락을 반영하며, 공신들의 위상을 기록하는 중요한 사료로서의 기능을 다하고 있습니다.

## 방문 안내

부산광역시 서구 구덕로에 위치한 심지백 개국원종공신녹권은 동아대학교 박물관 내에 소장되어 있습니다. 이 박물관은 부산의 중심부에 자리 잡고 있어 대중교통으로의 접근이 용이합니다. 박물관에 도착하기 위해서는 부산 지하철 1호선이나 여러 버스를 이용하실 수 있으며, 도보로도 쉽게 접근할 수 있는 위치에 있습니다. 박물관 내부에는 다양한 전시물이 마련되어 있어, 심지백 개국원종공신녹권을 포함한 여러 문화유산을 한자리에서 감상하실 수 있습니다. 관람 시에는 박물관의 운영 방침에 따라 조용히 관람해 주시고, 전시물에 대한 촬영이 제한될 수 있으니 유의하시기 바랍니다. 또한, 박물관의 전시 일정이나 특별 전시회에 대한 정보는 공식 사이트에서 확인하시는 것이 좋습니다.

## 심지백 개국원종공신녹권의 가치와 의미

심지백 개국원종공신녹권은 조선시대의 중요한 역사적 문서로서, 그 가치가 매우 높습니다. 이 문서는 국보 제69호로 지정되어 있으며, 그 지정일은 1962년 12월 20일입니다. 국보라는 지정 종목은 해당 유산이 한국의 역사와 문화에 미치는 영향과 중요성을 인정받았음을 의미합니다. 이 문서는 조선 전기의 정치적 상황을 이해하는 데 필수적인 자료로, 당시 공신들의 역할과 위상을 기록하고 있습니다. 심지백 개국원종공신녹권은 한국 문화유산 전체에서 중요한 위치를 차지하며, 후세에 전해지는 역사적 교훈을 제공하고 있습니다. 이러한 이유로 이 문서는 단순한 기록을 넘어, 조선시대의 정치적, 사회적 맥락을 이해하는 데 중요한 역할을 하고 있습니다.

---

## 여행 준비에 도움되는 추천 용품

- [코차이 DSLR 카메라 가방 대용량 방수 충격방지 렌즈 수납 촬영용 카메라 숄더백](https://link.coupang.com/a/epbmNH) — 48,900.0원
- [바우아토 포켓쉴 고속 입출력 케이블 일체형 미니 대용량 난연 보조배터리 20000mAh C타입 애플8핀 PD 22.5W, 단일상품, 아이보리](https://link.coupang.com/a/epbmQv) — 37,800원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 근처 가볼 만한 곳



<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>


<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/30/3476830_image2_1.jpg" alt="국제시장 먹자골목" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">국제시장 먹자골목</strong><span class="nearby-card-addr">부산광역시 중구 중구로 36</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B5%AD%EC%A0%9C%EC%8B%9C%EC%9E%A5%20%EB%A8%B9%EC%9E%90%EA%B3%A8%EB%AA%A9" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/89/3552989_image2_1.jpg" alt="미술의거리" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">미술의거리</strong><span class="nearby-card-addr">부산광역시 중구 신창동4가</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%AF%B8%EC%88%A0%EC%9D%98%EA%B1%B0%EB%A6%AC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/47/3498447_image2_1.jpg" alt="민주공원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">민주공원</strong><span class="nearby-card-addr">부산광역시 중구 민주공원길 19</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%AF%BC%EC%A3%BC%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



## 근처 맛집

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/35/2867635_image2_1.JPG" alt="원조18번완당" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">원조18번완당</strong><span class="nearby-card-addr">부산광역시 서구 구덕로238번길 6 (부용동1가)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9B%90%EC%A1%B018%EB%B2%88%EC%99%84%EB%8B%B9" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/29/2867729_image2_1.JPG" alt="한우뭉치" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">한우뭉치</strong><span class="nearby-card-addr">부산광역시 중구 보수대로 106 (보수동3가)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%95%9C%EC%9A%B0%EB%AD%89%EC%B9%98" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/89/2867689_image2_1.JPG" alt="대동냉면밀면" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">대동냉면밀면</strong><span class="nearby-card-addr">부산광역시 중구 흑교로45번길 31</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%8C%80%EB%8F%99%EB%83%89%EB%A9%B4%EB%B0%80%EB%A9%B4" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

- [서울 양평 신화리 금동여래입의 숨겨진 역사와 예술적 가치](/posts/서울-양평-신화리-금동여래입의-숨겨진-역사와-예술적-가치/)
- [제주 관덕정의 숨겨진 역사와 문화적 가치에 대한 심층 해설](/posts/제주-관덕정의-숨겨진-역사와-문화적-가치에-대한-심층-해설/)
- [강원 강릉 굴산사지 당간지주와 양양 선림원지 삼층석탑의 숨겨진 비밀](/posts/강원-강릉-굴산사지-당간지주와-양양-선림원지-삼층석탑의-숨겨진-비밀/)