---
title: "경남 대포마을과 샤샤의놀이터 여행 방문 전 필독"
date: 2026-03-21
draft: false

---



## 경남 여행코스

![대포마을(산청)](http://tong.visitkorea.or.kr/cms/resource/17/3589117_image2_1.jpg)


경남 여행코스에서는 자연과 문화가 어우러진 다채로운 장소들을 탐방할 수 있다. 아래는 추천하는 여행 코스의 요약이다.

- **대포마을(산청)**
- **샤샤의놀이터**
- **산청특리지석묘군**
- **대광사(창원)**
- **용추사(함양)**

예상 소요 시간은 약 8시간이며, 입장료는 각 장소에 따라 상이하다. 주차는 대부분 가능하니 차량으로 이동할 경우 편리하다. 

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel