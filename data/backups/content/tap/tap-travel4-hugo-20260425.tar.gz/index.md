---
title: "전남 목포 해상케이블카 여행 코스 추천"
date: 2026-03-22
draft: false

---



## 전남 여행코스 코스 요약

![목포 해상케이블카](http://tong.visitkorea.or.kr/cms/resource/20/3554020_image2_1.jpg)


- 소요시간: 약 6시간
- **장소명 및 입장료**
  - 목포 해상케이블카: 무료
  - 읍리지석묘와 하마비: 무료
  - 봄의 왈츠 드라마 촬영지: 무료
  - 도솔암(해남): 무료
  - 무안낙지공원: 무료

전남은 다양한 자연경관과 문화유산이 어우러진 지역으로, 여행코스에서는 가족과 친구들이 함께 즐길 수 있는 5개의 명소를 탐방한다. 이 코스는 목포 해상케이블카로 시작하여, 완도의 읍리지석묘와 하마비, 봄의 왈츠 드라마 촬영지, 해남의 도솔암을 거쳐 무안낙지공원으로 마무리된다.

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;backgrou