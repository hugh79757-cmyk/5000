---
title: "경북 여행코스 우천 시 대체 코스까지 정리"
date: 2026-03-22
draft: false

---



## 경북 여행코스 코스 요약

![한화리조트 경주](http://tong.visitkorea.or.kr/cms/resource/00/3592400_image2_1.jpg)


- **코스 순서**: 한화리조트 경주 → 옥산 세심마을 → 기천서원 → 포항크루즈 → 내수전일출전망대
- **소요시간**: 약 10시간 (이동 시간 포함)
- **입장료**: 무료입장 (일부 시설 제외, 사전 확인 필요)

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="