---
title: "강원 속초 여행코스 5곳 정리"
date: 2026-03-22
draft: false

---



## 강원 여행코스 코스 요약

> [강원 영월 김삿갓면 [슬로시티] 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B0%95%EC%9B%90%20%EC%98%81%EC%9B%94%20%EA%B9%80%EC%82%BF%EA%B0%93%EB%A9%B4%20%5B%EC%8A%AC%EB%A1%9C%EC%8B%9C%ED%8B%B0%5D)

![속초 설악해맞이공원](https://tong.visitkorea.or.kr/cms/resource/75/2921475_image2_1.jpg)

- **코스 순서**: 속초 설악해맞이공원 → 봄내향기공방 → 강원 영월 김삿갓면 [슬로시티] → 쏠비치 양양 오션플레이 → [효석문학100리길 5-1코스] 마을길따라 노산가는 길
- **소요시간**: 약 8시간
- **입장료**: 무료 (일부 시설은 유료)

## 코스 상세 안내

![봄내향기공방](https://tong.visitkorea.or.kr/cms/re