---
title: "예산 10만원으로 즐기는 인천 여행코스 5곳 코스"
date: 2026-03-23
draft: false

---



## 인천 여행코스 코스 요약

![점핑파크 인천계양점](https://tong.visitkorea.or.kr/cms/resource/66/3080966_image2_1.png)

- **코스 순서**: 점핑파크 인천계양점 → 스카이랜드카라반 리조트 → 월미공원 → 용화선원(인천) → 인천기독교사회복지관(여선교사합숙소)
- **소요시간**: 약 8시간
- **입장료**: 현장에서 결제 필요(각 장소마다 다름)

## 코스 상세 안내

![스카이랜드카라반 리조트](https://tong.visitkorea.or.kr/cms/resource/75/2800275_image2_1.jpg)


### 점핑파크 인천계양점

> [점핑파크 인천계양점 네이버 지도에서 보기](https://map.naver.com/v5/search/%EC%A0%90%ED%95%91%ED%8C%8C%ED%81%AC%20%EC%9D%B8%EC%B2%9C%EA%B3%84%EC%96%91%EC%A0%90)
점핑파크 인