---
title: "대구에서 하루 만에 즐기는 여행코스 5곳 플랜"
date: 2026-03-21
draft: false

---



## 대구 여행코스 코스 요약

![동화사(대구)](http://tong.visitkorea.or.kr/cms/resource/85/3576785_image2_1.JPG)

- 동화사(대구)
- 교남YMCA 회관
- 바운스 트램폴린파크 동대구신세계백화점센터
- 한밤마을
- 옹기종기행복마을

소요시간: 약 6~7시간  
입장료: 없음  

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gog