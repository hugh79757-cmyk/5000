---
title: "광주 풍암저수지 포함 힐링코스 4곳 정리"
slug: '광주-풍암저수지-포함-힐링코스-4곳-정리'
date: '2026-04-23T07:17:02+09:00'
draft: false
description: "광주 힐링코스 — 광주하계유니버시아드 주경기장, 풍암저수지, 전평제. 4곳 정보와 방문 팁 정리."
tags: ['여행코스', '광주', '힐링코스']
categories: ['여행코스']
featureimage: "https://tong.visitkorea.or.kr/cms/resource/04/1587804_image2_1.jpg"
---

## 광주 여행코스 요약

![광주하계유니버시아드 주경기장(광주월드컵경기장)](https://tong.visitkorea.or.kr/cms/resource/04/1587804_image2_1.jpg)


광주 여행코스는 광주하계유니버시아드 주경기장을 중심으로 구성된 힐링코스입니다. 이 코스는 다음과 같은 장소로 이루어져 있습니다.  
- **광주하계유니버시아드 주경기장(광주월드컵경기장)**  
- **풍암저수지**  
- **전평제**  
- **상무시민공원**  

가족 및 연인과 함께 여유로운 시간을 보내기에 적합한 코스입니다. 각 장소는 자연과 조화를 이루며, 다양한 볼거리를 제공합니다.

## 코스 상세 안내

![풍암저수지](https://tong.visitkorea.or.kr/cms/resource/09/1587809_image2_1.jpg)


### 광주하계유니버시아드 주경기장(광주월드컵경기장)

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%ED%95%98%EA%B3%84%EC%9C%A0%EB%8B%88%EB%B2%84%EC%8B%9C%EC%95%84%EB%93%9C%20%EC%A3%BC%EA%B2%BD%EA%B8%B0%EC%9E%A5%28%EA%B4%91%EC%A3%BC%EC%9B%94%EB%93%9C%EC%BB%B5%EA%B2%BD%EA%B8%B0%EC%9E%A5%29" target="_blank" rel="nofollow">광주하계유니버시아드 주경기장(광주월드컵경기장) 네이버 지도에서 보기</a>


![전평제](https://tong.visitkorea.or.kr/cms/resource/28/1587728_image2_1.jpg)


광주하계유니버시아드 주경기장은 광주광역시 서구 금화로 240에 위치해 있습니다. 이 경기장은 관람객 출입구와 바닥포장 패턴의 방사형 설계를 통해 원형 경기장에서 강렬한 빛이 발산되는 모습을 형상화하고 있습니다. 경기장 지붕과 스탠드를 지지하는 대형 기둥은 Y자 형태로 설계되어 있으며, 이는 광주의 전통 민속놀이인 고싸움놀이의 고를 상징합니다. 동서 양측 지붕이 마주하고 있는 모습은 고싸움놀이 중 상호 충돌하려는 고의 모습을 나타내고 있습니다. 이곳은 스포츠 이벤트뿐만 아니라 다양한 문화 행사도 개최되어 많은 이들의 사랑을 받고 있습니다. 경기장 주변의 조경시설물은 방문객들에게 시각적 즐거움을 더합니다.

### 풍암저수지

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%ED%92%8D%EC%95%94%EC%A0%80%EC%88%98%EC%A7%80" target="_blank" rel="nofollow">풍암저수지 네이버 지도에서 보기</a>


![상무시민공원](https://tong.visitkorea.or.kr/cms/resource/77/1587777_image2_1.jpg)


풍암저수지는 광주광역시 서구 풍암동에 위치하며, 1956년에 농업용 목적으로 축조되었습니다. 이후 풍암택지 개발과 함께 이용객이 증가하였고, 1999년부터 국토공원화 시범사업으로 발전하여 전통정자와 목교 등이 설치되었습니다. 이곳은 물과 전통이 조화를 이루는 광주의 상징적인 쉼터로, 하루 수백 명의 방문객이 찾고 있습니다. 저수지 주변은 산책하기 좋은 환경으로 조성되어 있으며, 가족 단위 방문객들에게 적합한 공간입니다. 물가에서의 편안한 산책과 더불어 자연을 충분히 즐길 수 있는 장소로 많은 이들이 찾는 이유입니다. 특히, 저수지의 경치는 사계절 내내 변하는 모습으로 방문객들에게 새로운 경험을 제공합니다.

### 전평제

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%A0%84%ED%8F%89%EC%A0%9C" target="_blank" rel="nofollow">전평제 네이버 지도에서 보기</a>


전평제는 광주광역시 서구 전평길 1에 위치하며, 1943년에 농업용수 공급과 재해 방지를 위해 축조되었습니다. 이 저수지는 도심 근교에 방치되어 있다가 1999년부터 국토공원화 시범사업으로 쉼터로 조성되었습니다. 특히, 저수지 가운데 인공섬이 있어 목교가 설치되어 있어 수변 경관과 자연 탐방을 즐기기에 적합한 장소입니다. 가족 단위 여가 선용을 위한 공간으로 많은 사람들이 찾고 있으며, 저수지 주변의 자연 환경은 방문객들에게 편안함을 제공합니다. 또한, 이곳은 다양한 조경과 함께 여유로운 산책로가 조성되어 있어 자연과 함께하는 힐링을 경험할 수 있습니다.

### 상무시민공원

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%83%81%EB%AC%B4%EC%8B%9C%EB%AF%BC%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">상무시민공원 네이버 지도에서 보기</a>


상무시민공원은 광주광역시 서구 상무공원로 101에 위치하며, 서구 치평동의 신도심 아파트 단지 내에 자리잡고 있습니다. 1994년 11월 12일에 지정된 이 공원은 다양한 운동시설과 아름다운 수경관, 열린 광장, 조각공원 등으로 구성되어 있습니다. 광주에서 최대 규모의 공원으로, 인공호수 2개와 39,360㎡의 광장, 여러 체육시설이 마련되어 있어 지역 주민과 방문객들에게 다양한 여가 활동을 제공합니다. 공원 내에는 환경 조형 작품이 설치되어 있어 예술적인 감성을 느낄 수 있습니다. 이곳은 가족과 함께 운동을 하거나 산책을 즐기기에 좋으며, 편의시설도 잘 갖춰져 있어 방문객들에게 편리한 환경을 제공합니다.

## 방문 전 참고사항

이 코스를 방문하기 전에는 편안한 복장과 운동화를 준비하는 것이 좋습니다. 각 장소가 자연과 가까이 위치해 있어 걷기 좋은 환경이 조성되어 있습니다. 최적의 방문 시기는 봄과 가을로, 이 시기에는 날씨가 쾌적하여 산책하기 좋습니다. 여름철에는 햇볕이 강하므로 모자나 선크림을 챙기는 것이 필요합니다. 공식 사이트에서 확인이 필요합니다.

---

## 여행 준비에 도움되는 추천 용품

- [보바 그립 22.5W 고속충전 보조배터리 20000mAh](https://link.coupang.com/a/euAPTn) — 40,900원
- [카필드 차량용 흡착식 맥세이프 휴대폰거치대, 정품 카필드 블랙, 1개](https://link.coupang.com/a/euAPUF) — 54,500원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/09/2872309_image2_1.jpg" alt="천지유삼계탕" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">천지유삼계탕</strong><span class="nearby-card-addr">광주광역시 서구 풍금로 67</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B2%9C%EC%A7%80%EC%9C%A0%EC%82%BC%EA%B3%84%ED%83%95" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/66/2664566_image2_1.JPG" alt="김강심 칼국수" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">김강심 칼국수</strong><span class="nearby-card-addr">광주광역시 서구 회재로 841</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B9%80%EA%B0%95%EC%8B%AC%20%EC%B9%BC%EA%B5%AD%EC%88%98" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/61/2664561_image2_1.jpg" alt="금당" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">금당</strong><span class="nearby-card-addr">광주광역시 서구 송풍로17번길 15 (풍암동, 수정빌라)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B8%88%EB%8B%B9" target="_blank" rel="nofollow">지도에서 보기</a></div></div>