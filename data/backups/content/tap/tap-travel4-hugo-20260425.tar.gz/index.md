---
title: "경남 금대암과 통도사 자장암 여행 비교"
date: 2026-03-22
draft: false

---



## 경남 여행코스 코스 요약

![금대암](http://tong.visitkorea.or.kr/cms/resource/80/3590280_image2_1.jpg)


경남 여행코스는 총 5곳으로 구성된다. 각 장소는 가족 단위 여행객에게 적합하며, 아름다운 자연과 문화유산을 경험할 수 있다. 아래는 코스 순서와 소요 시간 등이다.

- **코스 순서**: 금대암 → 서암정사(함양) → 통도사 자장암 → 디피랑(DPIRANG) → 방곡마을
- **소요시간**: 약 6시간
- **입장료**: 무료 (일부 장소 제외)

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" 