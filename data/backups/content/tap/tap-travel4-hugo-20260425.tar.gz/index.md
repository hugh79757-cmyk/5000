---
title: "경남 여행코스, 부곡온천부터 서암정사까지 한눈에 보기"
date: 2026-03-22
draft: false

---



## 경남 여행코스 코스 요약

![부곡온천 관광특구](http://tong.visitkorea.or.kr/cms/resource/90/3589790_image2_1.jpg)

- **코스 순서**: 부곡온천 관광특구 → 방곡마을 → 서암정사(함양) → 대광사(창원) → 산청특리지석묘군
- **소요시간**: 약 6시간 (이동시간 포함)
- **입장료**: 무료

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.