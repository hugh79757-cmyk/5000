---
title: "광주 만귀정과 5·18 기념공원 포함 도보코스 4곳 메뉴 비교"
slug: '광주-만귀정과-518-기념공원-포함-도보코스-4곳-메뉴-비교'
date: '2026-04-23T23:55:08+09:00'
draft: false
description: "광주 도보코스 — 만귀정, 운천사마애여래좌상, 5·18 기념공원. 4곳 정보와 방문 팁 정리."
tags: ['여행코스', '도보코스', '광주']
categories: ['여행코스']
featureimage: "https://tong.visitkorea.or.kr/cms/resource/32/741832_image2_1.jpg"
---

## 광주 여행코스 요약

![만귀정](https://tong.visitkorea.or.kr/cms/resource/32/741832_image2_1.jpg)


광주에서의 여행코스는 서구 8경 중 4경을 탐방하는 도보 코스입니다. 이 코스에서는 **만귀정**, **운천사마애여래좌상**, **5·18 기념공원**, **양동시장**을 방문하게 됩니다. 자연과 문화유산이 어우러진 이곳에서 광주의 다채로운 매력을 경험할 수 있습니다.

## 코스 상세 안내

![운천사마애여래좌상](https://tong.visitkorea.or.kr/cms/resource/50/1587750_image2_1.jpg)


### 만귀정

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EB%A7%8C%EA%B7%80%EC%A0%95" target="_blank" rel="nofollow">만귀정 네이버 지도에서 보기</a>


![5·18 기념공원](https://tong.visitkorea.or.kr/cms/resource/92/1587792_image2_1.jpg)

만귀정은 광주광역시 서구 동하길 10에 위치한 정자로, 서구 세하동 동하마을에 자리 잡고 있습니다. 이 정자는 효우공 장창우가 후학을 가르치며 만년을 보내기 위해 창건하였습니다. 원래의 건물은 세월에 의해 무너졌으나, 후손들에 의해 1934년에 중건되고 1945년에 중수가 이루어졌습니다. 만귀정은 사방 두 칸의 규모로, 팔작지붕과 우물 마루로 구성되어 있습니다. 정자는 큰 연못 가운데 세워진 수중 정자로, 그 옆에는 습향각과 묵암정사가 나란히 위치해 있어 아름다운 경관을 자아냅니다. 이곳은 조용한 분위기 속에서 자연을 감상하며 휴식을 취하기 좋은 장소입니다.

### 운천사마애여래좌상

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%9A%B4%EC%B2%9C%EC%82%AC%EB%A7%88%EC%95%A0%EC%97%AC%EB%9E%98%EC%A2%8C%EC%83%81" target="_blank" rel="nofollow">운천사마애여래좌상 네이버 지도에서 보기</a>


![양동시장](https://tong.visitkorea.or.kr/cms/resource/56/1587756_image2_1.jpg)

운천사마애여래좌상은 광주광역시 서구 금호운천길 85-15에 위치하며, 원효대사가 무등산 원효사에 머무르던 시기에 세워진 전설이 전해집니다. 이 마애불은 큰 자연 암벽에 불상을 양각하여 조각한 것으로, 앉은 높이가 약 2m에 달하는 대형 불상입니다. 전해지는 이야기에는 제자 보광화상이 이곳에 불상을 새겼다는 내용이 포함되어 있으나, 고증할 기록이나 유물은 존재하지 않습니다. 불상은 중국 운강석굴의 대불을 연상시키며, 주변의 경치와 함께 신비로운 분위기를 자아냅니다. 이곳은 역사와 전통을 느낄 수 있는 장소로, 많은 이들이 방문하여 경외감을 느끼고 있습니다.

### 5·18 기념공원

<a class="naver-map-btn" href="https://map.naver.com/v5/search/5%C2%B718%20%EA%B8%B0%EB%85%90%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">5·18 기념공원 네이버 지도에서 보기</a>

5·18 기념공원은 광주광역시 서구 상무민주로 61에 위치한 시민 휴식공간입니다. 이 공원은 5·18의 교훈을 올바르게 계승하고 발전하기 위해 조성되었습니다. 넓이는 약 20만 4,985㎡로, 전통연못과 다양한 수목들이 조화롭게 어우러져 있어 자연 학습장으로도 활용되고 있습니다. 공원 내에는 시민들이 편안하게 쉴 수 있는 공간이 마련되어 있으며, 가족 단위 방문객들에게도 적합합니다. 이곳은 역사적인 의미를 지닌 장소로, 많은 이들이 5·18의 의미를 되새기며 방문합니다. 공원은 다양한 프로그램과 행사도 열리며, 지역 주민들에게 사랑받는 공간입니다.

### 양동시장

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%96%91%EB%8F%99%EC%8B%9C%EC%9E%A5" target="_blank" rel="nofollow">양동시장 네이버 지도에서 보기</a>

양동시장은 광주광역시 서구 천변좌로 238에 위치한 전통 시장입니다. 이 시장의 기원은 1910년대에 광주교 아래 백사장에서 시작되었으며, 일제강점기인 1940년에 현재의 위치로 이전하였습니다. 시장은 1969년 시영시장에서 민영시장으로 전환되었고, 현대적인 시설로 정비되어 있습니다. 현재 양동시장은 4개 동으로 구성되어 있으며, 농산물, 수산물, 공산품 등 다양한 물품을 취급하는 340여 개 점포가 있습니다. 특히 제수용품이나 혼수용품으로 유명하여, 많은 이들이 이곳을 찾아 쇼핑을 즐깁니다. 시장의 활기찬 분위기 속에서 지역의 특색을 느낄 수 있는 좋은 기회입니다.

## 방문 전 참고사항
여행을 계획할 때는 편안한 복장과 편한 신발을 준비하는 것이 좋습니다. 각 장소는 도보로 이동할 수 있는 거리이므로, 충분한 체력을 갖추는 것이 필요합니다. 최적의 방문 시기는 봄과 가을로, 날씨가 쾌적하여 산책하기 좋습니다. 또한, 양동시장은 정기휴일이 있으니 방문 전 공식 사이트에서 확인이 필요합니다. 각 장소의 입장료나 주차 요금 또한 공식 사이트에서 확인이 필요합니다. 광주 서구의 8경 탐방은 역사와 자연을 동시에 경험할 수 있는 소중한 시간이 될 것입니다.

---

## 여행 준비에 도움되는 추천 용품

- [스피덱스 여행용 파우치 6개 여행파우치 세트 고급형 원단 여행용 옷 파우치 캐리어 정리 파우치 세트 트래블파우치 여행용 옷 압축파우치 정리백 분리 보관 파우치](https://link.coupang.com/a/eu87fv) — 24,830원
- [바우아토 포켓쉴 고속 입출력 케이블 일체형 미니 대용량 난연 보조배터리 20000mAh C타입 애플8핀 PD 22.5W, 단일상품, 블랙](https://link.coupang.com/a/eu87gp) — 37,800원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/67/2864867_image2_1.jpg" alt="홍아네" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">홍아네</strong><span class="nearby-card-addr">광주광역시 서구 마륵복개로150번길 7</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%99%8D%EC%95%84%EB%84%A4" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/18/2606418_image2_1.jpg" alt="[백년가게]민들레" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">[백년가게]민들레</strong><span class="nearby-card-addr">광주광역시 서구 상무평화로 137</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%5B%EB%B0%B1%EB%85%84%EA%B0%80%EA%B2%8C%5D%EB%AF%BC%EB%93%A4%EB%A0%88" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/61/2863161_image2_1.jpg" alt="다도해물나라" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">다도해물나라</strong><span class="nearby-card-addr">광주광역시 서구 마륵복개로 57</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%8B%A4%EB%8F%84%ED%95%B4%EB%AC%BC%EB%82%98%EB%9D%BC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>