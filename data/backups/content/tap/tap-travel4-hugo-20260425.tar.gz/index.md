---
title: "경북 드라이브 코스 1곳, 주차 정보 포함"
date: 2026-03-21
draft: false

---



## 경북 여행코스 코스 요약

![동해안일주해안도로(울진), 등뼈를 타고 달리다!](http://tong.visitkorea.or.kr/cms/resource/22/2716522_image2_1.jpg)

경북 여행코스는 동해안일주해안도로를 따라 울진의 아름다움을 탐방하는 일정이다. 이 코스는 울진의 해안선을 따라 자연의 경관을 즐기며 드라이브할 수 있는 기회를 제공한다. 다음은 코스에 대한 요약이다.

- 장소명: 동해안일주해안도로(울진), 등뼈를 타고 달리다!
- 소요시간: 약 3시간
- 입장료: 없음

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" styl