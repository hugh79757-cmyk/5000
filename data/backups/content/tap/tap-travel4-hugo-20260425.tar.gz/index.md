---
title: "제주 김만덕기념관 포함 도보코스 5곳 미리 확인"
slug: '제주-김만덕기념관-포함-도보코스-5곳-미리-확인'
date: '2026-04-11T16:08:56+09:00'
draft: false
description: "제주 도보코스 — 김만덕기념관, 모충사, 사라봉공원. 5곳 정보와 방문 팁 정리."
tags: ['제주', '도보코스', '여행코스']
categories: ['여행코스']
---

## 제주 여행코스 요약

![김만덕기념관](https://tong.visitkorea.or.kr/cms/resource/30/3396630_image2_1.jpg)


제주 여행코스는 제주의 여장부 김만덕을 따라 걷는 산책입니다. 이 코스는 김만덕의 행적과 자취를 따라가며 제주도민의 생활상과 특산품을 함께 알아볼 수 있는 경험을 제공합니다. 코스는 다음과 같은 장소로 구성되어 있습니다:
- **김만덕기념관**
- **모충사**
- **사라봉공원**
- **사라봉**
- **산지등대**

## 코스 상세 안내

![모충사](https://tong.visitkorea.or.kr/cms/resource/91/1618591_image2_1.jpg)


### 김만덕기념관

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B9%80%EB%A7%8C%EB%8D%95%EA%B8%B0%EB%85%90%EA%B4%80" target="_blank" rel="nofollow">김만덕기념관 네이버 지도에서 보기</a>


![사라봉공원](https://tong.visitkorea.or.kr/cms/resource/92/197792_image2_1.jpg)

김만덕기념관은 제주특별자치도 제주시 산지로 7에 위치하고 있습니다. 김만덕(1739~1812)은 조선시대 제주 출신의 여성이자 유명한 거상 및 자선가로, 그녀의 선행을 기리기 위해 세워진 기념관입니다. 기념관 내부에는 김만덕의 일대기를 그린 다양한 작품들이 전시되어 있어, 그녀의 삶과 업적을 깊이 이해할 수 있는 기회를 제공합니다. 과거에는 유품 354점이 소장되었으나, 현재는 작품 중심으로 전시가 이루어지고 있습니다. 이곳은 제주 역사와 문화를 느낄 수 있는 중요한 장소이며, 김만덕의 정신을 기리는 의미가 깊습니다.

### 모충사

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EB%AA%A8%EC%B6%A9%EC%82%AC" target="_blank" rel="nofollow">모충사 네이버 지도에서 보기</a>


![사라봉](https://tong.visitkorea.or.kr/cms/resource/99/3053499_image2_1.jpg)

모충사는 제주특별자치도 제주시 건입동에 위치하여, 사라봉 공원 동남쪽에 있습니다. 이 사찰은 제주 주민의 성금으로 세워졌으며, 김만덕 할머니의 구혈의녀탑, 순국지사 조봉호 기념비, 의병항쟁 기념탑이 함께 있는 역사적인 장소입니다. 모충사는 단순한 관광지를 넘어, 민족의 정기가 깃든 의로운 신전으로 알려져 있습니다. 이곳을 방문하면 제주도의 역사와 민족의 아픔을 느낄 수 있으며, 지역 주민들의 자부심을 엿볼 수 있습니다. 사찰 주변의 조경과 함께 어우러진 분위기는 방문객에게 평화로운 시간을 제공합니다.

### 사라봉공원

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%82%AC%EB%9D%BC%EB%B4%89%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">사라봉공원 네이버 지도에서 보기</a>


![산지등대](https://tong.visitkorea.or.kr/cms/resource/39/3384639_image2_1.jpg)

사라봉공원은 제주특별자치도 제주시 사라봉길 75에 위치하고 있으며, 제주시 동문로터리에서 동쪽으로 2km 거리에 있습니다. 이 공원은 143m 높이의 낮은 동산으로, 사봉 낙조는 영주 12경의 하나로 손꼽힙니다. 북쪽으로는 바다, 남쪽으로는 한라산을 바라볼 수 있는 이곳은 제주시민과 관광객 모두에게 사랑받는 명소입니다. 사라봉 공원 동쪽에는 별도봉이 자리하고 있으며, 그 기슭에는 우당도서관이 있습니다. 이곳에서부터 사라봉 뒤편을 돌아 제주항을 거쳐 탑동까지 이어지는 드라이브 코스는 매우 유명합니다. 공원 내 다양한 산책로와 조경은 방문객에게 자연을 즐길 수 있는 소중한 공간을 제공합니다.

### 사라봉
사라봉은 제주특별자치도 제주시 사라봉동길 61에 위치하여, 제주항 동쪽 바닷가에 접해 있는 오름입니다. 제주시를 대표하는 오름으로, 이오름 봉우리에 오르면 북쪽으로는 망망한 바다, 남쪽으로는 웅장한 한라산이 펼쳐집니다. 발아래에는 제주시의 시가지와 주변 마을들이 그림처럼 아름답게 펼쳐져 있으며, 특히 저녁 붉은노을이 바다를 물들이는 광경은 장관입니다. 사라봉은 북서쪽으로 벌어진 말굽형 화구로, 붉은 송이로 구성된 기생화산체입니다. 이곳은 해송이 조림되어 숲을 이루고 있어, 자연과 함께하는 힐링의 시간을 제공합니다.

### 산지등대

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%82%B0%EC%A7%80%EB%93%B1%EB%8C%80" target="_blank" rel="nofollow">산지등대 네이버 지도에서 보기</a>

산지등대는 제주특별자치도 제주시 사라봉동길 108-1에 위치하고 있으며, 제주시민의 대표적인 공원인 사라봉 중턱 언덕 위에 있습니다. 이곳은 탐라의 관문인 제주항을 한눈에 조망할 수 있는 장소로, 해안 절벽과 바다가 어우러져 아름다운 해안선의 모습을 감상할 수 있습니다. 산지등대는 1916년 무인등대로 처음 점등되었고, 1999년 현재의 모습으로 새롭게 등탑이 신설되었습니다. 이곳은 제주항의 안전을 지키는 역할을 하며, 주변 경관과 함께 방문객들에게 잊지 못할 경험을 제공합니다.

## 방문 전 참고사항
이 코스를 즐기기 위해서는 편안한 복장과 충분한 물을 준비하는 것이 좋습니다. 최적의 방문 시기는 봄과 가을로, 날씨가 쾌적하여 도보 여행에 적합합니다. 각 장소의 입장료 및 주차요금은 공식 사이트에서 확인이 필요합니다. 제주도의 아름다운 자연과 역사적인 장소를 경험하며 소중한 추억을 만들어보는 기회를 놓치지 않기 바란다.

---

## 여행 준비에 도움되는 추천 용품

- [여성용 크로스백 여행용 심플 숄더백](https://link.coupang.com/a/emGjcY) — 29,400원
- [반디루 여행용 압축 파우치 세면파우치 포함 올인원 7종 세트](https://link.coupang.com/a/emGjg9) — 23,800원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 근처 맛집

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/74/2851074_image2_1.jpg" alt="산지해장국" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">산지해장국</strong><span class="nearby-card-addr">제주특별자치도 제주시 임항로 34</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%82%B0%EC%A7%80%ED%95%B4%EC%9E%A5%EA%B5%AD" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/01/2947401_image2_1.jpg" alt="롤링브루잉" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">롤링브루잉</strong><span class="nearby-card-addr">제주특별자치도 제주시 일도일동 1168-1</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%A1%A4%EB%A7%81%EB%B8%8C%EB%A3%A8%EC%9E%89" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/38/2899538_image2_1.jpg" alt="아베베베이커리" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">아베베베이커리</strong><span class="nearby-card-addr">제주특별자치도 제주시 동문로6길 4</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%95%84%EB%B2%A0%EB%B2%A0%EB%B2%A0%EC%9D%B4%EC%BB%A4%EB%A6%AC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

- [경기 가족코스 5곳 순서와 소요 시간 정리](/posts/경기-가족코스-5곳-순서와-소요-시간-정리/)
- [인천 석모도와 민머루해변 포함 힐링코스 4곳 꿀팁](/posts/인천-석모도와-민머루해변-포함-힐링코스-4곳-꿀팁/)
- [경남 당항포관광지 포함 캠핑코스 6곳 미리 확인](/posts/경남-당항포관광지-포함-캠핑코스-6곳-미리-확인/)