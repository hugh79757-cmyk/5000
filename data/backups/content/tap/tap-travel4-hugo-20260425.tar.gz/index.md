---
title: "대구 여행코스 코스별 소요 시간과 이동 거리 정리"
date: 2026-03-23
draft: false

---



## 대구 여행코스 코스 요약

![신숭겸장군유적](https://tong.visitkorea.or.kr/cms/resource/93/3570793_image2_1.jpg)


- **코스 순서**: 신숭겸장군유적 → 앞산카페거리 → 봉무정
- **소요시간**: 약 4시간
- **입장료**: 없음

## 코스 상세 안내

![앞산카페거리](https://tong.visitkorea.or.kr/cms/resource/87/3569987_image2_1.JPG)


### 신숭겸장군유적

> [신숭겸장군유적 네이버 지도에서 보기](https://map.naver.com/v5/search/%EC%8B%A0%EC%88%AD%EA%B2%B8%EC%9E%A5%EA%B5%B0%EC%9C%A0%EC%A0%81)

신숭겸장군유적은 대구광역시 동구에 위치한 역사적인 장소이다. 이곳은 신숭겸 장군의 업적을 기리기 위해 조성된 유적으로, 다양한 역사적 소장품과 전시물이 있다. 주변에는 넓은 공원이 있