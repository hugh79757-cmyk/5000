---
title: "사진 명소 위주 대구 여행코스 5곳 코스 추천"
date: 2026-03-23
draft: false

---



## 대구 여행코스 코스 요약

![경상감영공원](https://tong.visitkorea.or.kr/cms/resource/44/3310544_image2_1.jpg)


- 출발 장소: 경상감영공원
- 이동 경로: 경상감영공원 → 동화사(대구) → 관암사(대구) → 한밤마을 → 교남YMCA 회관
- 소요시간: 약 6~8시간
- 입장료: 무료

## 코스 상세 안내

![한밤마을](https://tong.visitkorea.or.kr/cms/resource/68/3571368_image2_1.jpg)


### 경상감영공원

> [경상감영공원 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B2%BD%EC%83%81%EA%B0%90%EC%98%81%EA%B3%B5%EC%9B%90)
경상감영공원은 대구 중구 경상감영길에 위치하고 있으며, 대구의 역사와 문화를 느낄 수 있는 공간이다. 공원 내부에는 넓은 잔디밭과 산책로가 조성되어 있어 산책