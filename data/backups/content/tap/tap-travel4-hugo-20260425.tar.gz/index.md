---
title: "강원 원주 소금산 울렁다리 여행 한눈에 보기"
date: 2026-03-22
draft: false

---



## 강원 여행코스 코스 요약

![원주 소금산 울렁다리](https://tong.visitkorea.or.kr/cms/resource/78/2814478_image2_1.jpg)


- **코스 순서**: 
  1. 원주 소금산 울렁다리
  2. 행복&피크닉
  3. 봄내향기공방
  4. 삼척 가시오가피마을
  5. 요선정·요선암

- **소요시간**: 약 7시간 
- **입장료**: 무료 또는 별도 비용 발생 장소 있음

## 코스 상세 안내

![행복&피크닉](https://tong.visitkorea.or.kr/cms/resource/72/3588072_image2_1.jpg)


### 원주 소금산 울렁다리

> [원주 소금산 울렁다리 네이버 지도에서 보기](https://map.naver.com/v5/search/%EC%9B%90%EC%A3%BC%20%EC%86%8C%EA%B8%88%EC%82%B0%20%EC%9A%B8%EB%A0%81%EB%8B%A4%EB%A6%AC)