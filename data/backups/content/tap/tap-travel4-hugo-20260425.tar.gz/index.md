---
title: "광주 오웬기념각 포함 도보코스 4곳 정리"
slug: '광주-오웬기념각-포함-도보코스-4곳-정리'
date: '2026-03-31T07:08:58+09:00'
draft: false
description: "광주 도보코스 — 오웬기념각, 이장우가옥, 우일선 선교사 사택. 4곳 정보와 방문 팁 정리."
tags: ['광주', '여행코스', '도보코스']
categories: ['여행코스']
---

## 광주 여행코스 요약

![오웬기념각](https://tong.visitkorea.or.kr/cms/resource/00/3408000_image2_1.png)


광주에서의 여행코스는 '근현대를 넘나드는 100년 여행'입니다. 이 코스는 역사와 현대가 어우러진 장소들을 탐방하며, 광주의 과거와 현재를 동시에 체험할 수 있습니다. 코스는 다음과 같은 순서로 진행됩니다:  
**1. 오웬기념각**  
**2. 이장우가옥**  
**3. 우일선 선교사 사택**  
**4. 충장로**

## 코스 상세 안내

![이장우가옥](https://tong.visitkorea.or.kr/cms/resource/95/1587495_image2_1.jpg)


### 오웬기념각

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%98%A4%EC%9B%AC%EA%B8%B0%EB%85%90%EA%B0%81" target="_blank" rel="nofollow">오웬기념각 네이버 지도에서 보기</a>


![우일선 선교사 사택](https://tong.visitkorea.or.kr/cms/resource/18/1995318_image2_1.jpg)

오웬기념각은 광주광역시 남구 백서로70번길 6에 위치해 있으며, 기독병원 간호전문대학 내에 있습니다. 이 건물은 전남 지역 최초의 선교사인 클레멘트 C. 오웬을 기리기 위해 1914년에 세워졌습니다. 연면적 434평방미터의 양옥건물로, 당시 예배당 및 집회실로 사용되었던 것으로 추정됩니다. 현재는 기독병원 간호전문대학의 강당으로 활용되고 있습니다. 오웬기념각은 역사적 의미와 함께 건축물로서의 가치도 지니고 있어, 방문객들에게 깊은 인상을 남깁니다. 이곳에서 광주의 선교 역사와 오웬 선교사의 삶을 살펴볼 수 있는 기회를 제공합니다.

### 이장우가옥

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%9D%B4%EC%9E%A5%EC%9A%B0%EA%B0%80%EC%98%A5" target="_blank" rel="nofollow">이장우가옥 네이버 지도에서 보기</a>


![충장로](https://tong.visitkorea.or.kr/cms/resource/06/1587606_image2_1.jpg)

이장우가옥은 광주광역시 남구 양촌길 21에 위치한 전통 기와집입니다. 이 가옥은 대문간, 곳간채, 행랑채, 사랑채, 안채로 구성되어 있으며, 1899년에 건축된 것으로 확인됩니다. 안채의 상량문에는 '광무삼년을해이월십일축시'라는 기록이 있어 역사적 가치를 더욱 높입니다. 전반적으로 굵은 뼈대와 잘 보존된 원형을 자랑하는 이장우가옥은 한국 전통 가옥의 아름다움을 느낄 수 있는 공간입니다. 또한, 이곳은 광주의 근대사를 이해하는 데 중요한 역할을 하는 장소로, 방문객들에게 한국의 전통 건축양식을 체험할 수 있는 기회를 제공합니다. 이장우가옥의 고즈넉한 분위기 속에서 과거의 일상을 상상해보는 것도 흥미로운 경험입니다.

### 우일선 선교사 사택

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%9A%B0%EC%9D%BC%EC%84%A0%20%EC%84%A0%EA%B5%90%EC%82%AC%20%EC%82%AC%ED%83%9D" target="_blank" rel="nofollow">우일선 선교사 사택 네이버 지도에서 보기</a>

우일선 선교사 사택은 광주광역시 남구 제중로47번길 20에 위치한 2층 벽돌 건물입니다. 이 건물은 양림산 기슭에 동향으로 세워져 있으며, 광주에서 가장 오래된 양식 주택으로 알려져 있습니다. 미국인 선교사 우일선에 의해 1920년대에 지어진 것으로 전해지지만, 정확한 건립 연대는 확인되지 않았습니다. 현재는 내부가 개조되어 대한예수교 장로회 사무실로 사용되고 있으며, 한국 근대 건축의 흐름을 이해하는 데 중요한 자료로 평가받고 있습니다. 우일선 선교사 사택은 역사적 가치뿐만 아니라, 근대 건축의 아름다움도 함께 느낄 수 있는 장소로, 방문객들에게 깊은 감동을 줍니다.

### 충장로

<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%B6%A9%EC%9E%A5%EB%A1%9C" target="_blank" rel="nofollow">충장로 네이버 지도에서 보기</a>

충장로는 광주광역시 동구 서석로 37에 위치한 패션의 거리로, 광주의 명동거리라고 불립니다. 이곳은 광주의 최신 유행을 한눈에 볼 수 있는 곳으로, 충장공 김덕령장군의 충절을 기리기 위해 1946년부터 충장로라는 이름이 붙여졌습니다. 충장로 1가에서 3가까지는 대형 패션몰과 의류매장, 액세서리, 각종 잡화들이 즐비해 있으며, 다양한 상품을 한자리에서 만나볼 수 있습니다. 특히, 4가와 5가에는 전통혼례 한복과 개량한복을 판매하는 한복집들이 모여 있어, 한국의 전통 의상을 구매할 수 있는 기회도 제공합니다. 충장로는 현대적인 분위기와 전통이 어우러진 곳으로, 쇼핑과 문화 체험을 동시에 즐길 수 있는 최적의 장소입니다.

## 방문 전 참고사항
이 코스를 탐방하기 위해서는 편안한 복장과 신발을 준비하는 것이 좋습니다. 도보로 이동하는 코스이므로, 충분한 수분을 섭취하고 중간중간 휴식을 취하는 것이 필요합니다. 최적의 방문 시기는 날씨가 온화한 봄이나 가을로, 쾌적한 환경에서 여행을 즐길 수 있습니다. 각 장소의 입장료 및 운영 시간은 공식 사이트에서 확인이 필요합니다. 광주에서의 역사적인 여정을 통해 과거와 현재를 동시에 느껴보는 시간을 가져보길 권장합니다.

---

## 여행 준비에 도움되는 추천 용품

- [요이치 욜로4세대 블루투스 삼각대 셀카봉, WT800(블랙), 1개](https://link.coupang.com/a/eeLvdr) — 39,800원
- [에이덤스 차량용 듀얼 고속 무선충전 거치대 대시보드 흡착형 Z 플립 Flip 호환](https://link.coupang.com/a/eeLve9) — 28,790원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/57/3402457_image2_1.JPG" alt="10년후그라운드" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">10년후그라운드</strong><span class="nearby-card-addr">광주광역시 남구 양촌길 1</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/10%EB%85%84%ED%9B%84%EA%B7%B8%EB%9D%BC%EC%9A%B4%EB%93%9C" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/85/2664685_image2_1.png" alt="메타포" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">메타포</strong><span class="nearby-card-addr">광주광역시 남구 백서로 69</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%A9%94%ED%83%80%ED%8F%AC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/93/2823293_image2_1.jpg" alt="이이남스튜디오" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">이이남스튜디오</strong><span class="nearby-card-addr">광주광역시 남구 제중로47번길 10 이이남스튜디오</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9D%B4%EC%9D%B4%EB%82%A8%EC%8A%A4%ED%8A%9C%EB%94%94%EC%98%A4" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

- [서울 당일치기 여행코스 스토리지북앤필름 포함 5곳](/posts/서울-당일치기-여행코스-스토리지북앤필름-포함-5곳/)
- [울산 외고산옹기마을 포함 여행코스 5곳 정리](/posts/울산-외고산옹기마을-포함-여행코스-5곳-정리/)
- [경기 힐링코스 3곳 순서와 볼거리 총정리](/posts/경기-힐링코스-3곳-순서와-볼거리-총정리/)