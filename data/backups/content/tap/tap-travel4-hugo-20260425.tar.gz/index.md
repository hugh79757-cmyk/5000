---
title: "예산 10만원으로 즐기는 제주 여행코스 5곳 코스"
date: 2026-03-22
draft: false

---



## 제주 여행코스 코스 요약

![하도어촌체험마을](http://tong.visitkorea.or.kr/cms/resource/91/3412991_image2_1.jpg)


- **코스 순서**: 하도어촌체험마을 → 코코컬처클럽 → 녹산로 유채꽃도로 → 일출랜드 → 더마파크
- **소요시간**: 약 6시간
- **입장료**: 무료 또는 별도 요금 없음

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.