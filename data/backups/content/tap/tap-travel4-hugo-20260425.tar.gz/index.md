---
title: "대구 북지장사와 수성못 한눈에 보기"
date: 2026-03-23
draft: false

---



## 대구 여행코스 코스 요약

![북지장사(대구)](https://tong.visitkorea.or.kr/cms/resource/99/3590699_image2_1.jpg)

- **여행코스 순서**: 북지장사 → 수성못 유원지 → 백련사  
- **장소명**: 북지장사, 수성못 유원지, 백련사  
- **소요시간**: 약 6시간  
- **입장료**: 무료 (모든 장소)  

## 코스 상세 안내

![수성못 유원지](https://tong.visitkorea.or.kr/cms/resource/51/2653751_image2_1.jpg)


### 북지장사(대구)

> [북지장사(대구) 네이버 지도에서 보기](https://map.naver.com/v5/search/%EB%B6%81%EC%A7%80%EC%9E%A5%EC%82%AC%28%EB%8C%80%EA%B5%AC%29)
북지장사는 대구 동구 도장길에 위치한 사찰로, 대구의 대표적인 불교 명소 중 하나다. 이곳은 조용한 산