---
title: "대구 이천동 고미술거리와 여행 체크리스트"
date: 2026-03-22
draft: false

---



## 대구 여행코스 코스 요약

![이천동 고미술거리](http://tong.visitkorea.or.kr/cms/resource/57/3569957_image2_1.JPG)

- **코스 순서**: 이천동 고미술거리 → 백련사 → 앞산카페거리 → 이월드 → 충혼탑
- **소요시간**: 약 6시간
- **입장료**: 무료(단, 이월드 이용 시 별도 입장료 필요)

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage