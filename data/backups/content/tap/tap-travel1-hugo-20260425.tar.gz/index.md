---
title: "경기 광주시 축제, 현지인이 알려주는 알짜 코스"
date: 2026-04-04
draft: false

---

<!-- DESC: 경기 광주시 축제 — 광주왕실도자페스티벌. 1곳 정보와 방문 팁 정리. -->
## 경기 광주시 축제 개요와 일정

![광주왕실도자페스티벌](https://tong.visitkorea.or.kr/cms/resource/20/3481720_image2_1.jpg)


경기 광주시에서 열리는 광주왕실도자페스티벌은 2026년 4월 24일부터 5월 5일까지 진행됩니다. 이 축제는 곤지암도자공원에서 개최되며, 입장료는 무료입니다. 주최는 광주시이며, 다양한 프로그램과 체험 활동이 마련되어 있습니다. 축제 기간 동안 방문객들은 왕실도자에 대한 깊이 있는 이해를 돕는 전시와 공연, 체험을 통해 특별한 시간을 보낼 수 있습니다. 이 축제는 도자기와 관련된 문화유산을 알리고, 지역의 예술을 경험할 수 있는 좋은 기회입니다.

## 주요 프로그램과 체험

광주왕실도자페스티벌에서는 여러 가지 흥미로운 프로그램이 마련되어 있습니다. 첫 번째로, 광주왕실도자 전시 및 판매가 진행되어 방문객들은 다양한 왕실도자 작품을 직접 감상할 수 있습니다. 또한, 왕실도자 명장전이 열려 전통 도자기의 아름다움과 가치를 느낄 수 있습니다. 공연 프로그램으로는 버스킹 및 프린지 공연이 예정되어 있어, 다양한 장르의 음악과 공연을 즐길 수 있습니다. 마지막으로, 참여형 체험 프로그램으로는 인스톨레이션 아트, 리버마켓, 분원오락실, 도공의 하루(왕실도자체험), 역사문화 만들기 체험 등이 마련되어 있어, 방문객들이 직접 참여하고 체험할 수 있는 기회를 제공합니다.

## 교통과 주차 안내

광주왕실도자페스티벌이 열리는 곤지암도자공원은 경기도 광주시 곤지암읍 경충대로 727에 위치하고 있습니다. 자가용으로 방문할 경우, 경충대로를 따라 이동하면 쉽게 도착할 수 있습니다. 대중교통을 이용할 경우, 광주역이나 분당선 곤지암역에서 하차 후 택시를 이용하거나 도보로 이동할 수 있습니다. 주차 가능 여부와 요금은 공식 사이트에서 확인하는 것이 좋습니다. 현장 주차 공간이 부족할 수 있으므로 대중교통 이용을 권장합니다.

## 방문 전 참고 사항

광주왕실도자페스티벌을 방문하기에 가장 좋은 시간대는 오전 10시에서 오후 12시 사이입니다. 이 시간대는 비교적 혼잡하지 않아 여유롭게 축제를 즐길 수 있습니다. 또한, 날씨에 맞는 복장을 준비하는 것이 중요합니다. 봄철에 열리는 축제이므로 가벼운 외투나 겉옷을 챙기는 것이 좋습니다. 혼잡을 피하고 싶다면 주말보다는 평일 방문을 고려하는 것이 좋습니다. 축제 기간 동안 다양한 프로그램이 진행되므로, 미리 공식 웹사이트를 통해 일정과 프로그램을 확인하는 것이 유익합니다.

---

## 여행 준비에 도움되는 추천 용품

- [솜솜라이크 여행용 경량 피크닉매트 미니 방수 돗자리, 스트라이프 옐로우](https://link.coupang.com/a/ehHSfG) — 24,900원
- [바우아토 포켓쉴 고속 입출력 케이블 일체형 미니 대용량 난연 보조배터리 20000mAh C타입 애플8핀 PD 22.5W, 단일상품, 아이보리](https://link.coupang.com/a/ehHSiO) — 37,800원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 근처 가볼 만한 곳

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/16/3072516_image2_1.jpg" alt="광주 곤지암도자공원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">광주 곤지암도자공원</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 경충대로 727</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EA%B3%A4%EC%A7%80%EC%95%94%EB%8F%84%EC%9E%90%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/27/3527227_image2_1.jpg" alt="호국생활체육공원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">호국생활체육공원</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 평촌길 12-137</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%98%B8%EA%B5%AD%EC%83%9D%ED%99%9C%EC%B2%B4%EC%9C%A1%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/93/2862193_image2_1.jpg" alt="곤지바위" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">곤지바위</strong><span class="nearby-card-addr">경기도 광주시 곤지암로 72</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B3%A4%EC%A7%80%EB%B0%94%EC%9C%84" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



## 근처 맛집

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/51/2750551_image2_1.png" alt="시래마루" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">시래마루</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 경충대로 661</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%8B%9C%EB%9E%98%EB%A7%88%EB%A3%A8" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/41/2750441_image2_1.png" alt="동동국수 본점" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">동동국수 본점</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 도척로 20</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%8F%99%EB%8F%99%EA%B5%AD%EC%88%98%20%EB%B3%B8%EC%A0%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/03/2865503_image2_1.jpg" alt="우해정" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">우해정</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 곤지암천로 248</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9A%B0%ED%95%B4%EC%A0%95" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

{{< article link="/posts/2026-전북-축제행사-일정과-입장료-총정리/" >}}

{{< article link="/posts/강원-양양송이축제-일정과-즐길-거리-한눈에-보기/" >}}

{{< article link="/posts/부산-해운대구-2026-부산국제보트쇼-포함-축제-정보-한눈에-보기/" >}}



<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EC%99%95%EC%8B%A4%EB%8F%84%EC%9E%90%ED%8E%98%EC%8A%A4%ED%8B%B0%EB%B2%8C" target="_blank" rel="nofollow">광주왕실도자페스티벌 네이버 지도에서 보기</a>