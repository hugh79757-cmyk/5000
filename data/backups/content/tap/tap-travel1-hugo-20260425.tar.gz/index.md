---
title: "광주 축제·행사 근처 맛집까지 한번에 정리"
date: 2026-03-20
draft: false

---

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**

## 광주여성영화제와 함께하는 특별한 여름의 하루

> [광주여성영화제 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EC%97%AC%EC%84%B1%EC%98%81%ED%99%94%EC%A0%9C)

![광주여성영화제](http://tong.visitkorea.or.kr/cms/resource/26/3460726_image2_1.jpg)

2026년 5월 6일부터 5월 10일까지 광주에서 열리는 광주여성영화제는 . 영화와 문화가 어우러지는 이 축제에 참여해보자. 

## 광주여성영화제 주차장 3곳 위치와 요금

> [광주여성영화제 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EC%97%AC%EC%84%B1%EC%98%81%ED%99%94%EC%A0