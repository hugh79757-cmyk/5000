---
title: "광주 동구 국가유산야행 포함 축제 3곳 미리 확인"
slug: '광주-동구-국가유산야행-포함-축제-3곳-미리-확인'
date: '2026-04-05T16:03:06+09:00'
draft: false
description: "광주 동구 축제 — 광주국가유산야행. 1곳 정보와 방문 팁 정리."
tags: ['축제', '광주 동구', 'festival']
categories: ['festival']
---

## 광주 동구 축제 개요와 일정

![광주국가유산야행](https://tong.visitkorea.or.kr/cms/resource/70/4053670_image2_1.jpg)


광주 동구에서 열리는 "광주국가유산야행"은 2026년 4월 24일부터 4월 25일까지 이틀 동안 진행됩니다. 행사 장소는 광주광역시 동구 문화전당로 38에 위치한 5·18민주광장 등으로, 지역의 역사와 문화를 체험할 수 있는 기회를 제공합니다. 이 축제는 광주광역시 동구가 주최하며, 다양한 프로그램을 통해 방문객들에게 흥미로운 경험을 선사합니다. 입장료는 무료이나, 일부 유료 프로그램이 있을 수 있으니 사전 확인이 필요합니다. 운영 시간은 매일 오후 6시부터 10시까지입니다.

## 주요 프로그램과 체험

광주국가유산야행에서는 다양한 프로그램과 체험이 마련되어 있습니다. 첫째, 야경을 테마로 한 프로그램으로 빛터널 '함께 걷는 읍성길', 시간의 등 만들기, 전남도청 미디어파사드 '빛의 집' 등이 있습니다. 둘째, 야로 프로그램에서는 야행 여행자센터 '달빛사랑방', 광주목사 행차 재현, 어린이 해설사 투어, 지식가이드 투어 등을 통해 역사적 체험을 할 수 있습니다. 셋째, 야사 프로그램으로는 렉처콘서트 '건축가의 고민', 건축 미로 탈출 '도청 회의실의 보물을 찾아라', 광주읍성 체험극 '사또의 하루' 등이 준비되어 있습니다. 넷째, 야화 프로그램에서는 '건축가의 방' 전시, 그림자극 '재명석등의 소원', 광주읍성 미디어아트&디오라마 '광주읍성 풍경'을 통해 예술적 경험을 제공합니다. 마지막으로, 야설 프로그램에서는 개막 음악극 '세 개의 시간', 도청 앞 작은 음악회, 전통공연 '판' 등이 진행됩니다.

## 교통과 주차 안내

광주국가유산야행에 방문하기 위해서는 대중교통을 이용하는 것이 편리합니다. 행사 장소인 5·18민주광장까지는 광주 지하철 1호선을 이용하여 '문화전당역'에서 하차한 후 도보로 이동할 수 있습니다. 또한, 시내버스를 이용할 경우 '문화전당' 정류장에서 하차하면 됩니다. 주차 정보는 공식 웹사이트를 통해 확인하는 것이 좋습니다. 주차 공간이 제한적일 수 있으니 대중교통 이용을 권장합니다. 행사 기간 동안 교통 혼잡이 예상되므로, 미리 도착하여 여유롭게 행사에 참여하는 것이 좋습니다.

## 방문 전 참고 사항

광주국가유산야행을 방문하기에 가장 좋은 시간대는 저녁 6시 이후입니다. 이 시간대에 방문하면 다양한 프로그램과 야경을 함께 즐길 수 있습니다. 복장에 있어서는 편안한 복장을 추천합니다. 특히, 야외 행사이므로 날씨에 따라 겉옷을 준비하는 것이 좋습니다. 혼잡을 피하고 싶다면, 행사 첫날이나 마지막 날의 이른 시간에 도착하는 것이 유리합니다. 또한, 다양한 프로그램이 동시에 진행되므로 미리 원하는 프로그램의 시간을 체크하고 계획을 세우는 것이 필요합니다. 행사 장소 주변에는 여러 편의시설이 마련되어 있으니, 필요한 경우 미리 알아두는 것이 좋습니다.

---

## 여행 준비에 도움되는 추천 용품

- [New 대형냉각패드 위니쿨 급속냉각 넥선풍기 BLDC 대용량5200mAh, W1026, 클래식화이트](https://link.coupang.com/a/eixk7K) — 58,600원
- [일상HO감 4세대 초대형 장우산 보다 큰 3단우산 여행 등산 카라비너 골프우산](https://link.coupang.com/a/eixlaR) — 24,310원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 근처 가볼 만한 곳

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/99/3351399_image2_1.jpg" alt="충장로" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">충장로</strong><span class="nearby-card-addr">광주광역시 동구 서석로 37 (충장로1가)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B6%A9%EC%9E%A5%EB%A1%9C" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/58/3453358_image2_1.jpg" alt="광주 충장로 케이팝 스타의 거리" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">광주 충장로 케이팝 스타의 거리</strong><span class="nearby-card-addr">광주광역시 동구 충장로 94 (충장로2가)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EC%B6%A9%EC%9E%A5%EB%A1%9C%20%EC%BC%80%EC%9D%B4%ED%8C%9D%20%EC%8A%A4%ED%83%80%EC%9D%98%20%EA%B1%B0%EB%A6%AC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/71/3556671_image2_1.jpeg" alt="충장로 홍콩골목" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">충장로 홍콩골목</strong><span class="nearby-card-addr">광주광역시 동구 충장로안길 5-2 (충장로3가)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B6%A9%EC%9E%A5%EB%A1%9C%20%ED%99%8D%EC%BD%A9%EA%B3%A8%EB%AA%A9" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



## 근처 맛집

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/41/3454441_image2_1.jpg" alt="카페진정성" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">카페진정성</strong><span class="nearby-card-addr">광주광역시 동구 문화전당로 38 (광산동)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B9%B4%ED%8E%98%EC%A7%84%EC%A0%95%EC%84%B1" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/94/2665094_image2_1.jpg" alt="장독대" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">장독대</strong><span class="nearby-card-addr">광주광역시 동구 문화전당로 43 3층</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9E%A5%EB%8F%85%EB%8C%80" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/53/2668053_image2_1.jpg" alt="퍼스트네팔" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">퍼스트네팔</strong><span class="nearby-card-addr">광주광역시 동구 서석로7번길 6-44</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%8D%BC%EC%8A%A4%ED%8A%B8%EB%84%A4%ED%8C%94" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

- [2026 충남 태안군 축제, 놓치면 후회할 일정과 꿀팁](/posts/2026-충남-태안군-축제-놓치면-후회할-일정과-꿀팁/)
- [광주 서구 양동통맥축제와 함께 즐길 3곳 미리 확인](/posts/광주-서구-양동통맥축제와-함께-즐길-3곳-미리-확인/)
- [경기 고양시 2026 대한민국 과학 축제 한눈에](/posts/경기-고양시-2026-대한민국-과학-축제-한눈에/)