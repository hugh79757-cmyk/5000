---
title: "광주 축제·행사 일정부터 주차까지 한눈에 보기"
slug: '광주-축제행사-일정부터-주차까지-한눈에-보기'
date: '2026-03-21T11:28:33+09:00'
draft: false
description: "광주에서 열리는 다양한 축제와 행사는 2026년 가을 예정으로 다채로운 프로그램을 제공합니다. 이번 블로그에서는 광주에서 열리는 축제와 행사에 대한 구체적인 정보와"
tags: ['축제', '광주', '축제·행사']
categories: ['축제']
---

## 광주 축제 2025: 다채로운 행사와 함께하는 즐거운 시간

> [광주 버스킹 월드컵 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EB%B2%84%EC%8A%A4%ED%82%B9%20%EC%9B%94%EB%93%9C%EC%BB%B5)

![광주서창억새축제](http://tong.visitkorea.or.kr/cms/resource/22/3546722_image2_1.jpg)

광주에서 열리는 다양한 축제와 행사는 2025년 가을 예정으로 다채로운 프로그램을 제공합니다. 이번 블로그에서는 광주에서 열리는 축제와 행사에 대한 구체적인 정보와 함께, 편리하게 축제를 즐길 수 있는 팁을 소개합니다.

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>

## 광주 축제 타임테이블 정리 (시간대별 프로그램)

> [광주 버스킹 월드컵 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EB%B2%84%EC%8A%A4%ED%82%B9%20%EC%9B%94%EB%93%9C%EC%BB%B5)

![광주국제미술전람회 〈아트광주24〉](http://tong.visitkorea.or.kr/cms/resource/30/3382730_image2_1.jpg)

2025년 광주에서 열리는 축제들은 각기 다른 매력을 가지고 있습니다. 예를 들어, 렛츠플로피(Let's FLOPPY 3.0)는 다양한 아트 프로그램과 공연이 펼쳐지며, 주말 오전 10시부터 오후 6시까지 운영됩니다. 광주 버스킹 월드컵은 오후 1시부터 시작되며, 거리 공연과 다양한 장르의 음악이 어우러집니다. 광주서창억새축제는 일몰 전후의 아름다운 풍경을 즐길 수 있어, 오후 5시부터 개막됩니다. 각 프로그램의 시간대를 미리 확인하고 일정을 계획하면 더욱 알찬 경험이 될 것입니다.

## 대중교통으로 가는 법 (버스·지하철 노선)

광주를 방문할 때 대중교통을 이용하는 것이 편리합니다. 광주 지하철 1호선을 이용하면 렛츠플로피(Let's FLOPPY 3.0)와 광주국제미술전람회 〈아트광주24〉에 쉽게 접근할 수 있습니다. 금남로1가역에서 하차 후 5분 거리로 도보 이동이 가능합니다. 광주 버스킹 월드컵은 금남로1가에 위치해 있어, 해당 지역의 여러 버스 노선을 통해 접근할 수 있습니다. 버스 노선은 100, 200번 등이 있으며, 자주 배차되므로 대기시간이 길지 않습니다.

## 광주서창억새축제 주차장 3곳 위치와 요금

> [광주 버스킹 월드컵 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EB%B2%84%EC%8A%A4%ED%82%B9%20%EC%9B%94%EB%93%9C%EC%BB%B5)

광주서창억새축제를 방문할 경우, 주차 공간이 한정적이므로 사전 준비가 필요합니다. 축제장 근처에는 총 3곳의 주차장이 있으며, 각각 50대, 70대, 80대를 수용할 수 있습니다. 주차 요금은 1시간당 1,000원으로, 하루 최대 5,000원이 부과됩니다. 주말 오전 시간대는 주차장이 빠르게 만차가 되므로, 오전 9시 이전에 도착하는 것이 좋습니다. 주차가 어려운 경우, 대중교통을 이용하는 것이 더 효율적입니다.

## 광주 축제와 묶어 갈 당일치기 코스

> [광주 버스킹 월드컵 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EB%B2%84%EC%8A%A4%ED%82%B9%20%EC%9B%94%EB%93%9C%EC%BB%B5)

광주에서 축제를 즐기는 것 외에도 다양한 관광지를 함께 방문할 수 있습니다. 광주국제미술전람회 〈아트광주24〉를 관람한 후, 인근의 광주민속촌을 방문하면 지역의 전통 문화를 체험할 수 있습니다. 또한, 비어페스트 광주에서 시원한 맥주와 함께 지역의 먹거리를 즐기는 것도 좋은 선택입니다. 당일치기로 충분히 즐길 수 있는 코스이므로, 일정을 미리 세워보면 좋습니다.

**기간** 2025년 가을 예정 / **장소** 광주광역시 서구 상무누리로 30 / **입장료** 무료 / **주차** 주차장 유, 요금 1시간 1,000원 

광주 축제를 방문할 때는 날씨에 맞는 복장이 필요합니다. 가을철은 아침 저녁으로 쌀쌀하므로 가벼운 외투를 챙기는 것이 좋습니다. 혼잡을 피하고 싶다면, 주말보다는 평일 방문을 고려해보세요. 네이버 예약에서 광주 축제를 검색하여 사전접수를 하면 대기 없이 입장할 수 있습니다.

<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://www.trip.com/?Allianceid=3993748&SID=travel_blog" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>

## 반경 10km 내 가볼만한 곳

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%9A%B4%EC%B2%9C%EC%A0%80%EC%88%98%EC%A7%80" target="_blank">운천저수지 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%9A%B4%EC%B2%9C%EC%82%AC%EB%A7%88%EC%95%A0%EC%97%AC%EB%9E%98%EC%A2%8C%EC%83%81" target="_blank">운천사마애여래좌상 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%85%8C%EB%9D%BC%ED%94%BC%20%EC%8A%A4%ED%8C%8C%20%EC%86%8C%EB%B2%A0" target="_blank">테라피 스파 소베 지도에서 보기</a>

## 반경 10km 내 맛집

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%99%8D%EC%95%84%EB%84%A4" target="_blank">홍아네 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%5B%EB%B0%B1%EB%85%84%EA%B0%80%EA%B2%8C%5D%EB%AF%BC%EB%93%A4%EB%A0%88" target="_blank">[백년가게]민들레 지도에서 보기</a>

전화: 062-374-8760

<a class="nearby-link" href="https://map.naver.com/v5/search/%EB%8B%A4%EB%8F%84%ED%95%B4%EB%AC%BC%EB%82%98%EB%9D%BC" target="_blank">다도해물나라 지도에서 보기</a>

---

## 여행 준비에 도움되는 추천 용품

- [바우아토 원터치 블루투스 셀카봉 삼각대](https://link.coupang.com/a/d95Twc) — 33,800원
- [벨킨 Qi2 15W 마그네틱 무선충전 보조배터리 10000mAh](https://link.coupang.com/a/d95TBo) — 56,900원

## 함께 읽어보기

{{< article link="/posts/강원-축제행사-일정과-체험-프로그램-정리/" >}}

{{< article link="/posts/제주-금능원담축제-일정과-주변-볼거리-정리/" >}}

{{< article link="/posts/경남-아라가야문화제와-함께하는-축제-일정-정리/" >}}

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**
