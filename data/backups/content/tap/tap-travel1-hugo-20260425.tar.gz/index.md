---
title: "광주 어린이 가족문화축제와 함께하는 즐길 거리 총정리"
slug: '광주-어린이-가족문화축제와-함께하는-즐길-거리-총정리'
date: '2026-03-21T14:28:01+09:00'
draft: false
description: "<div style=\"margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;\"><a href=\"https://heritage."
tags: ['축제', '축제·행사', '광주']
categories: ['축제']
---

## 광주 어린이 가족문화축제 하우펀 11, 2025년 무료 축제 안내

> [어린이 가족문화축제 하우펀 11 네이버에서 검색하기](https://search.naver.com/search.naver?query=%EC%96%B4%EB%A6%B0%EC%9D%B4%20%EA%B0%80%EC%A1%B1%EB%AC%B8%ED%99%94%EC%B6%95%EC%A0%9C%20%ED%95%98%EC%9A%B0%ED%8E%80%2011)

![어린이 가족문화축제 하우펀 11](http://tong.visitkorea.or.kr/cms/resource/22/3487522_image2_1.jpg)

2025년 5월 28일부터 5월 29일까지 광주광역시에서 열리는 '어린이 가족문화축제 하우펀 11'은 가족과 아이들을 위한 다양한 프로그램으로 가득 차 있습니다. 특히, 이 축제는 무료로 진행되기 때문에 가족 단위 방문객들에게 큰 인기를 끌고 있습니다. 

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>

## 어린이 가족문화축제 하우펀 11 타임테이블 정리 (시간대별 프로그램)

> [어린이 가족문화축제 하우펀 11 네이버에서 검색하기](https://search.naver.com/search.naver?query=%EC%96%B4%EB%A6%B0%EC%9D%B4%20%EA%B0%80%EC%A1%B1%EB%AC%B8%ED%99%94%EC%B6%95%EC%A0%9C%20%ED%95%98%EC%9A%B0%ED%8E%80%2011)

![동명커피산책](http://tong.visitkorea.or.kr/cms/resource/09/3553609_image2_1.jpg)

어린이 가족문화축제 하우펀 11의 프로그램은 날짜와 시간에 따라 다채롭게 구성되어 있습니다. 5월 28일과 29일 양일간 오전 10시부터 오후 6시까지 진행되며, 다양한 체험 부스와 공연이 마련됩니다. 오전 10시부터는 가족 체험 프로그램이 운영되며, 오후 2시부터는 인기 아티스트의 공연이 예정되어 있어 부모와 아이들이 함께 즐길 수 있습니다. 이 외에도 다양한 볼거리가 마련되어 있어 방문객들은 하루 종일 즐거운 시간을 보낼 수 있습니다. 

대중교통 이용이 더욱 효율적일 수 있습니다. 

## 광주 축제와 묶어 갈 당일치기 코스

어린이 가족문화축제 하우펀 11을 방문한 후, 광주에서 다른 축제를 함께 즐기는 것도 추천합니다. 축제장 인근에는 '무등울림축제'와 '남도달밤야시장'이 위치하고 있어, 문화와 맛을 동시에 경험할 수 있습니다. 무등울림축제는 전통문화관에서 열리며, 다양한 공연과 체험 프로그램이 마련되어 있습니다. 남도달밤야시장은 저녁에 열리며, 지역 특산물과 음식들을 맛볼 수 있는 좋은 기회입니다. 이 두 축제는 하우펀 11과 가까운 거리이므로 시간적 여유를 두고 일정을 조정하면 좋습니다.

가족과 함께 다양한 프로그램을 계획하면 더욱 즐거운 하루가 될 것입니다.

## 대중교통으로 가는 법 (버스·지하철 노선)

광주광역시의 대중교통은 매우 편리합니다. 어린이 가족문화축제 하우펀 11에 가기 위해서는 지하철 1호선을 이용해 '문화전당역'에서 하차 후, 도보로 약 5분 거리에 위치해 있습니다. 버스를 이용할 경우, '문화전당' 정류장에서 하차하면 됩니다. 많은 사람들이 모이는 축제인 만큼, 대중교통을 이용하는 것이 혼잡을 피하는 데 도움이 됩니다. 

교통 혼잡을 피하기 위해서는 축제 시작 시간인 오전 10시 이전에 도착하는 것을 추천합니다. 

## 어린이 가족문화축제 하우펀 11 주차장 3곳 위치와 요금

> [어린이 가족문화축제 하우펀 11 네이버에서 검색하기](https://search.naver.com/search.naver?query=%EC%96%B4%EB%A6%B0%EC%9D%B4%20%EA%B0%80%EC%A1%B1%EB%AC%B8%ED%99%94%EC%B6%95%EC%A0%9C%20%ED%95%98%EC%9A%B0%ED%8E%80%2011)

어린이 가족문화축제 하우펀 11을 방문할 때 주차 공간이 한정되어 있어 주의가 필요합니다. 축제장 인근에는 주차장이 크게 3곳 있습니다. 첫 번째는 문화전당 주차장으로 100대 수용 가능하며, 요금은 확인 필요합니다. 두 번째는 동구청 주차장으로 50대 수용 가능합니다. 세 번째는 주변 상가 주차장으로 50대 수용 가능하나, 사전 예약이 필요할 수 있습니다. 

주차를 원할 경우, 가능한 일찍 도착하여 자리를 잡는 것이 좋습니다. 

**기간** 2025년 5월 28일 ~ 5월 29일 / **장소** 광주광역시 동구 문화전당로 38 / **입장료** 무료 / **주차** 유료, 수용대수 수용대수는 공식 사이트에서 확인

5월의 날씨는 변덕스럽기 때문에 가벼운 외투를 준비하는 것이 좋습니다. 축제 기간 동안 혼잡을 피하려면 금요일이나 토요일 아침 일찍 방문하는 전략이 효과적입니다. 네이버 예약에서 '어린이 가족문화축제 하우펀 11'을 검색 후 사전접수를 하면 대기 없이 입장 가능합니다.

<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://www.trip.com/?Allianceid=3993748&SID=travel_blog" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>

## 반경 10km 내 가볼만한 곳

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EA%B3%B5%EC%9B%90%20%EC%84%A0%EC%A0%95%EB%B9%84%EA%B5%B0" target="_blank">광주공원 선정비군 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%EA%B3%B5%EC%9B%90" target="_blank">광주공원 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B4%80%EB%8D%95%EC%A0%95%EC%9D%98%20%EA%B0%81%EA%B6%81" target="_blank">관덕정의 각궁 지도에서 보기</a>

## 반경 10km 내 맛집

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B9%80%EB%AA%85%ED%99%94%EC%84%9C%EB%A6%AC%ED%83%9C%EC%BD%A9%EA%B5%AD%EC%88%98" target="_blank">김명화서리태콩국수 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%99%A9%EC%86%94%EC%B4%8C%20%EC%B6%A9%EC%9E%A5%EC%A0%90" target="_blank">황솔촌 충장점 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%8D%BC%EC%8A%A4%ED%8A%B8%EB%84%A4%ED%8C%94" target="_blank">퍼스트네팔 지도에서 보기</a>

전화: 062-225-8771

---

## 여행 준비에 도움되는 추천 용품

- [바우아토 원터치 블루투스 셀카봉 삼각대](https://link.coupang.com/a/d95Twc) — 33,800원
- [벨킨 Qi2 15W 마그네틱 무선충전 보조배터리 10000mAh](https://link.coupang.com/a/d95TBo) — 56,900원

## 함께 읽어보기

{{< article link="/posts/충남-국가유산-미디어아트-부-행사-일정과-즐길-거리-정리/" >}}

{{< article link="/posts/충북-축제행사-주차장-위치와-요금-정리/" >}}

{{< article link="/posts/경기-축제행사-푸드존-메뉴와-가격-미리보기/" >}}

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**
