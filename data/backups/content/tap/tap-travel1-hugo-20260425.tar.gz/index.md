---
title: "대전 유성구 축제 야간 프로그램과 포토존 위치"
date: 2026-04-02
draft: false

---

<!-- DESC: 대전 유성구 축제 — 제11회 세계과학문화포럼. 1곳 정보와 방문 팁 정리. -->
## 대전 유성구 축제 개요와 일정

![제11회 세계과학문화포럼](https://tong.visitkorea.or.kr/cms/resource/82/4054782_image2_1.jpg)


대전 유성구에서 개최되는 제11회 세계과학문화포럼은 과학과 문화를 주제로 한 축제입니다. 이번 포럼은 2026년 4월 17일부터 4월 18일까지 이틀 동안 진행됩니다. 행사 장소는 대전광역시 유성구 엑스포로 87에 위치한 대전컨벤션센터 제2전시장 1전시홀입니다. 입장료는 무료로 제공되며, 누구나 자유롭게 참여할 수 있습니다. 주최는 대전광역시이며, 다양한 프로그램이 준비되어 있어 많은 이들에게 흥미로운 경험을 선사할 것입니다.

## 주요 프로그램과 체험

제11회 세계과학문화포럼에서는 다채로운 프로그램이 마련되어 있습니다. 첫째 날인 4월 17일에는 개막식과 함께 기조강연이 진행됩니다. 기조강연에는 최재천 교수와 지보브스키 바르토즈 단장이 참여하여 과학과 문화의 융합에 대한 주제를 다룹니다. 이어지는 세션 2와 세션 3에서는 김경일 교수, 김명주 소장, 정명훈 상무, 엄윤설 대표이사가 각각 강연을 진행합니다. 둘째 날인 4월 18일에는 전원경 교수의 세션 1을 시작으로, 박동일 센터장과 채수응 대표이사, 임희원 대표이사와 궤도 과학커뮤니케이터가 참여하는 세션이 이어집니다. 또한, AI 로고송 챌린지와 같은 부대 프로그램도 마련되어 있어 참가자들이 직접 참여할 수 있는 기회를 제공합니다.

## 교통과 주차 안내

대전컨벤션센터 제2전시장 1전시홀은 대전광역시 유성구 엑스포로 87에 위치하고 있습니다. 이곳에 접근하기 위해서는 대중교통을 이용하는 것이 편리합니다. 대전 지하철 1호선의 도룡역에서 하차 후, 도보로 약 15분 거리에 위치해 있습니다. 또한, 대전 시내버스 노선도 여러 개가 지나가므로, 해당 노선의 버스를 이용하면 보다 쉽게 도착할 수 있습니다. 주차는 행사장 내에서 가능하나, 주차 가능 여부와 요금은 현장에서 확인하는 것을 추천합니다. 대중교통을 이용할 경우, 혼잡한 시간대를 피할 수 있어 더 편리하게 이동할 수 있습니다.

## 방문 전 참고 사항

제11회 세계과학문화포럼을 방문하기 전, 추천 방문 시간대는 오전 9시부터 오후 12시 사이입니다. 이 시간대는 행사 시작과 함께 다양한 프로그램이 진행되므로, 보다 많은 내용을 접할 수 있습니다. 복장에 있어서는 편안한 복장을 추천합니다. 행사장 내부는 다소 쾌적하게 유지되지만, 외부 날씨에 따라 적절한 겉옷을 준비하는 것이 좋습니다. 혼잡을 피하기 위해서는 행사 첫날보다는 둘째 날에 방문하는 것이 좋습니다. 둘째 날은 상대적으로 관람객 수가 적을 수 있으며, 보다 여유롭게 프로그램을 관람할 수 있습니다. 이와 같은 팁을 참고하여 방문 계획을 세우면 더욱 알찬 시간을 보낼 수 있습니다.

---

## 여행 준비에 도움되는 추천 용품

- [코멧 패브릭 쿠션 접이식 의자](https://link.coupang.com/a/egyZb4) — 16,710원
- [[등땀탈출] 휴이즈 휴대용 허리 선풍기, 화이트+실버 (1+1)](https://link.coupang.com/a/egyZhP) — 63,000원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 근처 가볼 만한 곳

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/16/3032116_image2_1.JPG" alt="유성 관광특구" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">유성 관광특구</strong><span class="nearby-card-addr">대전광역시 유성구 대덕대로 480</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9C%A0%EC%84%B1%20%EA%B4%80%EA%B4%91%ED%8A%B9%EA%B5%AC" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/29/3564729_image2_1.jpg" alt="대전교통문화연수원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">대전교통문화연수원</strong><span class="nearby-card-addr">대전광역시 유성구 대덕대로 480</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%8C%80%EC%A0%84%EA%B5%90%ED%86%B5%EB%AC%B8%ED%99%94%EC%97%B0%EC%88%98%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/96/3452996_image2_1.jpg" alt="꿀잼도시 대전홍보관" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">꿀잼도시 대전홍보관</strong><span class="nearby-card-addr">대전광역시 유성구 엑스포로 1 (도룡동)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%BF%80%EC%9E%BC%EB%8F%84%EC%8B%9C%20%EB%8C%80%EC%A0%84%ED%99%8D%EB%B3%B4%EA%B4%80" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



## 근처 맛집

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/14/2767214_image2_1.jpg" alt="더 빛나" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">더 빛나</strong><span class="nearby-card-addr">대전광역시 유성구 엑스포로 131 (도룡동)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%8D%94%20%EB%B9%9B%EB%82%98" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/47/2899447_image2_1.jpg" alt="천년의정원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">천년의정원</strong><span class="nearby-card-addr">대전광역시 서구 만년로67번길 18-13 (만년동)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%B2%9C%EB%85%84%EC%9D%98%EC%A0%95%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/57/3444257_image2_1.jpg" alt="정일품두손두부" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">정일품두손두부</strong><span class="nearby-card-addr">대전광역시 서구 둔산대로117번길 34 (만년동)</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%A0%95%EC%9D%BC%ED%92%88%EB%91%90%EC%86%90%EB%91%90%EB%B6%80" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

{{< article link="/posts/대전-동구동락-축제와-함께하는-즐길거리-5곳-정리/" >}}

{{< article link="/posts/광주-무등산-인문축제-일정과-체험-코스-추천/" >}}

{{< article link="/posts/서울무용제-일정과-관람-포인트-정리/" >}}



<a class="naver-map-btn" href="https://map.naver.com/v5/search/%EC%A0%9C11%ED%9A%8C%20%EC%84%B8%EA%B3%84%EA%B3%BC%ED%95%99%EB%AC%B8%ED%99%94%ED%8F%AC%EB%9F%BC" target="_blank" rel="nofollow">제11회 세계과학문화포럼 네이버 지도에서 보기</a>