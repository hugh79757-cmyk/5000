---
title: "서울 제2회 고메 잇 강남 행사 총정리"
slug: '서울-제2회-고메-잇-강남-행사-총정리'
date: '2026-03-21T16:18:24+09:00'
draft: false
description: "<div style=\"margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;\"><a href=\"https://heritage."
tags: ['축제', '축제·행사', '서울']
categories: ['축제']
---

## 제2회 고메 잇 강남, 동궐동락, 서울라이트 광화문 축제 정보

> [제2회 고메 잇 강남 네이버 지도에서 보기](https://map.naver.com/v5/search/%EC%A0%9C2%ED%9A%8C%20%EA%B3%A0%EB%A9%94%20%EC%9E%87%20%EA%B0%95%EB%82%A8)

![동궐동락](http://tong.visitkorea.or.kr/cms/resource/22/3572022_image2_1.jpg)

2023년 10월 12일부터 15일까지 서울에서 열리는 제2회 고메 잇 강남은 많은 방문객이 찾는 인기 축제입니다. 이 축제는 삼성동에서 열리며, 입장료는 없습니다. 

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>

## 제2회 고메 잇 강남 타임테이블 정리 (시간대별 프로그램)

> [제2회 고메 잇 강남 네이버 지도에서 보기](https://map.naver.com/v5/search/%EC%A0%9C2%ED%9A%8C%20%EA%B3%A0%EB%A9%94%20%EC%9E%87%20%EA%B0%95%EB%82%A8)

![종로K축제](http://tong.visitkorea.or.kr/cms/resource/64/3563664_image2_1.jpg)

제2회 고메 잇 강남의 프로그램은 다양한 음식 체험과 이벤트로 구성됩니다. 첫날인 10월 12일에는 오후 1시부터 5시까지 유명 셰프들의 요리 시연이 예정되어 있습니다. 이어서 저녁 6시부터 9시까지 지역 식당의 푸드 트럭이 운영됩니다. 축제 기간 동안 매일 공연과 전시도 진행되며, 주말에는 더욱 다양한 프로그램이 마련됩니다. 궁금한 점은 현장에서 직접 확인할 수 있습니다.

## 제2회 고메 잇 강남 주차장 3곳 위치와 요금

> [제2회 고메 잇 강남 네이버 지도에서 보기](https://map.naver.com/v5/search/%EC%A0%9C2%ED%9A%8C%20%EA%B3%A0%EB%A9%94%20%EC%9E%87%20%EA%B0%95%EB%82%A8)

고메 잇 강남 주변에는 3곳의 주차장이 위치해 있습니다. 첫 번째는 삼성동에서 가장 가까운 삼성역 공영주차장으로, 24시간 운영됩니다. 두 번째는 코엑스 주차장으로, 행사 기간 중 특별 요금이 적용됩니다. 세 번째는 인근의 스타필드 주차장으로, 탁 트인 공간 덕에 주차가 용이합니다. 

## 서울라이트 광화문 반경 1km 점심 맛집 3곳

> [서울라이트 광화문 네이버 지도에서 보기](https://map.naver.com/v5/search/%EC%84%9C%EC%9A%B8%EB%9D%BC%EC%9D%B4%ED%8A%B8%20%EA%B4%91%ED%99%94%EB%AC%B8)

서울라이트 광화문 근처에는 다양한 점심 맛집이 있습니다. 첫 번째로 추천할 장소는 '광화문국밥'으로, 국밥이 인기 메뉴다. 두 번째는 '연남서식당'으로, 퓨전 한식이 매력적입니다. 마지막으로 '마포갈매기'는 고기구이를 전문으로 하는 곳으로, 점심시간에 가볍게 즐기기 좋습니다. 이들 맛집은 축제 관람 후 간편하게 이동할 수 있는 위치에 있습니다.

## 겨울, 청계천의 빛 야간 프로그램과 조명 포인트

> [겨울, 청계천의 빛 네이버 지도에서 보기](https://map.naver.com/v5/search/%EA%B2%A8%EC%9A%B8%2C%20%EC%B2%AD%EA%B3%84%EC%B2%9C%EC%9D%98%20%EB%B9%9B)

겨울, 청계천의 빛 축제는 야경을 즐길 수 있는 최적의 장소입니다. 이곳에서는 매일 저녁 5시부터 10시까지 화려한 조명으로 청계천이 빛납니다. 특히, 청계천 다리 위에서 바라보는 조명은 인상적입니다. 주말에는 더욱 많은 인파가 몰리므로 평일 방문을 고려하는 것이 좋습니다. 

**기간** 2023년 10월 12일 ~ 15일 / **장소** 서울특별시 강남구 영동대로 513 / **입장료** 무료 / **주차** 유료, 수용대수는 공식 사이트에서 확인

축제 기간 동안 날씨는 쌀쌀할 수 있으니, 가벼운 외투를 준비하는 것이 좋습니다. 주말에는 혼잡하므로 가급적 평일에 방문하는 것이 바람직합니다. 네이버 예약에서 제2회 고메 잇 강남을 검색 후 사전 접수하면 대기 없이 입장 가능합니다.

<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://www.trip.com/?Allianceid=3993748&SID=travel_blog" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>

## 반경 10km 내 가볼만한 곳

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%B6%A9%EB%AC%B4%EB%A1%9C%EC%98%81%EC%83%81%EC%84%BC%ED%84%B0%20%EC%98%A4%EC%9E%AC%EB%AF%B8%EB%8F%99" target="_blank">충무로영상센터 오재미동 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%B6%A9%EB%AC%B4%EB%A1%9C%20%EC%9D%B8%EC%87%84%EA%B3%A8%EB%AA%A9" target="_blank">충무로 인쇄골목 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%95%B4%ED%92%8D%EB%B6%80%EC%9B%90%EA%B5%B0%EC%9C%A4%ED%83%9D%EC%98%81%EB%8C%81%EC%9E%AC%EC%8B%A4" target="_blank">해풍부원군윤택영댁재실 지도에서 보기</a>

## 반경 10km 내 맛집

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%95%84%EB%8F%99%EB%A9%B4%EC%98%A5" target="_blank">필동면옥 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B8%88%EB%8F%99%ED%99%94%EB%A1%9C%EC%88%AF%EB%B6%88%EA%B5%AC%EC%9D%B4" target="_blank">금동화로숯불구이 지도에서 보기</a>

전화: 02-2264-3002

<a class="nearby-link" href="https://map.naver.com/v5/search/%EB%A1%9C%EC%9D%B4%ED%84%B0%20%EC%BB%A4%ED%94%BC%20%EC%85%B8%ED%84%B0" target="_blank">로이터 커피 셸터 지도에서 보기</a>

---

## 여행 준비에 도움되는 추천 용품

- [바우아토 원터치 블루투스 셀카봉 삼각대](https://link.coupang.com/a/d95Twc) — 33,800원
- [벨킨 Qi2 15W 마그네틱 무선충전 보조배터리 10000mAh](https://link.coupang.com/a/d95TBo) — 56,900원

## 함께 읽어보기

{{< article link="/posts/부산-유라리-건맥축제와-주변-행사-정리/" >}}

{{< article link="/posts/서울-한강페스티벌-일정과-인근-명소-정리/" >}}

{{< article link="/posts/광주-어린이-가족문화축제-일정과-인근-행사-정리/" >}}

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**
