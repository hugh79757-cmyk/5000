---
title: "경기 광주시 축제 먹거리와 체험 부스 미리 보기"
slug: '경기-광주시-축제-먹거리와-체험-부스-미리-보기'
date: '2026-04-04T07:02:56+09:00'
draft: false
description: "경기 광주시 축제 — 광주왕실도자페스티벌. 1곳 정보와 방문 팁 정리."
tags: ['festival', '축제', '경기 광주시']
categories: ['festival']
---

## 경기 광주시 축제 개요와 일정

![광주왕실도자페스티벌](https://tong.visitkorea.or.kr/cms/resource/20/3481720_image2_1.jpg)


경기 광주시에서 열리는 광주왕실도자페스티벌은 2026년 4월 24일부터 5월 5일까지 진행됩니다. 이 축제는 곤지암도자공원에서 개최되며, 입장료는 무료입니다. 주최는 광주시에서 맡고 있으며, 왕실도자에 대한 다양한 프로그램과 행사가 마련되어 있습니다. 축제 기간 동안 관람객들은 전시, 공연, 체험 등 다양한 활동에 참여할 수 있습니다. 이 축제는 도자기와 관련된 문화와 예술을 체험할 수 있는 좋은 기회가 될 것입니다.

## 주요 프로그램과 체험

광주왕실도자페스티벌에서는 여러 가지 프로그램과 체험이 마련되어 있습니다. 첫 번째로, 광주왕실도자 전시 및 판매가 진행되어 관람객들은 다양한 도자기를 감상하고 구매할 수 있습니다. 또한, 왕실도자 명장전이 열려 도자기 제작의 명장들의 작품을 직접 볼 수 있는 기회를 제공합니다. 공연 프로그램으로는 버스킹 및 프린지 공연이 마련되어 있어, 축제의 분위기를 더욱 고조시킵니다. 뿐만 아니라, 왕실도자 마당극이 진행되어 전통적인 이야기와 예술을 함께 즐길 수 있습니다. 마지막으로, 인스톨레이션 아트, 리버마켓, 분원오락실, 도공의 하루(왕실도자체험), 역사문화 만들기 체험 등 다양한 체험 프로그램이 준비되어 있어 가족 단위 방문객들도 즐길 수 있는 내용이 가득합니다.

## 교통과 주차 안내

광주왕실도자페스티벌이 열리는 곤지암도자공원은 경기도 광주시 곤지암읍 경충대로 727에 위치하고 있습니다. 자가용으로 방문할 경우, 경충대로를 따라 오시면 쉽게 도착할 수 있습니다. 대중교통을 이용할 경우, 광주역이나 분당선 곤지암역에서 버스를 이용하여 곤지암도자공원으로 이동할 수 있습니다. 버스 노선은 지역에 따라 다를 수 있으므로, 사전에 확인하는 것이 좋습니다. 주차 가능 여부와 요금은 현장 확인을 추천합니다. 대중교통을 이용하는 경우, 혼잡한 시간대를 피하기 위해 미리 출발하는 것이 좋습니다.

## 방문 전 참고 사항

광주왕실도자페스티벌을 방문할 때는 오전 10시부터 오후 5시 30분까지 운영되므로, 이 시간을 고려하여 방문 계획을 세우는 것이 좋습니다. 특히, 주말이나 공휴일에는 많은 인파가 몰릴 수 있으므로, 평일 방문을 추천합니다. 복장은 편안한 복장으로 준비하시고, 날씨에 따라 외투를 챙기는 것이 좋습니다. 또한, 행사장 내에서는 다양한 체험 프로그램이 진행되므로, 미리 예약이 필요한 프로그램이 있는지 확인하는 것이 필요합니다. 혼잡을 피하기 위해서는 오전 일찍 도착하는 것이 좋습니다.

---

## 여행 준비에 도움되는 추천 용품

- [바우아토 포켓쉴 고속 입출력 케이블 일체형 미니 대용량 난연 보조배터리 20000mAh C타입 애플8핀 PD 22.5W, 단일상품, 아이보리](https://link.coupang.com/a/ehB379) — 37,800원
- [폴딩 스포츠물병 접이식 실리콘 등산물병 헬스 여행용  접히는 물병](https://link.coupang.com/a/ehB4cs) — 11,900원

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**


<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://kr.trip.com/?Allianceid=7451816&SID=283255449&trip_sub1=&trip_sub3=D14664967" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>


## 근처 가볼 만한 곳

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/16/3072516_image2_1.jpg" alt="광주 곤지암도자공원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">광주 곤지암도자공원</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 경충대로 727</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EA%B3%A4%EC%A7%80%EC%95%94%EB%8F%84%EC%9E%90%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/27/3527227_image2_1.jpg" alt="호국생활체육공원" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">호국생활체육공원</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 평촌길 12-137</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%ED%98%B8%EA%B5%AD%EC%83%9D%ED%99%9C%EC%B2%B4%EC%9C%A1%EA%B3%B5%EC%9B%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/93/2862193_image2_1.jpg" alt="곤지바위" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">곤지바위</strong><span class="nearby-card-addr">경기도 광주시 곤지암로 72</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EA%B3%A4%EC%A7%80%EB%B0%94%EC%9C%84" target="_blank" rel="nofollow">지도에서 보기</a></div></div>



## 근처 맛집

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/51/2750551_image2_1.png" alt="시래마루" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">시래마루</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 경충대로 661</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%8B%9C%EB%9E%98%EB%A7%88%EB%A3%A8" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/41/2750441_image2_1.png" alt="동동국수 본점" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">동동국수 본점</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 도척로 20</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EB%8F%99%EB%8F%99%EA%B5%AD%EC%88%98%20%EB%B3%B8%EC%A0%90" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

<div class="nearby-card"><img class="nearby-card-img" src="https://tong.visitkorea.or.kr/cms/resource/03/2865503_image2_1.jpg" alt="우해정" loading="lazy"><div class="nearby-card-body"><strong class="nearby-card-name">우해정</strong><span class="nearby-card-addr">경기도 광주시 곤지암읍 곤지암천로 248</span><a class="nearby-card-btn" href="https://map.naver.com/v5/search/%EC%9A%B0%ED%95%B4%EC%A0%95" target="_blank" rel="nofollow">지도에서 보기</a></div></div>

## 함께 읽어보기

- [서울 중구 이순신 축제와 스프링워크서울 포함 2곳 꿀팁](/posts/서울-중구-이순신-축제와-스프링워크서울-포함-2곳-꿀팁/)
- [충남 예산군 윤봉길 평화축제와 함께 즐길 3가지 이유](/posts/충남-예산군-윤봉길-평화축제와-함께-즐길-3가지-이유/)
- [충북 청주시 축제 주차난 피하는 법과 셔틀 안내](/posts/충북-청주시-축제-주차난-피하는-법과-셔틀-안내/)