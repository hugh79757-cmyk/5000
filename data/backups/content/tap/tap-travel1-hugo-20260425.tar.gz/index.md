---
title: "전남 여수동동북축제 일정과 주변 행사 정리"
slug: '전남-여수동동북축제-일정과-주변-행사-정리'
date: '2026-03-21T18:01:42+09:00'
draft: false
description: "각 축제마다 다양한 프로그램과 체험이 마련될 것으로 예상됩니다. 여수동동북축제는 가족 단위 방문객을 위한 여러 놀이 및 체험 프로그램이 진행될 가능성이 높습니다. 남도영화제 시즌2 광양은 영화 상영 외에도 관객과의 대화, 다양한 영화 관련 행사가 포함될 것으로 예상됩니다. 남도국제미식산"
tags: ['축제·행사', '전남', '축제']
categories: ['축제']
---

## 전남 축제·행사 개요와 일정

> [전남 세계 김밥 페스티벌 네이버에서 검색하기](https://search.naver.com/search.naver?query=%EC%A0%84%EB%82%A8%20%EC%84%B8%EA%B3%84%20%EA%B9%80%EB%B0%A5%20%ED%8E%98%EC%8A%A4%ED%8B%B0%EB%B2%8C)

![여수동동북축제](http://tong.visitkorea.or.kr/cms/resource/02/3406002_image2_1.jpg)

전남에서는 여수동동북축제, 남도영화제 시즌2 광양, 남도국제미식산업박람회, 한국전력과 함께하는 2025 희망·사랑 나눔 콘서트, 전남 세계 김밥 페스티벌 등 다섯 가지 주요 축제와 행사가 개최됩니다. 여수동동북축제는 전라남도 여수시 소호로 606에서 개최되며, 구체적인 일정은 발표되지 않았습니다. 남도영화제 시즌2 광양은 광양시 중마중앙로 99에서 열리며, 이 또한 일정이 구체적으로 안내되지 않았습니다. 남도국제미식산업박람회는 목포시 남농로 102에서 진행되며, 자세한 일정은 확인이 필요합니다. 한국전력과 함께하는 2025 희망·사랑 나눔 콘서트는 장성군 장성읍 문화로 110에서 열리며, 전반적인 일정은 별도 안내가 필요합니다. 마지막으로, 전남 세계 김밥 페스티벌은 목포시 남농로 102에서 개최되며, 일정은 추후 공지될 예정입니다. 이 모든 축제는 가족 및 친구와 함께 즐기기에 적합한 행사들입니다.

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>

## 주요 프로그램과 체험

![남도영화제 시즌2 광양](http://tong.visitkorea.or.kr/cms/resource/59/3536359_image2_1.jpg)

각 축제마다 다양한 프로그램과 체험이 마련될 것으로 예상됩니다. 여수동동북축제는 가족 단위 방문객을 위한 여러 놀이 및 체험 프로그램이 진행될 가능성이 높습니다. 남도영화제 시즌2 광양은 영화 상영 외에도 관객과의 대화, 다양한 영화 관련 행사가 포함될 것으로 예상됩니다. 남도국제미식산업박람회는 음식과 관련된 체험을 통해 전라남도의 다양한 미식을 소개하는 자리가 될 것입니다. 한국전력과 함께하는 2025 희망·사랑 나눔 콘서트는 음악 공연과 함께 서로의 희망과 사랑을 나누는 활동이 포함될 것입니다. 전남 세계 김밥 페스티벌은 김밥 조리 체험 및 시식 프로그램이 마련될 가능성이 큽니다. 각 축제의 프로그램은 주최측의 결정에 따라 달라질 수 있으므로 사전에 확인하는 것이 좋습니다.

## 교통과 주차 안내

![남도국제미식산업박람회](http://tong.visitkorea.or.kr/cms/resource/74/3544874_image2_1.jpg)

전남의 축제들은 각기 다른 지역에 위치하고 있습니다. 여수동동북축제는 여수시에서 열리므로 여수시내에서 접근이 용이합니다. 남도영화제 시즌2 광양은 광양시 내에서 이동이 편리하며, 주차 공간이 마련되어 있습니다. 남도국제미식산업박람회는 목포시 남농로에서 개최되며, 해당 장소에는 주차 시설이 존재합니다. 한국전력과 함께하는 2025 희망·사랑 나눔 콘서트는 장성군 장성읍에 위치해 있으며, 대중교통을 이용할 경우 버스를 이용할 수 있습니다. 전남 세계 김밥 페스티벌 역시 목포시에서 열리기 때문에 인근 대중교통 이용이 가능합니다. 각 행사마다 주차 여건이 다를 수 있으므로 현장 확인을 추천합니다.

## 방문 전 참고 사항

![한국전력과 함께하는 2025 희망·사랑 나눔 콘서트](http://tong.visitkorea.or.kr/cms/resource/85/3547385_image2_1.jpg)

축제를 방문할 예정이라면 미리 일정을 확인하는 것이 중요합니다. 각 행사에서는 혼잡할 수 있는 시간대가 있으므로, 평일이나 이른 시간대에 방문하는 것이 좋습니다. 복장은 행사 성격에 맞춰 편안하고 활동하기 좋은 복장을 추천합니다. 또한 여수동동북축제와 같은 가족 단위 행사에 참석할 경우, 어린이 동반 시 미리 필요한 물품을 챙기는 것이 좋습니다. 대중교통을 이용할 경우, 사전에 시간표를 확인하여 원활한 이동을 도모하는 것이 유리합니다. 각 축제마다 다채로운 프로그램이 준비되어 있을 것으로 예상되므로, 세부 사항을 미리 확인한 후 방문하는 것이 바람직합니다.

<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://www.trip.com/?Allianceid=3993748&SID=travel_blog" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>

## 반경 10km 내 가볼만한 곳

![전남 세계 김밥 페스티벌](http://tong.visitkorea.or.kr/cms/resource/16/3553016_image2_1.JPG)

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%86%A1%EC%84%9D%EC%A0%95" target="_blank">송석정 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%86%A1%EC%84%9D%EC%A0%95%EC%9C%A0%EC%9B%90%EC%A7%80" target="_blank">송석정유원지 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%95%99%ED%8F%AC%EB%8B%B9" target="_blank">학포당 지도에서 보기</a>

---

## 여행 준비에 도움되는 추천 용품

- [바우아토 원터치 블루투스 셀카봉 삼각대](https://link.coupang.com/a/d95Twc) — 33,800원
- [벨킨 Qi2 15W 마그네틱 무선충전 보조배터리 10000mAh](https://link.coupang.com/a/d95TBo) — 56,900원

## 함께 읽어보기

{{< article link="/posts/광주여성영화제-일정과-관람-꿀팁-총정리/" >}}

{{< article link="/posts/세종에서-열리는-나라꽃-무궁화-대축제-일정과-장소-정리/" >}}

{{< article link="/posts/광주-양동통맥축제-일정과-주변-명소-정리/" >}}

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**
