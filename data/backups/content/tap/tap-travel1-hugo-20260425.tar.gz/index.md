---
title: "광주여성영화제 일정과 관람 꿀팁 총정리"
slug: '광주여성영화제-일정과-관람-꿀팁-총정리'
date: '2026-03-22T13:15:32+09:00'
draft: false
description: "광주에서 개최되는 광주여성영화제는 여성 감독들의 작품을 중심으로 다루는 영화제로, 올해에는 2026년 11월 6일부터 11월 10일까지 열립니다. 이 영화제는 광주광역시 동구 중앙로160번길 16-7에 위치한 광주극장에서 진행되며, 폐막식은 CGV 광주금남로에서 진행됩니다. 영화제를 통"
tags: ['축제·행사', '축제', '광주']
categories: ['축제']
---

## 광주 축제·행사 개요와 일정

![광주여성영화제](http://tong.visitkorea.or.kr/cms/resource/26/3460726_image2_1.jpg)

광주에서 개최되는 광주여성영화제는 여성 감독들의 작품을 중심으로 다루는 영화제로, 올해에는 2025년 11월 6일부터 11월 10일까지 열립니다. 이 영화제는 광주광역시 동구 중앙로160번길 16-7에 위치한 광주극장에서 진행되며, 폐막식은 CGV 광주금남로에서 진행됩니다. 영화제를 통해 많은 영화 팬이 다양한 여성 감독들의 작품을 관람할 수 있는 기회를 가지게 됩니다. 입장료는 일반적으로 5,000원이며, 장애인 좌석은 별도로 예약이 필요합니다. 이 영화제는 광주 지역의 문화적 다양성과 여성의 목소리를 담아내는 중요한 자리로 자리잡고 있습니다.

<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="width:120px;height:120px;object-fit:cover;flex-shrink:0;" loading="lazy"/><div style="padding:12px 16px;flex:1;min-width:0;"><span style="display:inline-block;font-size:11px;color:#B8860B;font-weight:700;letter-spacing:0.5px;margin-bottom:4px;">K-HERITAGE GUIDE</span><p style="margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:#2c2416;">한국 궁궐·종묘 가이드 — K-Heritage Guide</p><p style="margin:0;font-size:13px;color:#6b5e4f;line-height:1.4;">경복궁, 창덕궁, 창경궁, 덕수궁, 종묘 — 4개 언어 해설과 사진으로 만나는 한국의 궁궐</p></div></a></div>

## 주요 프로그램과 체험

광주여성영화제는 다양한 프로그램과 체험을 제공합니다. 올해 영화제의 주요 프로그램으로는 '메이드 인 광주'와 경쟁 섹션인 '귄 당선작'이 있습니다. 또한, '마스터클래스'에서는 한국을 이끄는 여성 감독들의 강의가 진행되어, 관객들은 직접 감독의 노하우를 배울 수 있는 소중한 시간을 갖게 됩니다. '배리어프리' 프로그램도 마련되어 있어, 다양한 관객들이 보다 쉽게 영화를 관람할 수 있는 환경을 조성하고 있습니다. 이러한 프로그램을 통해 영화제는 여성의 영화 제작과 관련된 다양한 이야기를 나누고, 지역 사회와의 교류를 촉진하는 기회를 제공합니다.

## 교통과 주차 안내

광주여성영화제가 열리는 광주극장은 대중교통으로 쉽게 접근할 수 있는 위치에 있습니다. 광주광역시의 주요 버스 노선 및 지하철 노선이 가까이 있어, 대중교통 이용이 매우 편리합니다. 특히, 광주역에서 출발하는 버스를 이용할 경우 더욱 수월하게 영화제 장소에 도착할 수 있습니다. 주차 공간은 광주극장 근처에 마련되어 있으나, 행사 기간 동안 혼잡할 수 있으므로 가급적 대중교통을 이용하는 것을 권장합니다. 현장 주차 가능 여부에 대해서는 방문 전에 확인하는 것이 좋습니다. 

## 방문 전 참고 사항

광주여성영화제를 방문할 계획이라면, 추천 방문 시간대는 개막식이나 폐막식 전후로, 프로그램이 집중되는 시간대입니다. 이러한 시간대에는 관객의 참여도가 높아 영화제의 분위기를 더욱 생동감 있게 느낄 수 있습니다. 복장은 편안한 옷차림이 좋으며, 실내 영화관의 온도 차를 고려해 가벼운 외투를 챙기는 것이 좋습니다. 혼잡한 상황을 피하기 위해, 평일에 방문하거나 비인기 상영시간을 선택하는 전략도 효과적입니다. 이 영화제를 통해 지역 여성 감독들의 다양한 작품을 감상하며, 문화적 경험을 쌓을 수 있는 좋은 기회가 될 것입니다.

<div class="cta-box">
  <p style="margin:0;font-size:1.1rem;">여행 숙소를 찾고 계신가요?</p>
  <a href="https://www.trip.com/?Allianceid=3993748&SID=travel_blog" target="_blank" rel="nofollow">트립닷컴에서 최저가 확인하기</a>
</div>

## 반경 10km 내 가볼만한 곳

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%B6%A9%EC%9E%A5%EB%A1%9C%20%ED%99%8D%EC%BD%A9%EA%B3%A8%EB%AA%A9" target="_blank">충장로 홍콩골목 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EA%B4%91%EC%A3%BC%20%EC%B6%A9%EC%9E%A5%EB%A1%9C%20%EC%BC%80%EC%9D%B4%ED%8C%9D%20%EC%8A%A4%ED%83%80%EC%9D%98%20%EA%B1%B0%EB%A6%AC" target="_blank">광주 충장로 케이팝 스타의 거리 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%B6%A9%EC%9E%A5%EB%A1%9C" target="_blank">충장로 지도에서 보기</a>

## 반경 10km 내 맛집

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%99%A9%EC%86%94%EC%B4%8C%20%EC%B6%A9%EC%9E%A5%EC%A0%90" target="_blank">황솔촌 충장점 지도에서 보기</a>

<a class="nearby-link" href="https://map.naver.com/v5/search/%ED%8D%BC%EC%8A%A4%ED%8A%B8%EB%84%A4%ED%8C%94" target="_blank">퍼스트네팔 지도에서 보기</a>

전화: 062-225-8771

<a class="nearby-link" href="https://map.naver.com/v5/search/%EC%A7%84%EC%8A%A4%ED%86%B5" target="_blank">진스통 지도에서 보기</a>

전화: 062-233-3788

---

## 여행 준비에 도움되는 추천 용품

- [바우아토 원터치 블루투스 셀카봉 삼각대](https://link.coupang.com/a/d95Twc) — 33,800원
- [벨킨 Qi2 15W 마그네틱 무선충전 보조배터리 10000mAh](https://link.coupang.com/a/d95TBo) — 56,900원

## 함께 읽어보기

{{< article link="/posts/광주-렛츠플로피-축제-일정과-주변-명소-소개/" >}}

{{< article link="/posts/대전에서-열리는-유성온천-크리와-문화제-일정-정리/" >}}

{{< article link="/posts/제주-새연교-주말-문화공연-일정과-주변-볼거리-정리/" >}}

> **이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.**
