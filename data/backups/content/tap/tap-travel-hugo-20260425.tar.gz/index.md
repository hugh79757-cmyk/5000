---
title: "대구 국보 탐방, 필수 방문지 5곳 정리"
date: 2026-03-23
draft: false

---



## 1. 국보 탐방 체험 과정과 소요 시간

![구미 선산읍 금동보살입상(1976-2)](https://www.khs.go.kr/unisearch/images/national_treasure/1611966.jpg)


<div style="margin:1.5em 0;padding:0;border:1px solid #e0d5c1;border-radius:12px;overflow:hidden;max-width:600px;background:#fffdf7;"><a href="https://heritage.aikorea24.kr/" target="_blank" rel="noopener" style="display:flex;text-decoration:none;color:inherit;"><img src="https://www.heritage.go.kr/gung/gogung4/images/mode_general_00_01.jpg" alt="K-Heritage Guide" style="w